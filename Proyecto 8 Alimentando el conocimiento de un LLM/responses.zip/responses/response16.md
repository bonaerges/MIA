Title: CUARTETOS 2024 ▷ Carnaval de Cádiz

URL Source: https://www.codigocarnaval.com/coac-2024/cuartetos-2024/

Published Time: 2023-11-15T13:47:47+01:00

Markdown Content:
Bienvenidos al apartado de cuartetos 2024 del Carnaval de Cádiz. Aquí podrás acceder a las fichas de cada agrupación pulsando en su fotografía.

En ellas podrás disfrutar de su previa antes del concurso y los vídeos de sus actuaciones completas en las diferentes fases del COAC 2024 en el Gran Teatro Falla.

#### Sobre el COAC 2024

🎭 **[Guía completa del COAC 2024](https://www.codigocarnaval.com/coac-2024/)**  
🎭 **[Entradas COAC 2024](https://www.codigocarnaval.com/coac-2024/entradas-2024/)** – Toda la información  
🎭 **[Orden actuación Cuartos de Final 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-cuartos-2024/)**  
🎭 **[Listado nombres agrupaciones COAC 2024](https://www.codigocarnaval.com/coac-2024/nombres-agrupaciones-2024/)**  
🎭 **[Dónde ver el COAC en DIRECTO](https://www.codigocarnaval.com/coac-directo-online/)**

* * *

Cuartetos COAC 2024
-------------------

* * *

[![Image 1: cuarteto he vuelto](https://www.codigocarnaval.com/wp-content/uploads/2023/11/cuarteto-he-vuelto.jpg)](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/"¡¡Hevuelto!!(ElBarrio)")

### [¡¡He vuelto!! (El Barrio)](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/)

[![Image 2: cuarteto que dolo de muñeca](https://www.codigocarnaval.com/wp-content/uploads/2023/11/cuarteto-que-dolo-de-muneca.jpg)](https://www.codigocarnaval.com/coac-2024/que-dolo-de-muneca/"¡Quédolodemuñeca!")

### [¡Qué dolo de muñeca!](https://www.codigocarnaval.com/coac-2024/que-dolo-de-muneca/)

[![Image 3: cuarteto en mi caseta cabe todo el mundo](https://www.codigocarnaval.com/wp-content/uploads/2023/11/cuarteto-en-mi-caseta-cabe-todo-el-mundo.jpg)](https://www.codigocarnaval.com/coac-2024/en-mi-caseta-cabe-todo-el-mundo/"Enmicasetacabetodoelmundo")

### [En mi caseta cabe todo el mundo](https://www.codigocarnaval.com/coac-2024/en-mi-caseta-cabe-todo-el-mundo/)

[![Image 4: cuarteto punk y circo la lucha continua](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20533'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/los-cocos-de-cadi/"LosCocosdeCadi")

### [Los Cocos de Cadi](https://www.codigocarnaval.com/coac-2024/los-cocos-de-cadi/)

[![Image 5: cuarteto punk y circo la lucha continua](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20533'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/punk-y-circo-la-lucha-continua/"Punkycirco,laluchacontinúa")

### [Punk y circo, la lucha continúa](https://www.codigocarnaval.com/coac-2024/punk-y-circo-la-lucha-continua/)
