Title: Política de Cookies - Codigo Carnaval

URL Source: https://www.codigocarnaval.com/politica-de-cookies/

Published Time: 2019-10-08T22:41:00+02:00

Markdown Content:
**Política de Cookies**

**¿Qué es una cookie?**

Una cookie es un fichero **inofensivo** que se descarga en tu ordenador al acceder a determinadas páginas web. Las cookies permiten a una página web, entre otras cosas, almacenar y recuperar información sobre los hábitos de navegación de un usuario o de su equipo y, dependiendo de la información que contengan y de la forma en que utilice su equipo.

Así, hay cookies que obtienen información relacionada con el número de páginas visitadas, la ciudad a la que está asignada la dirección IP desde la que se accede, el número de nuevos usuarios, la frecuencia y reincidencia de las visitas, el tiempo de visita, el navegador, el operador o el tipo de terminal desde el que se realiza la visita.

**¿Qué NO ES una _cookie_?**

No es un virus, ni un troyano, ni un gusano, ni spam, ni spyware, ni abre ventanas pop-up.

**¿Qué información almacena una _cookie_?**

Las _cookies_ no suelen almacenar información sensible sobre ti, como tarjetas de crédito o datos bancarios, fotografías, tu DNI o información personal, etc. Los datos que guardan son de carácter técnico, preferencias personales, personalización de contenidos, etc.

El servidor web no te asocia como persona si no a tu navegador web. De hecho, si navegas habitualmente con Internet Explorer y pruebas a navegar por la misma web con Firefox o Chrome verás que la web no se da cuenta que eres la misma persona porque en realidad está asociando al navegador, no a la persona.

**¿Qué ocurre si desactivo las _cookies_?**

Para que entiendas el alcance que puede tener desactivar las _cookies_ te mostramos unos ejemplos:

*   No podrás compartir contenidos de esa web en Facebook, Twitter o cualquier otra red social.
*   El sitio web no podrá adaptar los contenidos a tus preferencias personales, como suele ocurrir en las tiendas online.
*   No podrás acceder al área personal de la web, como por ejemplo _Mi cuenta_, o _Mi perfil_ o _Mis pedidos_.
*   Tiendas online: Te será imposible realizar compras online, tendrán que ser telefónicas o visitando la tienda física si es que dispone de ella.
*   No será posible personalizar tus preferencias geográficas como franja horaria, divisa o idioma.
*   El sitio web no podrá realizar analíticas web sobre visitantes y tráfico en la web, lo que dificultará que la web sea competitiva.
*   No podrás escribir en el blog, no podrás subir fotos, publicar comentarios, valorar o puntuar contenidos. La web tampoco podrá saber si eres un humano o una aplicación automatizada que publica _spam_.
*   No se podrá mostrar publicidad sectorizada, lo que reducirá los ingresos publicitarios de la web.
*   Todas las redes sociales usan _cookies_, si las desactivas no podrás utilizar ninguna red social.

**¿Qué tipos de cookies hay?**

1.  Tipos de cookies según la entidad que gestione el equipo o dominio desde donde se envían las cookies y trate los datos que se obtengan, podemos distinguir:

*   Cookies propias: Son aquéllas que se envían al equipo terminal del usuario desde un equipo o dominio gestionado por el propio editor y desde el que se presta el servicio solicitado por el usuario.
*   Cookies de terceros: Son aquéllas que se envían al equipo terminal del usuario desde un equipo o dominio que no es gestionado por el editor, sino por otra entidad que trata los datos obtenidos través de las cookies.

En el caso de que las cookies sean instaladas desde un equipo o dominio gestionado por el propio editor pero la información que se recoja mediante éstas sea gestionada por un tercero, no pueden ser consideradas como cookies propias.

**Cookie DART**

*   Google, como proveedor asociado, utiliza cookies para publicar anuncios en Código Carnaval.
*   Puedes inhabilitar el uso de la cookie de DART del sistema de anuncios de Google accediendo al [centro de privacidad de Google](http://www.doubleclick.com/privacy/faq.aspx).

Además, los navegadores pueden también permitir a los usuarios ver y borrar _cookies_ individualmente.

Dispones de más información sobre las _Cookies_ en: [Wikipedia](http://es.wikipedia.org/wiki/Cookie)

**Web _Beacons_**

Este sitio puede albergar también _web beacons_ (también conocidos como _web bugs_). Los _web beacons_ suelen ser pequeñas imágenes de un pixel por un pixel, visibles o invisibles colocados dentro del código fuente de las páginas web de un sitio. Los _web beacons_ sirven y se utilizan de una forma similar a las _cookies_. Además, los _web beacons_ suelen utilizarse para medir el tráfico de usuarios que visitan una página web y poder sacar un patrón de los usuarios de un sitio.

Dispones de más información sobre los _web beacons_ en: [Wikipedia](http://es.wikipedia.org/wiki/Web_bug)

**Cookies de terceros**

En algunos casos, compartimos información sobre los visitantes de este sitio de forma anónima o agregada con terceros como puedan ser anunciantes, patrocinadores o auditores con el único fin de mejorar nuestros servicios. Todas estas tareas de procesamiento serán reguladas según las normas legales y se respetarán todos sus derechos en materia de protección de datos conforme a la regulación vigente.

Este sitio mide el tráfico con diferentes soluciones que pueden utilizar _cookies_ o _web beacons_ para analizar lo que sucede en nuestras páginas. Actualmente utilizamos las siguientes soluciones para la medición del tráfico de este sitio. Puedes ver más información sobre la política de privacidad de cada una de las soluciones utilizadas para tal efecto:

*   [Cómo usa Google los datos que recopila en los sitios web](http://www.google.com/intl/es/policies/privacy/partners/)
*   Google (Analytics): [Política de Privacidad de Google Analytics](http://www.google.com/intl/es_ALL/privacypolicy.html) (_si lo deseas puedes inhabilitar el seguimiento de Google Analytics mediante_ [_este complemento para el navegador ofrecido por Google_](https://tools.google.com/dlpage/gaoptout))

Este sitio también puede albergar publicidad propia, de afiliados, o de redes publicitarias. Esta publicidad se muestra mediante servidores publicitarios que también utilizan _cookies_ para mostrar contenidos publicitarios afines a los usuarios. Cada uno de estos servidores publicitarios dispone de su propia política de privacidad, que puede ser consultada en sus propias páginas web.

**¿Qué tipos de cookies se utilizan en este sitio web?**

Al acceder a la web Código Carnaval te informamos que si sigues navegando se te instalarán diversas cookies propias y de terceros correspondientes a las analíticas de la web (a modo de ejemplo: Google Analytics o herramientas similares) para ayudar al sitio web a analizar el uso que haces del sitio web y mejorar la usabilidad del mismo, pero en ningún caso se asocian a datos que pudieran llegar a identificarte. Los datos que guardan son de carácter técnico, preferencias personales, personalización de contenidos, etc. El servidor web no te asocia como persona sino a tu navegador web

Esta web se utiliza cookies propias y de terceros para conseguir que tengas una mejor experiencia de navegación, puedas compartir contenido en redes sociales, dejar comentarios y para obtener estadísticas de nuestros usuarios.

Como usuario, puedes rechazar el tratamiento de los datos o la información bloqueando estas cookies mediante la configuración apropiada de su navegador. Sin embargo, debes saber que si lo haces,  este sitio puede no funcionar adecuadamente.

Por eso es importante que leas la presente política de cookies y comprendas que si continúas navegando, consideramos que aceptas su uso. Puedes cambiar la configuración de tu navegador para ser avisado de la recepción de cookies en tu dispositivo o desactivar si lo deseas la capacidad de almacenar dichas cookies en tu dispositivo.

**Nuestras Cookies**

Incluimos a continuación una lista de las cookies que usamos, su finalidad y el máximo número de días que permanecerán en su ordenador (a menos que los suprima antes):

wordpress\_test\_cookie: la finalidad de estas cookies son mantener la información de los usuarios registrados y si permiten cookies.

cookie-notice-accepted: Para almacenar su aceptación de nuestra política de cookies. Caduca a los 19 días

**Cookies de terceros**

 **PREF, VISITOR\_INFO1\_LIVE, YSC:** cookies de Youtube utilizadas en la reproducción de vídeos a través de la web.

*   **PREF:** cookie que almacena las preferencias de configuración, tales como idioma preferido, número de resultados de búsqueda mostrados por página o activación del filtro SafeSearch de Google. Tiene una permanencia de 10 años.
*   **VISITOR\_INFO1\_LIVE:** cookie que realiza el seguimiento de los videos visitados que se encuentran incrustados en la web. Tiene una permanencia de 240 días aproximadamente.
*   **YSC:** cookie que mide las reproducciones de videos realizadas por el usuario y registra los eventos de “Me gusta” o “Compartir video”. Es una cookie de sesión, caducando cuando finaliza la sesión con el navegador.

**NID, 1P\_JAR:** cookies de Google.

*   **NID:** Visualización de mapas mediante Google Maps. 6 meses de permanencia.
*   **1P\_JAR:** transfiere datos a Google. Tiene una permanencia de 1 semana.

IDE: Cookie utilizada por Doubleclick.net  para la focalización, optimización, presentación de informes y atribución de anuncios en línea. 2 años.

**Google Analitycs:**

*    \_ga: Se usa para distinguir a los usuarios. Dos años.
*   \_gat: Se usa para diferenciar entre los diferentes objetos de seguimiento creados en la sesión. La cookie se crea al cargar la librería javascript y no existe una versión previa de la cookie \_gat. La cookie se actualiza cada vez que envía los datos a Google Analytics.
*   \_gid: Google Analytics utiliza esta cookie para almacenar y actualizar un valor único para cada página visitada. La cookie se actualiza cada vez que envía los datos a Google Analytics.

Actualmente este sitio web alberga publicidad de:

*   Google Adsense: [Política de privacidad de Google Adsense](http://www.google.es/privacypolicy.html) – [Términos y condiciones](https://www.google.com/adsense/localized-terms) – [Políticas del programa](https://www.google.com/adsense/support/bin/answer.py?answer=48182&sourceid=aso&subid=ww-ww-et-asui&medium=link)

También existen cookies correspondientes a las  redes sociales que utiliza esta web  tienen sus propias políticas de cookies.

*   Cookie de Twitter, según lo dispuesto en su [política de privacidad y uso de cookies](https://twitter.com/privacy).
*   Cookie de Facebook, según lo dispuesto en su [política de Cookies](https://www.facebook.com/help/cookies?ref_type=sitefooter)
*   Cookie de Google+ y Google Maps, según lo dispuesto en su página sobre qué [tipo de cookies utilizan](http://www.google.com/intl/es/policies/technologies/types/)
*   Cookie de Gravatar, según lo dispuesto en [la política de privacidad de la empresa Automattic](http://automattic.com/privacy/).

**¿Cómo se gestionan las _cookies_?**

Puesto que las cookies son archivos de texto normales, se pueden explorar con la mayoría de editores de texto o programas de procesamiento de texto. Puedes hacer clic en una cookie para abrirla. A continuación, se indica una lista de enlaces sobre cómo ver cookies en diferentes navegadores. Si utilizas otro navegador, consulte la información sobre cookies en el propio navegador. Si utilizas un teléfono móvil, consulta el manual del dispositivo para obtener más información.

*   Firefox: [https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer](https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer)
*   Chrome: [https://support.google.com/chrome/bin/answer.py?hl=en&answer=95647&topic=14666&ctx=topic](https://support.google.com/chrome/bin/answer.py?hl=en&answer=95647&topic=14666&ctx=topic)
*   Internet Explorer 8-10: [http://windows.microsoft.com/en-US/internet-explorer/delete-manage-cookies](http://windows.microsoft.com/en-US/internet-explorer/delete-manage-cookies)
*   Safari: [http://support.apple.com/kb/ph5042](http://support.apple.com/kb/ph5042)
*   Opera: [http://help.opera.com/Windows/12.00/es-ES/cookies.html](http://help.opera.com/Windows/12.00/es-ES/cookies.html)

**Configuración de _cookies_ para los navegadores más populares**

A continuación te indicamos cómo acceder a una _cookie_ determinada del navegador **Chrome**. Nota: estos pasos pueden variar en función de la versión del navegador:

1.  Ve a Configuración o Preferencias mediante el menú Archivo o bien pinchando el icono de personalización que aparece arriba a la derecha.
2.  Verás diferentes secciones, pincha la opción _Mostrar opciones avanzadas_.
3.  Ve a _Privacidad_, _Configuración de contenido_.
4.  Selecciona _Todas las cookies y los datos de sitios_.
5.  Aparecerá un listado con todas las _cookies_ ordenadas por dominio. Para que te sea más fácil encontrar las _cookies_ de un determinado dominio introduzca parcial o totalmente la dirección en el campo _Buscar cookies_.
6.  Tras realizar este filtro aparecerán en pantalla una o varias líneas con las _cookies_ de la web solicitada. Ahora sólo tienes que seleccionarla y pulsar la _X_ para proceder a su eliminación.

Para acceder a la configuración de _cookies_ del navegador **Internet Explorer** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Ve a _Herramientas_, _Opciones de Internet_
2.  Haz clic en _Privacidad_.
3.  Mueve el deslizador hasta ajustar el nivel de privacidad que desees.

Para acceder a la configuración de _cookies_ del navegador **Firefox** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Ve a _Opciones_ o _Preferencias_ según tu sistema operativo.
2.  Haz clic en _Privacidad_.
3.  En _Historial_ elige _Usar una configuración personalizada para el historial_.
4.  Ahora verás la opción _Aceptar cookies_, puedes activarla o desactivarla según tus preferencias.

Para acceder a la configuración de _cookies_ del navegador **Safari para OSX** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Ve a _Preferencias_, luego _Privacidad_.
2.  En este lugar verás la opción _Bloquear cookies_ para que ajuste el tipo de bloqueo que deseas realizar.

Para acceder a la configuración de _cookies_ del navegador **Safari para iOS** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Ve a _Ajustes_, luego _Safari_.
2.  Ve a _Privacidad y Seguridad_, verás la opción _Bloquear cookies_ para que ajuste el tipo de bloqueo que deseas realizar.

Para acceder a la configuración de _cookies_ del navegador para dispositivos **Android** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Ejecuta el navegador y pulsa la tecla _Menú_, luego _Ajustes_.
2.  Ve a _Seguridad y Privacidad_, verás la opción _Aceptar cookies_ para que active o desactive la casilla.

Para acceder a la configuración de _cookies_ del navegador para dispositivos **Windows Phone** sigue estos pasos (pueden variar en función de la versión del navegador):

1.  Abre _Internet Explorer_, luego _Más_, luego _Configuración_
2.  Ahora puedes activar o desactivar la casilla _Permitir cookies_.

**Notas adicionales**

*   Ni esta web ni sus representantes legales se hacen responsables ni del contenido ni de la veracidad de las políticas de privacidad que puedan tener los terceros mencionados en esta política de _cookies_.
*   Los navegadores web son las herramientas encargadas de almacenar las _cookies_ y desde este lugar debe efectuar su derecho a eliminación o desactivación de las mismas. Ni esta web ni sus representantes legales pueden garantizar la correcta o incorrecta manipulación de las _cookies_ por parte de los mencionados navegadores.
*   En algunos casos es necesario instalar _cookies_ para que el navegador no olvide tu decisión de no aceptación de las mismas.
*   En el caso de las _cookies_ de Google Analytics, esta empresa almacena las _cookies_ en servidores ubicados en Estados Unidos y se compromete a no compartirla con terceros, excepto en los casos en los que sea necesario para el funcionamiento del sistema o cuando la ley obligue a tal efecto. Según Google no guarda su dirección IP. Google Inc. es una compañía adherida al Acuerdo de Puerto Seguro que garantiza que todos los datos transferidos serán tratados con un nivel de protección acorde a la normativa europea.
*   Para cualquier duda o consulta acerca de esta política de _cookies_ no dudes en comunicarte con nosotros a través de la sección de contacto.

**Derechos de propiedad intelectual e industrial**

Mediante estas Condiciones Generales no se cede ningún derecho de propiedad intelectual o industrial sobre el portal Código Carnaval ni sobre ninguno de sus elementos integrantes, quedando expresamente prohibidos al Usuario la reproducción, transformación, distribución, comunicación pública, puesta a disposición del público, extracción, reutilización, reenvío o la utilización de cualquier naturaleza, por cualquier medio o procedimiento, de cualquiera de ellos, salvo en los casos en que esté legalmente permitido o sea autorizado por el titular de los correspondientes derechos.

El usuario conoce y acepta que la totalidad del sitio web, conteniendo sin carácter exhaustivo el texto, las imágenes, los diseños,  software, contenidos (incluyendo estructura, selección, ordenación y presentación de los mismos), material audiovisual y gráficos, está protegida por marcas, derechos de autor y otros derechos legítimos registrados, de acuerdo con los tratados internacionales en los que España es parte y otros derechos de propiedad y leyes de España.

En el caso de que un usuario o un tercero consideren que se ha producido una violación de sus legítimos derechos de propiedad intelectual por la introducción de un determinado contenido en Código Carnaval, deberá notificar dicha circunstancia a nuestra web indicando:

*   Datos personales del interesado titular de los derechos presuntamente infringidos, o indicar la representación con la que actúa en caso de que la reclamación la presente un tercero distinto del interesado.

Señalar los contenidos protegidos por los derechos de propiedad intelectual y su ubicación en Código Carnaval, la acreditación de los derechos de propiedad intelectual señalados y declaración expresa en la que el interesado se responsabiliza de la veracidad de las informaciones facilitadas en la notificación.

**Enlaces Externos**

Las páginas del sitio web Código Carnaval proporcionan enlaces a otros sitios web propios y contenidos que son propiedad de terceros la de fabricantes o proveedores.

El único objeto de los enlaces es proporcionar al Usuario la posibilidad de acceder a dichos enlaces y conocer nuestros productos, aunque Bisnis no se responsabiliza en ningún caso de los resultados que puedan derivarse al usuario por acceso a dichos enlaces.

El usuario que se proponga establecer cualquier dispositivo técnico de enlace desde su sitio web al portal Código Carnaval deberá obtener la autorización previa y escrita de Código Carnaval.

El establecimiento del enlace no implica en ningún caso la existencia de relaciones entre Código Carnaval y el propietario del sitio en el que se establezca el enlace, ni la aceptación o aprobación por parte de Código Carnaval de sus contenidos o servicios.

**Otras condiciones de uso de este sito web**

El usuario se compromete a hacer un uso diligente del sitio web y de los servicios accesibles desde el mismo, con total sujeción a la Ley, a las buenas costumbres y al presente aviso legal.

Asimismo, se compromete, salvo autorización previa, expresa y escrita de Código Carnaval a utilizar la información contenida en el sitio web, exclusivamente para su información, no pudiendo realizar ni directa ni indirectamente una explotación comercial de los contenidos a los que tiene acceso.

Este sitio almacena un fichero de datos relativos a los comentarios enviados a este sitio. Podrá ejercitar sus derechos de acceso, rectificación, cancelación u oposición mediante un envío de un correo electrónico a la dirección codigocarnaval(arroba)gmail.com.

Este sitio, los dominios asociados y la propiedad del contenido pertenecen a Código Carnaval (Josefa Soriano Vargas)., NIF 48899963P, con domicilio en Callejón del Espino número 5 de Chiclana de la Frontera, Cádiz, España.

Este sitio web contiene hiperenlaces que conducen a otras páginas web gestionadas por terceros ajenos a nuestra organización. Código Carnaval no garantiza ni se hace responsable del contenido que se recoja en dichas paginas web.

Salvo autorización expresa, previa y por escrito de Código Carnaval, queda terminantemente prohibida la reproducción, excepto para uso privado, la transformación, y en general cualquier otra forma de explotación, por cualquier procedimiento, de todo o parte de los contenidos de este sitio web.

Queda terminantemente prohibido realizar, sin el previo consentimiento de Código Carnaval cualquier manipulación o alteración de este sitio web. Consecuentemente, Código Carnaval no asumirá ninguna responsabilidad derivada, o que pudiera derivarse, de dicha alteración o manipulación por terceros.

**Ejercicio de derechos ARCO**

Podrás ejercitar, respecto de los datos recabados, los derechos reconocidos en la Ley Orgánica 15/1999, de acceso, rectificación o cancelación de datos y oposición. Por ello te informo que podrás ejercer dichos derechos mediante solicitud escrita y firmada que podrá enviar, junto con fotocopia de tu DNI o documento identificativos equivalente, al domicilio postal de Josefa Soriano Vargas., NIF 48899963P, en Callejón del Espino número 5 de Chiclana de la Frontera, Cádiz, España o por correo electrónico, adjuntado fotocopia de DNI a: codigocarnaval(arroba)gmail.com.  Antes de los 10 días responderemos a tu solicitud para confirmarte la ejecución del derecho que hayas solicitado ejercer.

**Exclusión de garantías y responsabilidad**

Código Carnaval no otorga ninguna garantía ni se hace responsable, en ningún caso, de los daños y perjuicios de cualquier naturaleza que pudieran traer causa de:

*   La falta de disponibilidad, mantenimiento y efectivo funcionamiento de la web o de sus servicios y contenidos;
*   La existencia de virus, programas maliciosos o lesivos en los contenidos;
*   El uso ilícito, negligente, fraudulento o contrario a este Aviso Legal;
*   La falta de licitud, calidad, fiabilidad, utilidad y disponibilidad de los servicios prestados por terceros y puestos a disposición de los usuarios en el sitio web.

Código Carnaval no se hace responsable bajo ningún concepto de los daños que pudieran dimanar del uso ilegal o indebido del presente sitio web.

**Plataforma Europea de resolución de litigios en línea**

La Comisión Europea facilita una plataforma de resolución de litigios en línea que se encuentra disponible en el siguiente enlace: [http://ec.europa.eu/consumers/odr/](http://ec.europa.eu/consumers/odr/). Los consumidores podrán someter sus reclamaciones a través de la plataforma de resolución de litigios en línea

**Ley aplicable y jurisdicción**

Con carácter general las relaciones entre Código Carnaval con los usuarios de sus servicios telemáticos, presentes en este sitio web, se encuentran sometidas a la legislación y jurisdicción españolas.

**Siempre estaremos localizables: Nuestro contacto**

En caso de que cualquier usuario tuviese alguna duda acerca de estas condiciones legales o cualquier comentario sobre el portal Código Carnaval, por favor dirígete a codigocarnaval(arroba)gmail.com o utiliza [el formulario de contacto disponible en el sitio web](https://www.codigocarnaval.com.com/contacto/).

Nuestra política de privacidad describe como recogemos, guardamos o utilizamos la información que recabamos a través de los diferentes servicios o páginas disponibles en este sitio. Es importante que entienda que información recogemos y como la utilizamos ya que el acceso a este sitio implica la aceptación nuestra política de privacidad.

**Aceptación y consentimiento**

El usuario declara haber sido informado de las condiciones sobre protección de datos de carácter personal, aceptando y consintiendo el tratamiento de los mismos por parte de Código Carnaval, en la forma y para las finalidades indicadas en la presente política de privacidad.

**Correos comerciales**

De acuerdo con la legislación vigente, Código Carnaval no realiza prácticas de SPAM, por lo que no envía correos comerciales por vía electrónica que no hayan sido previamente solicitados o autorizados por el usuario. En consecuencia, en cada uno de los formularios habidos en Código Carnaval, el Usuario tiene la posibilidad de dar su consentimiento expreso para recibir nuestra Newsletter/boletín, con independencia de la información comercial puntualmente solicitad
