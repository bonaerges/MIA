Title: ▷ Dónde ver el COAC en DIRECTO 2024 - Todas las opciones

URL Source: https://www.codigocarnaval.com/coac-directo-online/

Published Time: 2019-10-15T11:31:17+02:00

Markdown Content:
En este artículo te vamos a contar todas las opciones para seguir el **COAC en directo** a través de las diferentes plataformas de televisión, internet y radio.

¿Te gustaría seguir el concurso de agrupaciones del Carnaval de Cádiz? No importa donde estés, aquí podrás seguir todo el **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)** íntegro en directo por las diferentes plataformas.

**Preliminares 2024 – Función 17**

Horarios y dónde ver por TV y online el COAC 2024
-------------------------------------------------

### Onda Cádiz TV

A través de **Onda Cádiz TV** podrás seguir el concurso del Gran Teatro Falla **de manera íntegra**, desde la fase de preliminares hasta la Gran Final que se celebra el 9 de febrero.

Todas las funciones comenzarán a partir de las **20:00h** y se podrán seguir tanto en televisión, como en las diferentes plataformas de internet como YouTube, Twitch o radio.

#### 📺 Televisión

*   **TDT:** Canal 38 (frecuencia)
*   **Vodafone TV:** Canal 702 (Provincia de Cádiz)

#### 💻 Internet

*   En streaming a través de **Livestream** en **[Onda Cádiz Digital](https://tv.ocadizdigital.es/tv/directo)**
*   En directo a través del canal **Youtube** ‘**[Onda Cádiz Carnaval](https://www.youtube.com/channel/UCpOz3CN6mDlxkE7-m5AS1aQ)**‘
*   En directo a través del canal de **Twitch** ‘**[Onda Cádiz TV](http://www.twitch.tv/ondacadiztv)**‘

#### 📻 Radio

*   En FM a través del dial **92.8**
*   En internet a través de **Onda Cádiz Radio**

Horario y dónde ver los cuartos de final del COAC 2024
------------------------------------------------------

Los **cuartos de final** del Carnaval de Cádiz 2024 se llevarán a cabo entre el **26 y el 1 de febrero**, comenzando a partir de las 20:00h en el Gran Teatro Falla.

Además de por Onda Cádiz TV, Canal Sur emitirá la fase de cuartos de final.

### Canal Sur

La cadena andaluza retransmitirá la fase de cuartos de final a través de su segundo canal (**ATV**) en televisión.

En formato digital, la cadena de contenidos ‘**Canal Sur Más**‘ también emitirá el concurso por internet.

Horario y dónde ver las Semifinales del COAC 2024
-------------------------------------------------

Las semifinales del COAC 2024 tendrán lugar entre el **4 y 7 de febrero**. Comenzarán en directo a partir de las 20:00h desde el Gran Teatro Falla.

#### 📺 Televisión

Podrás seguir el concurso a través de **Onda Cádiz TV** o por **Canal Sur TV**, en su primer canal, ambos en riguroso directo.

#### 💻 Internet

Si quieres seguir las semifinales a través de internet, el **canal YouTube de Onda Cádiz**, así como su página web emitirán el COAC en directo. Mientras, Canal Sur lo hará a través de su plataforma ‘**Canal Sur Más**‘.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

Horario y dónde ver la Final del COAC 2024
------------------------------------------

La Gran Final del Falla 2024 se emitirá en directo tanto a través de **Canal Sur TV** como por **Onda Cádiz TV** en su formato televisivo.

La Gran Final se celebrará el **9 de febrero** a partir de las 20:00h en el Gran Teatro Falla.

Si quieres seguirla a través de internet, nuevamente, como en semifinales puedes usar en el **canal YouTube de Onda Cádiz**, su web o la plataforma ‘**Canal Sur Más**‘.

📻 COAC 2024 en directo por radio
---------------------------------

También es posible seguir el concurso del Gran Teatro Falla a través de las emisoras de radio que emiten online. Así, sentirás el COAC como si estuvieras allí y no te perderás ningún detalle.

**Canal Sur Radio:** 96.2 FM – **[ESCUCHAR](http://www.canalsur.es/radio/directos/p-2021.html?directo=player_csr_cadiz)**

**Cadena SER Cádiz:** 90.8 FM – **[ESCUCHAR](http://play.cadenaser.com/emisora/radio_cadiz/)**

**Onda Cero Cádiz:** 101.4 FM – **[ESCUCHAR](https://www.ondacero.es/emisoras/andalucia/cadiz/directo/)**

**Cadena COPE Cádiz:** 102.0 FM – **[ESCUCHAR](http://www.cope.es/directos/cadiz)**
