Title: Las mejores FRASES CARNAVAL DE CÁDIZ ✅ - Recopilatorio

URL Source: https://www.codigocarnaval.com/frases-carnaval-de-cadiz/

Published Time: 2019-10-09T11:37:55+02:00

Markdown Content:
Las frases Carnaval de Cádiz siempre nos dejan esa pequeña espina en la conciencia que nos enamora, que nos llega hasta el alma y grabamos a fuego en nuestra memoria, incluso en nuestra piel.

Queremos recopilar todas esas frases, que en un momento u otro nos han hecho estremecer gracias al carnaval.

Si quieres, puedes colaborar con nosotros mandándonos tu frase preferida, a través de un comentario en la página, o de un correo electrónico.

Frases al amor
--------------

> «**La sonrisa es un te quiero, que da calambre en el alma**«
> 
> Juan Carlos Aragón – Los Mafiosos

* * *

> **«Dicen que el día que se descubrió el amor, el hombre primero que lo encontró también encontró la locura»**  
> 
> Tino Tovar – Volver a empezar

* * *

> **«Hombre cobarde no conquista mujer bonita»**
> 
> Antonio Martínez Ares – Los Cobardes

* * *

> **«Por si pasado el tiempo el verde incandescente de tus ojos sigue ardiendo en la última estación y sin quedar ninguna espina agarradita a la mano me diga, cuánto nos hemos querido»**
> 
> Germán Rendón – OBDC, el show de Pinocchio

* * *

> **«La que jala de mí cuando caigo y me impide tirar la toalla, la que me agarra del corazón y levanta su voz junto a mí en la batalla»**
> 
> Jesús Bienvenido – Los Imprescindibles

* * *

> **«Dicen que amores que matan, dicen que son para siempre. Y eso tiene que ser verdad porque a mi me estás matando y yo no quiero estar vivo si te tengo que olvidar»**
> 
> Tino Tovar – El Espíritu de Cádiz

* * *

> **«La sonrisa en las paredes, enseguida lo noté, le dí un beso enorme y ese día fui más hombre por ser ella más mujer»**
> 
> Antonio Martínez Ares – Los Piratas

* * *

> **«Como una noria, la vida pasa y te prometo vida mía que ya cuento hasta los días que me pierdo tu sonrisa»**
> 
> José Luis Bustelo – La Construcción

* * *

> **«Si tú fuistes mi locura, yo fui sin pensarlo tu primer amor»**
> 
> Hermanos Carapapa – Los Chatarra

* * *

> **«Yo me enamoré de tí, por culpa de los carnavales»**
> 
> Juan Carlos Aragón – 1800 Los Inmortales

> **«La pantera de un pantera, tiene que ser diferente, peligrosa, liberal, valiente y que luche como él»**
> 
> Juan Carlos Aragón – Los Panteras

> **«Yo no sé, como se puede querer, acabada de nacer a tan poquita cosa»**
> 
> Joaquín Quiñones – La Caldera

📣 **EL MEJOR COMPARADOR DE ALOJAMIENTOS EN CÁDIZ 🔍  
**Si quieres encontrar el mejor precio para tu estancia, consulta el **[comparador de alojamientos en Cádiz](https://www.hotelscombined.es/Place/Cadiz.htm?a_aid=178580)**. Miles de estancias (hoteles, apartamentos, hostales) para que encuentres el más barato y cómodo.

> **«Con más amantes que amores qué contradicción, yo no lo entiendo pero es que te quiero, como no voy a venir, como no voy a cantar, como no voy a ser tu prisionero»**
> 
> Miguel Ángel García Argüez – Los Prisioneros

* * *

>   
> **«Celos, yo tengo celos que me envenenan cuando gritan a los vientos que eres la novia del mar. Tengo una novia señores, que tan sólo con mirarla va robando corazones»**
> 
> Juanma Braza ‘Sheriff’ – Los Valientes

* * *

> **«En mi delirio suena mi guitarra que vuelve a llamarte, me vuelvo loco y conmigo mismo empiezo a pelearme, pues me recuerdan que es que ya no puedo vivir sin cantarte»**
> 
> Hermanos Carapapa – La Azotea

* * *

>   
> **«Qué bonita es Cádiz por la tarde, cuando miro al solecito, que se viene pal’ fresquito con la marea»**
> 
> José Luis Bustelo – Los Acuarela

* * *

> **«Me han dicho que la locura es una enfermedad tan típica de Cádiz que los gaditanos que no la padecen nunca van al cielo»**
> 
> Juan Carlos Aragón – Los Ángeles Caídos

* * *

> **«Te quiero como una madre, te adoro como una novia, te amo como una mujer, los sentimientos me sobran, que a una mujer para amarla sobran to los sentimientos, basta con un mandamiento: No maltratarla, no maltratarla»**
> 
> Antonio Martín – La mare que me parió

* * *

> **«Silencio, silencio, silencio…que esto es Cai Cai. Si no se te levanta el vello esto es lo que hay»**
> 
> Joaquín Quiñones – Los Vikingos

* * *

> **«Que estás pisando Tierra Santa, desde la Viña hasta Cruz Verde y Callejones»**
> 
> Juan Carlos Aragón – Los Millonarios

Frases de Carnaval
------------------

> **«Creo en tí, oh todopoderoso Carnaval de Cádiz»**
> 
> Juan Carlos Aragón – Los Peregrinos

* * *

>   
> **«La biblia de los gaditanos, historias cantás por su gente, no están en ningún museo, pero yo las tarareo, eternamente, eternamente, eternamente»**
> 
> Antonio Martínez Ares – La Eternidad

* * *

>   
> **«Toma el 3×4, toma nuestras voces, que mi 3×4 siempre acaba en 12»**
> 
> Miguel Ángel García Argüez – Los Doce

* * *

>   
> **«Carnaval bendito, carnaval maldito. Carnaval te odio y te necesito»**
> 
> Antonio Martínez Ares – Los Cobardes

* * *

> **«Estos dos coloretes me los pintó en los cachetes el mismo sol que a la caleta le da el dorao»**
> 
> Paco Cárdenas y Ramón Peñalver – Los Caballeros de la Edad Media

* * *

>   
> **«Piérdase por Cádiz, piérdase por la tacita que con esta luz bendita todas las fotos te saldrán bonitas»**
> 
> Juanma Braza ‘Sheriff’ – Los Revelaos

* * *

>   
> **«Doce mesecitos mi corazón carnavaleando, nos dejó en herencia un dios divino a los gaditanos»**
> 
> Miguel Ángel García Argüez – Los Doce

* * *

> **«De que vale mi fortuna con la plata que hay aquí, y es que no es literatura que hasta el sol viene a morir»**
> 
> Paco Cárdenas y Ramón Peñalver – Los Agarraos

Frases de inspiración
---------------------

> **«Ay mi soledad, hemos cruzado tantas ciénagas los dos, tantos secretos que no podemos contar, tantas palabras que dirían que es amor»**
> 
> Juan Carlos Aragón – La Banda del Capitán Veneno

Frases célebres
---------------

> **«Con permiso buenas tardes, vengo pa’ que me detengan»**
> 
> Antonio Martínez Ares – Los Piratas

* * *

> **«Iba por Canalejas, por la acera del muelle, con una risa que me llegaba de oreja a oreja»**
> 
> Chirigota ‘El que la lleva la entiende’

* * *

> **«Que sueño y que flojera ojú me esta entrando a mi… Como yo me acueste no me levanto ni pa’ dormir»**
> 
> Chirigota ‘Los Juancojones’

* * *

> **«Me han dicho que el amarillo, está maldito pa’ los artistas y ese color sin embargo es gloria bendita para los cadistas»**
> 
> Manolo Santander – La Familia Pepperoni

Frases a la amistad
-------------------

> **«Un amigo-amigo de verdad no dice quiero ser tu amigo, pero si es tu amigo de verdad tu muerte la muere contigo»**
> 
> Juan Carlos Aragón – Los Condenaos

* * *

> **«Quédate conmigo tú que eres amigo, tú que me conoces, tu que me eres fiel. Quédate conmigo y bébete otra copa que quiero contarte que anoche lloré»**
> 
> Tino Tovar – Las Estaciones

* * *

>   
> **«Hoy me quiero emborrachar, con la mitad de mis amigos, y acordarme de la otra mitad, porque también han sido, mis amigos de verdad, y aunque al final se me hayan ido, no por ello me olvido, aun sabido que no volverán»**
> 
> Juan Carlos Aragón – 1800 Los Inmortales

* * *

>   
> **«Un perro es el amigo más leal, un perro es un caballero, quien tiene un perro sabe que tendrá mientras viva un compañero»**
> 
> Miguel Ángel García Argüez – El último escuadrón

* * *

>   
> **«La amistad tiene la llave del beso y del abrazo y nada pide, todo lo da. No se imponen condiciones ni privilegios porque el mayor privilegio es la amistad»**  
> 
> Jesús Bienvenido – Los Trasnochadores
