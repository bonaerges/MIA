Title: Nombres agrupaciones 2025 - COAC 2025 (101% actualizado)

URL Source: https://www.codigocarnaval.com/coac-2025/nombres-agrupaciones-2025/

Published Time: 2024-03-04T10:13:46+01:00

Markdown Content:
[Inicio](https://www.codigocarnaval.com/) » [COAC-2025](https://www.codigocarnaval.com/category/coac-2025/) » Nombres agrupaciones 2025

Como es habitual, un año más ya comenzamos a saber los **nombres agrupaciones 2025** para el **COAC 2025**.

Como siempre, os ofrecemos el listado de las agrupaciones que han ido confirmando de manera oficial el nombre de su proyecto y su participación en el concurso.

Seguro que tienes muchas preguntas, ¿Cuál será el nombre de la **chirigota del Selu 2025**? o ¿Cuál será el proyecto de **comparsa Martínez Ares 2025**?

Agrupaciones Adultos 2025 – Adultos
-----------------------------------

### Comparsas 2025

*   **Los Humanos** (Martínez Ares / Cádiz) – En 2024: **[La oveja negra](https://www.codigocarnaval.com/coac-2024/la-oveja-negra/)**
*   **El Cementerio** (Jonathan Pérez / Cádiz) – En 2024: **[Los Sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   **El otro barrio** (Sergio Guillén ‘Tomate’ y Antonio ‘Piru’ / Cádiz) – En 2024: **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   **Des-OBDC** (Germán Rendón / Cádiz) – En 2024: **[Donde fuimos felices](https://www.codigocarnaval.com/coac-2024/donde-fuimos-felices/)**
*   **La Majadería** (Manolín Santander / Cádiz) – En 2024: **[Las Herederas](https://www.codigocarnaval.com/coac-2024/las-herederas/)**
*   **Cadizfrenia** (Andrés Morales / Cádiz) – En 2024: **[Los Amuletos](https://www.codigocarnaval.com/coac-2024/los-amuletos/)**
*   **La casa de las ilusiones** (J. Antonio Jiménez y Antonio M. Malia / Algeciras) – En 2024: **[El Apotecario](https://www.codigocarnaval.com/coac-2024/el-apotecario/)**
*   **Desde mi mundo** (Alejandro Arteaga y Rafael Delis / Sevilla) – En 2024: **[El barrio calavera](https://www.codigocarnaval.com/coac-2024/el-barrio-calavera/)**
*   **Puente de Plata** (Enrique Rojas y Nicolás Quintero / Chiclana) – Nueva agrupación

### Chirigotas 2025

*   **Los Desconfiaos** (Chirigota de los Villegas / Cádiz) – En 2024: **[Los exageraos](https://www.codigocarnaval.com/coac-2024/los-exageraos/)**
*   **Los hipocampo der sú** (Jose María Barranco ‘El Lacio’ / Cádiz) – En 2023: **[La chirigota del Lazio](https://www.codigocarnaval.com/coac-2023/la-chirigota-del-lazio/)**
*   **Los inhumanos** (Victor Jurado y Miguel A. Ríos / Cádiz) – En 2024: **[Carnaval me cago en tus muertos](https://www.codigocarnaval.com/coac-2024/carnaval-me-cago-en-tus-muertos/)**
*   **Verde que te quiero verde** (Juanma Bocuñano y Javi ‘El Ojo’ / San Fernando) – En 2024: **[Anonymous Gaditano](https://www.codigocarnaval.com/coac-2024/anonymous-gaditano/)**
*   **Pa rebeldía mi poesía po cógela que es mía** (Moisés Serrano y El Lacio / Cádiz) – Nueva agrupación

### Coros 2025

*   Aún no han anunciado nombres

### Cuartetos 2025

*   Aún no han anunciado nombres

* * *

Agrupaciones Juveniles 2025
---------------------------

### Chirigotas juveniles 2025

*   **Los 12 hijos de Juan** (Moisés Hermida y Juanmi Gay) – Nueva agrupación

* * *

Agrupaciones Infantiles 2025
----------------------------

### Comparsas infantiles 2025

*   **Los del huerto** (Asociación Cantera de El puerto de Santa María) – En 2024: Los Discípulos
*   **La Centinela** (Antonio Guerrero ‘Piojo Chico’ / Cádiz) – En 2024: Si yo te contara

### Cuartetos infantiles 2025

*   **IA,IA,IA. Que bonita Andalus-IA**(Asociación Cantera de El puerto de Santa María) – Nueva agrupación

### Chirigotas infantiles 2025

*   **Los trataratachín** – En 2024: Los indigestos
*   **Este año lo partimos tó** (Asociación Cantera de El puerto de Santa María) – Nueva agrupación
