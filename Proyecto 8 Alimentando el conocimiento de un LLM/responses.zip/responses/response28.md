Title: COROS 2024 ▷ Carnaval de Cádiz

URL Source: https://www.codigocarnaval.com/coac-2024/coros-2024/

Published Time: 2023-11-15T13:45:55+01:00

Markdown Content:
[Inicio](https://www.codigocarnaval.com/) » [COAC-2024](https://www.codigocarnaval.com/category/coac-2024/) » Coros 2024

1 diciembre, 202315 noviembre, 2023

Bienvenidos al apartado de coros 2024 del Carnaval de Cádiz. Aquí podrás acceder a las fichas de cada agrupación pulsando en su fotografía.

En ellas podrás disfrutar de su previa antes del concurso y los vídeos de sus actuaciones completas en las diferentes fases del COAC 2024 en el Gran Teatro Falla.

#### Sobre el COAC 2024

* * *

Coros COAC 2024
---------------

* * *
