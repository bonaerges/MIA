Title: Agrupaciones Callejeras - Codigo Carnaval

URL Source: https://www.codigocarnaval.com/agrupaciones-callejeras/

Published Time: 2024-01-29T12:41:01+01:00

Markdown Content:
Las **agrupaciones callejeras** son uno de los símbolos más representativos del Carnaval de Cádiz.

Durante la semana de carnaval, un gran número de agrupaciones que no participa en el concurso prepara sus repertorios para ofrecerlos en las calles de Cádiz con un gran ingenio, humor, doble sentido e ironía.

*   Puedes consultar aquí toda la información sobre los **[Romanceros del Carnaval de Cádiz](https://www.codigocarnaval.com/romanceros/)**

Listado agrupaciones Callejeras 2024
------------------------------------

Lista de agrupaciones callejeras o ilegales que nos podremos encontrar por las calles de Cádiz en la semana de Carnaval 2024.

*   **¡Cuéntame!** – (Chirigota callejera del Pedri) – (en 2023: Te la vamos a clavar)
*   **A:C:A:I: Loving you…** – (Chirigota callejera de Cádiz) – (en 2023: Yes, we fuck)
*   **Abatar, desavío en el espacio** – (Dúo callejero de Cádiz) – (en 2023: **[Si me querei venirse](https://www.youtube.com/watch?v=kC34CHOSijA)**)
*   **Ahí va el peorcito del Puerto** – (Chirigota callejera de Sevilla) – (en 2023: Los incurables. Unos curas sin cura y una Virgen sin-vergüenza)
*   **A morir que son dos días** – (Chirigota de Juan Osorio) – (en 2023: La última y nos vamos)
*   **Asociación de apicultores, El cambio climático lo arreglo yo por mis cojones** -(en 2023: Cumpleaños senil, los centena)
*   **Cadi, la ex-novia del mar** (Chirigota Las Coñetas) – (en 2023: **[Callejera Street Fighter](https://www.youtube.com/watch?v=cF9QlZymT1o&pp=ygUYY2FsbGVqZXJhIHN0cmVldCBmaWdodGVy)**)
*   **Casi todo sobre la Koki** – (La chirigota de la Koki) – (en 2023: Dos diosas ateas Minerva y Atenea vienen buscando pelea)
*   **De venta en venta** – (Chirigota de las Tubio) – (en 2023: Cádiz en salsa)
*   **El cambio climático** – (Chirigota callejera de Cádiz) – (en 2023: La toma de la pastilla)
*   **El cielo puede esperar** – (Chirigota callejera de Cádiz) – (en 2023: Las que vienen con alegría)
*   **El ditero** – (La callejera de Los invisibles) – ( en 2023: Los del tribunal suprimo)
*   **El tirano** – (La miniparsa callejera de Cádiz) – (en 2023: La partida)
*   **Er coño tu prime** – (Carlos Meni) – (en 2023: **[La recogia](https://www.youtube.com/watch?v=grGZu2fwPrA)**)
*   **Fuga de cerebros** – (Chirigota callejera de Benalup-Casas Viejas) – (en 2023: La chirigota del negrito)
*   **Gracias por su visita** – (Chirigota callejera de Alex de Alba) – (en 2023: Cuidado con la derecha)
*   **Héroes del silencio** – (Chirigota de los Gañotti) – (en 2023: Tostón 4)
*   **Intocables** – (Los niños de la cueva) – (en 2023: Los muertos del furbo)
*   **Junts per Cadi** – (en 2023: Muertecita gaditana)
*   **La chirigota de cuéntame** – (en 2022: Verano azul)
*   **La clinica privada del Sr. Potato** – (Chirigota callejera de Cádiz) – (en 2023: **[Los cocos](https://www.youtube.com/watch?v=1NcYJoTvGHU)**)
*   **Las abbas clonás** – (Chirigota callejera de Cádiz) – (en 2023: La magna)
*   **Las adolfas** – (Chirigota We Can Do) – (en 2023: **[Las Musas](https://www.youtube.com/watch?v=nvlBqyOz6rQ&list=PLsSvWXfNFryOAcN6gYYyAVJylJYkTi3W_&pp=gAQBiAQB)**)
*   **Las barbitúricas** – (Chirigota ‘Las del carrito’) – (en 2023: La urtima y nos vamo)
*   **Las casi guapas** – (Chirigota Callejera de Cádiz) – (en 2023: Último cartucho)
*   **Las cuentacuentos** – (Chirigota callejera feminista de Sevilla) – (en 2023: Las equidistantes)
*   **Las lady DYC Diana de Ilegales** – (Chirigota Madre Coraje) – (En 2023: Las malas madres)
*   **Las Macgregor del Carnaval** – (Chirigota callejera) – (En 2023: Las majorís)
*   **Las sicarias** – Chirigota de nueva creación
*   **Las sin filtro, (Chirigota Cadiwoman 1954)** – (Chirigota callejera Las Cadiwoman) – (en 2023: **[Las Spice del padrón unas pican y otras no](https://www.youtube.com/watch?v=AEJ2s4rksLs)**)
*   **Los autognomos** – (Chirigota callejera de Mairena del Aljarafe) – (en 2023: Los carajotes del capirote)
*   **Los vaciletas de la caleta** – (Chirigota las Achicharrás) – (en 2023: Las achicharrás)
*   **Los bacardí** – (El Showmancero) – (en 2023: **[La tribu de los indios gaditas](https://www.youtube.com/watch?v=0lnREUY4h9I)**)
*   **Los becarios del telediario** – (Chirigota del AIRON) – (en 2023: **[Los llorones](https://www.youtube.com/watch?v=GHR5bU9zgsk)**)
*   **Los bronquitis** – (La ilegal de castilleja) – (en 2023: Vuelvo a KADI CITY , una chirigota de sofá)
*   **Los del año catapún** – (La Chirigota del Garfi) – (en 2023: Los enganchaos)
*   **Los expertos en bolas chinas** – (La chirigota del Wachi) – (en 2023: Entre quejas)
*   **Los hipnotizadores** – (Chirigota del Osorio) – (en 2023: Salon Restaurante el fiambre, por si te quedas con hambre)
*   **Los hombres Ñu, el Ñusical** – (Chirigota del Chano) – (en 2023: Los del bajo D)
*   **Los lisántropos** – (Chirigota del Ukelele) – (en 2023: **[Los chamanes del marquesado](https://www.youtube.com/watch?v=dektCDThPZw)**)
*   **Los Luis Rubiales** – (Chirigota callejera de Cádiz) – (en 2022: Los Boris Johnson)
*   **Los metemierdas** – (Chirigota callejera de Jerez) – (en 2023: El guarromántico)
*   **Los mierdas lerendas** – (La Chirigota Absurda) – (en 2023: We can’t ¡Ojú! Carnaval)
*   **Los Otakus** – (Chirigota Cuqui de Cádiz) – (en 2023: **[Esto ya ha salio](https://www.youtube.com/watch?v=zrTCX88utrs)**)
*   **Los peritos** – (Chirigota callejera ‘Sin ánimo de Luto’) – (en 2023: La guantá invisible)
*   **Los petacabras** – (La chirigota de los Mancilla) – (en 2023: Los curo)
*   **Los pone pegas** – (Chirigota callejera de Puerto Real) – (en 2023: Los enredados)
*   **Los psicoanalístas se la dan de artistas** – (Chirigota callejera del perchero) (Cádiz) – (en 2023: **[De medieval en peor](https://www.youtube.com/watch?v=dEQGyLahqeA)**)
*   **Los que fueron a Woodstock y todavia estan a gusto** – (Chirigota callejera Rockera de Cádiz) – ( en 2023: **[Espartaco y los que meten el taco](https://www.youtube.com/watch?v=mSu-SdQObZM)**)
*   **Los que se quedaron tan pancho** – (Coro callejero) – (en 2023: Los tercios de Frade)
*   **Los que sueltan agüilla** – (Chirigota callejera del Parchís) – (en 2023: Los que se jartan despacio)
*   **Los refugiaos** – (Chirigota los refugiaos)
*   **Los saturdainai** – (Chirigota  romancero de Cádiz) – (en 2023: Countri + mejón)
*   **Los Secos del Rocío** (Grupo Daddy Cadi) – (en 2023: **[La chirigota del Barranco](https://www.codigocarnaval.com/coac-2023/la-chirigota-del-barranco/)**)
*   **Los Sharklantanes** – (Chirigota callejera de Cádiz) – (en 2023: La fiesta de los primos)
*   **Los teleoperadores** – (Chirigota callejera Mencantajeré) – (en 2023: Juego de tonos)
*   **Los tercios españoles** – (Chirigota callejera del foame) – (en 2023: Vuelve ya shrek x 4)
*   **Los trisninas** – (Chirigota callejera de Bandera) – (en 2023: Banda de cornetas sin tambores Ntra. Sra. del Señor y Punto)
*   **Mister Spam. Nacido para llamar** – (Chirigota callejera del Puerto de Santa María) – (en 2023: ¿Noseratú de Cadi?)
*   **Ni un pasa atrás** – (Chirigota callejera de Cádiz) – (en 2023: La izquierda, chirigota infantil Carnaval chiquito)
*   **No es menester de juglaria** – (Chirigota del Mago) – (en 2023: Las tortugas viña)
*   **Pa esto hay que Ballet** – (Chirigota de los bodegueros) – (en 2023: Pa septiembre puteao, por un hechizo mal echao. IES Hogwarts Caleta)
*   **Pandora´s vox** – (La chirigota de la Beduinas) – (en 2023: Las del meneito)
*   **Que traducido resulta** (Ilegal de Rota) – (en 2023: Los Alarmistas)
*   **Si me queréis, irse** – (Chirigota callejera de Cádiz) – (en 2023: Este año nos lo llevamos to)
*   **T.U.S. M.U.E.R.T.O.S.** – (Chirigota callejera de Chiclana de la Frontera) – (en 2023: Los supermamporreros)
*   **The animals, el documental** – (Chirigota de Sanlúcar de Barrameda) – (Agrupación de nueva creación)
*   **Valiente príncipe** – (Chirigota platónica) – (en 2023: **[Un mundo feliz](https://www.youtube.com/watch?v=KwvIpVl2jvk)**)
*   **Viven (y de milagro)** – (Chirigota callejera de los extranjeros) – (en 2023: **[Mas vale nunca que tarde](https://www.youtube.com/watch?v=T14MSc35h2E)**)
