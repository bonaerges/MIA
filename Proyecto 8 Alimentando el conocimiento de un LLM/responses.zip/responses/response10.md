Title: ▷ Agenda LUNES DE CARNAVAL en Cádiz - 12 de febrero

URL Source: https://www.codigocarnaval.com/carnaval-de-cadiz/agenda-lunes-de-carnaval/

Published Time: 2023-02-17T20:13:22+01:00

Markdown Content:
El **lunes de Carnaval** (12 de febrero) también se le conoce como ‘lunes de resaca’ y es otro de los días en los que podremos disfrutar desde por la mañana de los diferentes actos que se celebrarán en Cádiz.

Como peculiaridad, este día es festivo en la ciudad, por lo que puede ser una buena oportunidad para disfrutar de la fiesta sin tanta masificación de días anteriores. Aún así, es un día muy concurrido.

Concurso de Tanguillos
----------------------

El barrio de Santamaría, más concretamente el **Centro Municipal de Arte Flamenco ‘La Merced’**, acoge a partir de las **12:00h** y a las **16:00h** del mediodía el **XLIV Concurso de bailes de Tanguillos**. La entrada es libre hasta completar aforo.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Feria infantil
--------------

La **plaza de San Antonio** acogerá la feria infantil entre las **12:00h** del mediodía y las **18:00h** de la tarde. Si quieres más información puedes consultar nuestro artículo de **[programación del Carnaval de Cádiz con niños.](https://www.codigocarnaval.com/carnaval-con-ninos/)**

Festival Benéfico Agamama
-------------------------

La **plaza del Mentidero** acogerá en la agenda lunes de carnaval uno de los eventos más atractivos del día. El evento dará comienzo a partir de las **12:00h**.

La **asociación Gaditana de Mujeres con Cáncer de Mama** ofrece un evento gratuito y benéfico donde actuarán agrupaciones del COAC y algunas antologías.

Agrupaciones que participan (sin orden establecido)

*   12:30h – Chirigota – **[Los Chabolis](https://www.codigocarnaval.com/coac-2024/los-chabolis/)**
*   13:00h – Chirigota – **[Los del Canal Sur](https://www.codigocarnaval.com/coac-2024/los-del-canal-sur/)**
*   13:30h – Cuarteto – **[Punk y Circo, la lucha continúa](https://www.codigocarnaval.com/coac-2024/punk-y-circo-la-lucha-continua/)**
*   13:30h – Cuarteto infantil – **Papa, mámá, tenemos un problema**
*   13:30h – Cuarteto juvenil – **La Señorita Candelaria y tres niños de secundaria**
*   14:00h – Comparsa – **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   14:30h – Chirigota – **[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)**
*   15:00h – Chirigota – **[La Callejera invisible](https://www.codigocarnaval.com/coac-2024/la-callejera-invisible/)**
*   15:30h – Comparsa – **[La Alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   16:00h – Comparsa – **[Los Despertadores](https://www.codigocarnaval.com/coac-2024/los-despertadores/)**
*   16:30h – Chirigota – **[Que ni las hambre las vamo a sentí](https://www.codigocarnaval.com/coac-2024/que-ni-las-hambre-las-vamo-a-senti/)**
*   17:00h – Chirigota callejera – **Las Adolfas**
*   17:30h – Comparsa – **[Los Colgaos](https://www.codigocarnaval.com/coac-2024/los-colgaos/)**
*   18:00h – Cuarteto infantil – **Recapaciclando**
*   18:15h – Comparsa – **[Las Herederas](https://www.codigocarnaval.com/coac-2024/las-herederas/)**
*   18:45h – Chirigota – **[Sácamela de la boca](https://www.codigocarnaval.com/coac-2024/sacamela-de-la-boca/)**
*   19:15h – Cuarteto – **[He vuelto (El Barrio)](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/)**
*   19:30h – Comparsa – **[Los Sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   20:00h – Chirigota – **[El Grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**
*   20:30h – Chirigota – **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   21:00h – Chirigota – **[El niño de Isabelita 2](https://www.codigocarnaval.com/coac-2024/el-nino-de-isabelita-2/)**
*   21:30h – **Antología del Noly**

Carrusel de coros
-----------------

Como ya ocurriera el día anterior, **[el carrusel de coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** volverá a celebrarse en torno a las **13:00h** del mediodía con dos focos importantes.

Tendremos dos recorridos, uno por **Plaza de Mina** y el citado por el **Mercado Central** (Plaza de Abastos). Ambos tendrán un sentido circular y los coros ofrecerán sus repertorios al público montados en bateas.

**CARRUSEL DE COROS** 🎭  
Si quieres más información detallada, visita nuestro artículo sobre el **[carrusel de Coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)**

I Concurso agrupaciones carnavalescas
-------------------------------------

A partir de las **13:00h** este año como novedad, la Asociación de vecinos Murallas de San Carlos organiza el **I Concurso de agrupaciones carnavalescas**, coros comparsas y chirigotas celebrándose a lo largo de la semana teniendo lugar en el **[tablao de la Plaza España](https://www.codigocarnaval.com/los-tablaos-del-carnaval-de-cadiz/)**.

### Orden de actuación

*   13:00h – Chirigota infantil – **Tochiko Mikay**
*   13:30h – Comparsa juvenil – **La casa del Carnaval**
*   14:30h – Chirigota – **Por fin lo despedimos**
*   15:00h – Comparsa – **Pueblejito La Frontera**
*   15:30h – Comparsa – **La Chirigotera**
*   16:00h – Chirigota – **Carnaval me cago en tus muertos**
*   16:30h – Comparsa – **Los Sacrificaos**
*   17:00h – Comparsa – **Los Amuletos**
*   17:30h – Comparsa – **El Paseíto**
*   18:00h – Chirigota – **Los Plácidos Domingos**
*   18:30h – Coro – **El Paraíso**
*   19:00h – Coro – **La Dama de Cádiz**
*   19:30h – Coro – **El Gremio**

XVI Tomatada Popular y Certamen de coplas Antifaz Violeta
---------------------------------------------------------

Sobre las **14:00h** dará comienzo la Tomatada popular organizado por AAVV del Pópulo y San Juan «Los Tres Arcos», junto a la **Catedral de Cádiz.**

En este evento tendrá lugar un certamen de coplas donde se disputará el **antifaz Violeta** entre las agrupaciones participantes.

Concurso de comparsas, chirigotas y cuartetos en la Peña La Estrella
--------------------------------------------------------------------

La **Peña La Estrella**, ubicará un escenario en la **plaza de Candelaria**, donde ese día, a partir de las **14:00h** irán desfilando diferentes agrupaciones (en este caso chirigotas, comparsas y cuartetos), con motivo del concurso de premios ‘Cañamaque’, ‘Paco Alba’ y ‘Agüillo’.

**CONCURSO PEÑA LA ESTRELLA 🎭  
**Si quieres más información detallada sobre el orden de actuación y agrupaciones que participan, visita nuestro artículo sobre el **[Tablao Peña La Estrella](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)**

Concentración de Romanceros Infantiles ‘A golpe de Cartelín’
------------------------------------------------------------

En la calle Abreu, muy próxima al Mercado Central, a partir de las 14:30h se ha organizado una concentración de romanceros infantiles y juveniles.

Algunos de los que han confirmado asistencia son:

*   Marco Santamaría «**Dragón ball pero la parte de Goku niño nada más**«
*   Lucía y Gala «**Las del columela**«
*   Paolo y Laura «**Ojalá nos manden a Parí**«
*   Andrea y Candela «**Una historia con Moraleja**«
*   Sofía «**La niña poseía y las nuevas tecnologías**«

Agrupaciones callejeras y del COAC por las calles de Cádiz
----------------------------------------------------------

Este lunes de carnaval, encontrarás numerosas **callejeras, romanceros y agrupaciones del COAC** ofreciendo sus repertorios por las calles de Cádiz. Si quieres saber cuáles son los puntos más calientes y habituales échale un vistazo a nuestro artículo sobre **[donde ver agrupaciones en Cádiz](https://www.codigocarnaval.com/donde-ver-agrupaciones-cadiz/)**. También puedes consultar **[la guía de Callejeras 2024](https://www.codigocarnaval.com/noticias/guia-callejeras-2024/)**

Además, en nuestro **[canal Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)**, donde somos ya más de 7000 carnavaleros podrás acceder y recibir todas las notificaciones al instante en tu teléfono sobre ubicaciones de agrupaciones y sus programas para el día.

**PROGRAMACIÓN BARRIO EL PÓPULO 🎭  
**El **barrio del Pópulo** también organizará una serie de eventos durante toda la semana. Si quieres más información consulta nuestro artículo de **Callejeras en el Pópulo**

Concursos
---------

A partir del lunes, tendremos el inicio de los diferentes concursos que se realizan con la participación de agrupaciones del COAC 2023.

A partir de las **20:00h**, la **Fundación Unicaja** organizará el **[Concurso Unicaja](https://www.codigocarnaval.com/concurso-unicaja-carnaval-de-cadiz/)** en la plaza de San Agustín.

A las **20:30h**, dará comienzo el **[Concurso de La Viña](https://www.codigocarnaval.com/concurso-popurri-la-vina/)**, ubicado en la calle de La Palma, en pleno corazón del barrio viñero.

### Concurso Romanceros Cartelón de Oro

En Gorrion Wine Bar tendrá lugar la primera semifinal del concurso de Romanceros en el barrio del Pópulo con el siguiente orden de actuación

*   21:00h – Annunakis inmortales en la playa de los corrales
*   21:15h – IA, IA, OH
*   21:30h – El trastero
*   21:45h – El romancero más malo del mundo
*   22:00h – El trepa
*   22:15h – La hija secreta de Cuqui, la muñeca diabólica
*   22:30h – Aquellos rublos antiguos
*   22:45h – 30 monedas
*   23:00h – La no boda del siglo
*   23:15h – La historia de Lolita cuando Napoleón estuvo de visita
*   23:30h – Nos la escarapela
*   23:45h – G.R.A.P.A.
*   00:00h – Aquí manda el señorito
*   00:15h – Barbie, contar la verdad para seguir viva
*   00:30h – Yo nunca me equivoco

Festival de Agrupaciones Cruzcampo
----------------------------------

La **plaza de San Antonio** acogerá un festival de agrupaciones donde actuarán numerosas agrupaciones del COAC 2024. Este evento tendrá lugar a partir de las **20:00h**.

*   Comparsa – **Los Sacrificaos**
*   Comparsa – **El Joyero**
*   Chirigota – **Que ni las hambre las vamo a sentí**
*   Chirigota – **Los Exageraos**
*   Chirigota – **La chirigota clásica**
*   Cuarteto – **Punk y Circo, la lucha continúa**

Programación para otros días
