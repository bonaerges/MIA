Title: Carnaval de Cádiz con niños - Guía COMPLETA 2024

URL Source: https://www.codigocarnaval.com/carnaval-con-ninos/

Published Time: 2020-02-04T10:19:08+01:00

Markdown Content:
Disfrutar del **Carnaval de Cádiz con niños** es posible, gracias a la programación oficial en la que ya conocemos los diferentes actos que se llevarán a cabo.

Las fechas oficiales del Carnaval de Cádiz comprenden entre el **8 al 18 de febrero** y los más pequeños podrán disfrutar de eventos, talleres y concursos dedicados a ellos.

Antes de que comience la semana oficial del carnaval de Cádiz, podremos asistir a una nueva propuesta de la Delegación Municipal de Fiestas, esto comprende un circuito de agrupaciones íntegramente formadas por infantiles y juveniles.

Esta programación está organizada por el Ayuntamiento de Cádiz.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Domingo 28 de enero
-------------------

### Circuito de agrupaciones ‘La cantera callejea’, novedad en el carnaval infantil 2024.

El domingo 28 de enero coincidiendo con la [**Ostionada**](https://www.codigocarnaval.com/ostionada/), las agrupaciones finalistas de la categoría infantil actuarán en el entorno de la Plaza de San Antonio.

Una oportunidad perfecta para disfrutar del **carnaval de Cádiz con niños** con el entorno de la cantera del Carnaval de Cádiz.

Domingo 4 de febrero
--------------------

### Circuito de agrupaciones ‘La cantera callejea’

El domingo 4 de febrero coincidiendo con la **[Erizada](https://www.codigocarnaval.com/erizada/)**, las agrupaciones finalistas de la categoría juvenil actuarán en los alrededores de la calle La Palma.

Asimismo, **el circuito ‘La cantera callejea’** volverá a acoger a las agrupaciones infantiles y juveniles, respectivamente, los días 17 y 18 de febrero, que ofrecerán actuaciones en diferentes puntos del casco histórico.

#### LUDOTECA CARNAVAL – FEBRERO

En la **calle Arbolí** se instalará una ludoteca infantil. Su horario será:  
◾ **De 9:00 a 14:00 y de 16:00 a 20:00h** _(Sábado 10 , Domingo 11, Lunes 12, Sábado 17 y Domingo 18)_  
◾ **De 16:00 a 20:00h** _(Martes 13, Miércoles 14, Jueves 15 y Viernes 16)_

Jueves 8 de febrero
-------------------

### Ludopandi de Carnaval

A partir de las 17:00h hasta las 21:00h en **la casa de la Juventud** (c/ Cánovas del Castillo 41) se llevará a cabo un baile infantil y juvenil de disfraces, talleres y otras actividades en colaboración con AGEBH.

Sábado 10 de febrero
--------------------

### Cortejo, pregón infantil y actuaciones de la cantera

Desde las **12:00h** del mediodía, la actividad se trasladará a zona de puertatierra, donde habrá un **desfile infantil de disfraces y agrupaciones infantiles** desde la **glorieta de Cortadura** hasta la **glorieta Ana Orantes**.

A continuación, desde la **glorieta Ana Orantes**, a partir de las 13:00h tendrá lugar el **pregón infantil** del Carnaval 2024 de la mano de **Sofía Letrán Sánchez de la Campa**.

Posteriormente y hasta las **18:00h** tendremos actuaciones de agrupaciones infantiles y juveniles del COAC 2024 con ‘**La Cantera callejea**‘ en la glorieta Ana Orantes y el Paseo Marítimo.

A su vez, en la misma glorieta también tendremos **juegos temáticos** con diversas actividades

*   Taller de jabones aromáticos
*   Olimpiadas ecológicas
*   Ginkana de la Fábrica de Chocolate
*   Atrapa a estos Oompa Loompa
*   Persigue el pozo de tus sueños

Sin dudas un día cargado de **actividades de carnaval para niños en Cádiz**.

Domingo 11 de febrero
---------------------

### Musical

Desde las **12:30h** en la **plaza de San Antonio** tendremos el musical ‘**Viva el carnaval. Cocodirlodrilo**‘.

### Gran Cabalgata

Desde las 17:30h, la **[Gran Cabalgata](https://www.codigocarnaval.com/cabalgata-carnaval-cadiz/)** recorrerá las calles de la avenida, desde Glorieta Ana Orantes hasta las Puertas de Tierra. Una perfecta oportunidad para disfrutar del carnaval con niños.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

Lunes 12 de febrero
-------------------

### Concurso de Tanguillos

A partir de las **12:00h** del mediodía, el **Centro Municipal de Arte Flamenco ‘La Merced’** acoge el XLIV **Concurso de Tanguillos**, dando otra función a partir de las 16:00h.

Por otro lado, desde las **12:00h** y hasta las **18:00h** en la Plaza de San Antonio habrá una **mini feria**.

### Musical

La plaza de San Antonio, desde las **13:00h** tendrá el musical ‘**13 cuentos, la magia desafía a la suerte**‘

Martes 13 de febrero
--------------------

El martes continuará el concurso de Tanguillos desde el centro ‘La Merced’ a partir de las 16:00h

### Teatro de títeres, un buen plan para pasar el carnaval de Cadiz con niños

Más tarde, a las 18:00h, la plaza de San Francisco será testigo de un **teatro de títeres** llamado ‘**Un quijote sin barba ni bigote**‘

Miércoles 14 de febrero
-----------------------

El miércoles se abrirá nuevamente con el concurso de Tanguillos en la Merced a partir de las 16:00h

### Tarde infantil y juvenil de Carnaval

Desde las **17:00h** hasta las **20:00h** en la **Plaza de San Antonio** los más peques podrán disfrutar de un concurso de disfraces infantiles y de un musical infantil llamado ‘**Valle de Cuentos**‘.

Por su parte, desde las **18:00h** en la **Plaza de San Francisco** podrán disfrutar de un teatro de títeres llamado ‘**Titirifabulas**‘.

### Certamen de coplas para la cantera

El barrio de Santa María y la Plaza de San Juan de Dios tendrán un escenario donde actuarán agrupaciones infantiles y juveniles del COAC 2024 a partir de las 19:00h.

Jueves 15 de febrero
--------------------

### Juegos Temáticos

Desde las **16:00h** hasta las **20:00h**, la **plaza de San Juan De Dios** acogerá diversos juegos temáticos para disfrutar del Carnaval de Cádiz con niños con toda la familia.

*   Lucha de espadas
*   Dale de comer al tiburón
*   Recorrido pirata
*   Baile
*   Pintacaras pirata
*   Pesca de patos

### Certamen de coplas para la cantera

El barrio de Santa María y la Plaza de San Juan de Dios tendrán un escenario donde actuarán agrupaciones infantiles y juveniles del COAC 2024 a partir de las 19:00h.

Viernes 16 de febrero
---------------------

### Juegos temáticos

Nuevamente se repetirá la programación del día anterior en la Plaza de San Juan de Dios en horario de 16:00h a 20:00h.

### Certamen de coplas para la cantera

El barrio de Santa María y la Plaza de San Juan de Dios tendrán un escenario donde actuarán agrupaciones infantiles y juveniles del COAC 2024 a partir de las 19:00h.

Sábado 17 de febrero
--------------------

### Actuaciones infantiles y juveniles ‘La Cantera Callejea’

El sábado 17 de febrero podremos disfrutar del circuito **‘La cantera callejea**‘ que ofrecerá las agrupaciones infantiles y juveniles por los alrededores de la plaza San Antonio y San Juan de Dios. Este evento tendrá lugar entres las 14:00h y las 18:00h.

Por la tarde, a partir de las 18:00h la **[cabalgata del humor](https://www.codigocarnaval.com/cabalgata-del-humor-carnaval-cadiz/)** recorrerá las calles del centro histórico.

Domingo 18 de febrero
---------------------

### Actuaciones infantiles y juveniles ‘La Cantera Callejea’

El domingo 18 de febrero podremos disfrutar del circuito **‘La cantera callejea**‘ que nuevamente en el mismo horario y lugares del sábado actuarán agrupaciones infantiles y juveniles del COAC 2024.

### Musical

Desde las **12:30h** en la **plaza de San Antonio** tendremos el **espectáculo musical infantil ‘Cantajuego’**.

### Gran Piñata Infantil

Desde la **glorieta Ana Orantes**, entre las **14:00h** y las **18:00h** tendrá lugar una **tarde de juegos**.

### Espectáculo de luces y sonidos para cerrar el carnaval

El Carnaval de Cádiz se cerrará oficialmente a partir de las **22:00h**, con la **quema de la Bruja Piti** y un **espectáculo de luces y sonidos** para clausurar el Carnaval 2024. En esta ocasión, siendo conscientes con la causa el Ayuntamiento de Cádiz ha confirmado que no usará pirotecnia ni fuegos artificiales.
