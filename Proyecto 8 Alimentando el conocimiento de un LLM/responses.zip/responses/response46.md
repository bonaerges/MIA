Title: ➤ Programación CARNAVAL DE CÁDIZ 2024 - Guía Completa

URL Source: https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/

Published Time: 2021-06-17T12:23:36+02:00

Markdown Content:
El carnaval de Cádiz suele comenzar a primeros de año, en torno al mes de enero con el inicio del **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)** (Concurso Oficial de Agrupaciones del Carnaval de Cádiz) que se celebra en el **Gran Teatro Falla**, cuya duración es de un mes aproximadamente.

Allí, las agrupaciones ofrecen sus repertorios que han ido ensayando durante los 4 últimos meses. El concurso se retransmite a través de **Onda Cádiz TV** y **Canal Sur TV**, así como las distintas emisoras de radio.

Una vez concluye el concurso, las agrupaciones salen a la calle para celebrar la fiesta del Carnaval de Cádiz que dura aproximadamente una semana.

Fechas Carnaval 2024
--------------------

Para la edición de 2024, el **Carnaval de Cádiz 2024** se celebrará del **8 al 18 de febrero**, comenzando como siempre el jueves previo a la Gran Final del COAC y finalizando dos domingos después, en el denominado domingo de piñata.

#### Exposiciones permanentes

– **Julio González**: ‘Carnaval de improviso. Retratos urgentes: la trastienda del COAC’  
– El carnaval y **Carlos Edmundo de Ory**  
– Exposición de **Agujas de Oro** del Carnaval de Cádiz

Actos Gastronómicos Carnaval 2024
---------------------------------

### Sábado 27 de enero

El **sábado 27 de enero** se dará el pistoletazo de salida con la celebración de la **[XXXIV Pestiñada Popular](https://www.codigocarnaval.com/pestinada/)** en la **plaza de San Francisco** a partir de las **20:30h**. Este evento está organizado por la Asociación de Comparsistas 1960.

Durante el mismo, habrá actuaciones de agrupaciones del Carnaval de Cádiz.

### Domingo 28 de enero

El día siguiente, el **domingo 28 de enero**, la **plaza de San Antonio** acogerá la **[XXXVII Ostionada Popular](https://www.codigocarnaval.com/ostionada/)** en torno a las **13:30h** del mediodía. En ella se degustarán ostiones y papas aliñás, junto a vino y cerveza.

Este evento está organizado por el Aula de Cultura del Carnaval de Cádiz.

Durante el mismo, habrá actuaciones de agrupaciones del Carnaval de Cádiz.

Ese mismo día, en la **Peña Flamenca La Perla de Cádiz** se celebrará la **XXIII Gambada Popular** organizada por la Peña La Tertulia Doña Frasquita. El evento comenzará a las **13:30h.**

### Domingo 4 de febrero

La celebre **[XLII Erizada 2024](https://www.codigocarnaval.com/erizada/)** se llevará a cabo por las calles del barrio de La Viña el **domingo 4 de febrero**, comenzando en torno a las **13:00h** del mediodía. Este evento se organiza por la Federación de Peñas y Entidades Caleteras.

Durante el mismo, habrá actuaciones de agrupaciones del Carnaval de Cádiz.

Ese mismo día, nuevamente en la **Peña La Perla de Cádiz** se celebrará su clásica **XX Mejillonada popular**, donde también se espera la actuación de diversas agrupaciones del Carnaval de Cádiz. Este evento tendrá lugar a las **13:30h.**

### Jueves, 8 de febrero

*   12:30h – **Recepción al Pregonero, Pregonera Infantil, Gran Momo y Hércules de Oro del Carnaval** (Salón de Plenos Ayuntamiento)
*   17:00h a 21:00h – **[Ludopandi de Carnaval](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Baile infantil y juvenil disfraces) (Casa de la Juventud)
*   20:00h – **[Final Concurso de Romanceros 2024](https://www.codigocarnaval.com/concurso-romanceros-carnaval/)** (Gran Teatro Falla)
*   22:00h – **Concierto de ‘POLE’** (Plaza de San Antonio)

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

### Viernes, 9 de febrero

*   20:00h – **[Gran Final del COAC 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/)** (Gran Teatro Falla)

El viernes, en el Gran Teatro Falla, por la tarde-noche, tendrá lugar la **[Gran Final del Falla 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/)** en la modalidad de adultos que se prolongará hasta las primeras luces del día siguiente en un auténtico maratón de coplas.

Este día no encontrarás mucho ambiente por la calle, salvo en los alrededores del Teatro o si decides pasarte por el **Café Teatro Pay-Pay**, en el barrio del Pópulo donde instalarán una pantalla de 100 pulgadas para seguir el concurso. Además, diversos locales del Pópulo también seguirán la iniciativa.

### Sábado, 10 de febrero

*   12:00h – **[Desfile infantil de disfraces y agrupaciones infantiles](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Glorieta Cortadura a Glorieta Ana Orantes)
*   12:00h – **Mejillonada Popular** (Plaza de los Porches)
*   13:00h – **Pregón Infantil a cargo de Sofía Letrán Sánchez de la Campa**
*   13:00h a 18:00h – **[La cantera callejea](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Actuaciones agrup. infantiles y juveniles COAC) (Glorieta Ana Orantes y Paseo Marítimo)
*   13:00h – **Certamen de romanceros** (AVV Murallas San Carlos)
*   13:00h a 18:00h – **[Juegos temáticos](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Glorieta Ana Orantes)
*   14:00h – **[Concurso de coros ‘Tío La Tiza’ en Peña La Estrella](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)** (Plaza Candelaria)
*   14:00h – **[Batalla de Coplas](https://www.codigocarnaval.com/batalla-coplas-carnaval/)** (Mercado Central y Plaza Palillero)
*   16:00h – **1ª Gala de Comparsas** (Sala Momart Theatre, Punta de S. Felipe) – **[Comprar Entradas](https://www.giglon.com/todos?idEvent=gala-de-carnaval-asociacion-de-comparsistas-1960-cadiz)**
*   20:30h – **[Pregón de Juanma Braza ‘El Sheriff’](https://www.codigocarnaval.com/pregon-carnaval-cadiz/)** (Plaza de San Antonio)
*   22:00h – **[Gala del Carnaval](https://www.codigocarnaval.com/gala-carnaval-de-cadiz/)** (Gran Teatro Falla)
*   22:00h – **Pregón barrio del Pópulo por Ketama y Cuqui**
*   22:30h – **Noche carnaval en la calle** (1º premios adultos COAC) (La Viña y Plaza S. Antonio)

**PROGRAMACIÓN INFANTIL  
**Consulta todos los planes que puedes hacer en el **[Carnaval de Cádiz con niños](https://www.codigocarnaval.com/carnaval-con-ninos/)** en la programación oficial y detallada.

### Domingo, 11 de febrero

*   12:30h – **[Musical ‘Viva el Carnaval Cocodilodrilo’](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio)
*   13:00h – **[Carrusel de Coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** (Mercado Central y Plaza de Mina)
*   13:00h – **[I Concurso agrupaciones carnavalescas](https://www.codigocarnaval.com/agenda-domingo-de-carnaval/),** coros comparsas y chirigotas organizado por AVV Murallas de San Carlos (Plaza España)
*   14:00h – **[Concurso Peña ‘La Estrella’ con actuaciones de chirigotas y comparsas](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)** (Plaza Candelaria)
*   17:30h – **[Cabalgata Magna del Carnaval de Cádiz](https://www.codigocarnaval.com/cabalgata-carnaval-cadiz/)**
*   22:00h – **Concierto de Alvama Ice** (Plaza S. Antonio)
*   Por determinar – **Actuaciones de coros y comparsas en el barrio del Pópulo**.

### Lunes, 12 de febrero

*   12:00h – **XLIV Concurso de Tanguillos** (Centro M. Arte Flamenco ‘La Merced’)
*   12:00h a 18:00h – **[Mini Feria](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio)
*   13:00h – **[Musical ’13 cuentos. La magia desafía a la suerte’](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio)
*   13:00h – **[Carrusel de Coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** (Mercado Central y Plaza de Mina)
*   13:00h – **[I Concurso agrupaciones carnavalescas](https://www.codigocarnaval.com/agenda-lunes-de-carnaval/)**, coros comparsas y chirigotas organizado por AVV Murallas de San Carlos (Plaza España)
*   13:00h – **[Festival Benéfico AGAMAMA](https://www.codigocarnaval.com/agenda-lunes-de-carnaval/)** (Agrupaciones COAC) (Plaza del Mentidero)
*   14:00h – **XVI Tomatada Popular y certamen de coplas antifaz Violeta** (Junto a la Catedral)
*   14:00h – **[Concurso Peña ‘La Estrella’ con actuaciones de chirigotas y comparsas](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)** (Plaza Candelaria)
*   16:00h – **XLIV Concurso de Tanguillos** (Centro M. Arte Flamenco ‘La Merced’)
*   20:00h – **[Concurso de Unicaja](https://www.codigocarnaval.com/concurso-unicaja-carnaval-de-cadiz/)** (Plaza S. Agustín)
*   20:00h – **[Festival de Agrupaciones Cruzcampo](https://www.codigocarnaval.com/agenda-lunes-de-carnaval/)** (Plaza San Antonio)
*   20:30h – **[Concurso Popurri La Viña y Piropo a Cádiz](https://www.codigocarnaval.com/concurso-popurri-la-vina/)** (Calle La Palma)
*   21:00h – **Concurso de romanceros ‘Cartelón de oro’** (Calles del Pópulo)

En la **Fundación Cajasol** (Plaza San Antonio, 14) se instalará un ‘**Fotomatón**‘ en horario de 12:00h a 14:00h y de 17:30h a 19:30h. Entrada 1€ online y taquillas Fundación.

### Martes, 13 de febrero

*   16:00h – **XLIV Concurso de Tanguillos** (Centro M. Arte Flamenco ‘La Merced’)
*   17:30h – **Taller familiar de maquillaje de fantasía ‘Pin Ta Te Tu’** (Fundación Cajasol)
*   18:00h – **[Teatro de títeres ‘Un quijote sin barba ni bigote’](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Francisco)
*   19:30h – **[Circuito de Agrupaciones](https://www.codigocarnaval.com/circuito-agrupaciones-carnaval/)**
*   20:00h – **Cortejo del Dios Momo por las calles de Cádiz** (Desde Plza. S. Juan de Dios a San Antonio)
*   20:00h – **[Concurso de Unicaja](https://www.codigocarnaval.com/concurso-unicaja-carnaval-de-cadiz/)** (Plaza S. Agustín)
*   20:00h – **[Concurso de Presentaciones ‘Holaquilloquepasa’](https://www.codigocarnaval.com/concurso-de-presentaciones/)** (Plaza Mentidero)
*   20:30h – **[Concurso Popurri La Viña y Piropo a Cádiz](https://www.codigocarnaval.com/concurso-popurri-la-vina/)** (Calle La Palma)
*   21:00h – **Concurso de romanceros ‘Cartelón de oro’** (Calles del Pópulo)
*   21:00h – **XXIV** **Concurso de Pasodobles en Peña Paco Alba** (Bóvedas Sta. Elena)
*   21:30h – **[Pregón y quema del Dios Momo por David Carapapa](https://www.codigocarnaval.com/quema-dios-momo/)** (Plaza de San Antonio)

### Miércoles, 14 de febrero

*   16:00h – **XLIV Concurso de Tanguillos** (Centro M. Arte Flamenco ‘La Merced’)
*   17:00h a 20:00h – **[Tarde Infantil y Juvenil de Carnaval](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza S. Antonio)
*   17:30h – **Coron-Arte** (Crea tu propio tocado de Carnaval) (Fundación Cajasol)
*   18:00h – **[Teatro de títeres ‘Titirifábulas’](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Francisco)
*   19:00h – **[Certamen de Coplas para la cantera](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza S. Juan de Dios y Barrio Santa María)
*   19:00h – **Gran Noche Callejera** (Actuación Agrupaciones Callejeras) (Fundación Cajasol)
*   19:30h – **[Circuito de Agrupaciones](https://www.codigocarnaval.com/circuito-agrupaciones-carnaval/)**
*   20:00h – **[Concurso de Unicaja](https://www.codigocarnaval.com/concurso-unicaja-carnaval-de-cadiz/)** (Plaza S. Agustín)
*   20:00h – **[Concurso de Presentaciones ‘Holaquilloquepasa’](https://www.codigocarnaval.com/concurso-de-presentaciones/)** (Plaza Mentidero)
*   20:30h – **[Concurso Popurri La Viña y Piropo a Cádiz](https://www.codigocarnaval.com/concurso-popurri-la-vina/)** (Calle La Palma)
*   21:00h – **XXIV Concurso de Pasodobles en Peña Paco Alba** (Bóvedas Sta. Elena)
*   22:00h – **Carrusel de ilegales por el barrio del Pópulo y alrededores**

Nuevo día laborable en la ciudad, donde las agrupaciones **callejeras y romanceros** se harán fuerte especialmente en los aledaños del barrio del Pópulo y del barrio de La Viña.

Continuarán los **[circuitos de agrupaciones](https://www.codigocarnaval.com/circuito-agrupaciones-carnaval/)** en la tarde-noche, la programación infantil y los diferentes concursos de peñas con actuaciones de agrupaciones del COAC.

**GUÍA DE CALLEJERAS 2024  
**Si quieres saber todo sobre las agrupaciones más imprescindibles no te pierdas nuestra **[guía de callejeras 2024.](https://www.codigocarnaval.com/noticias/guia-callejeras-2024/)**

### Jueves, 15 de febrero

*   16:00h a 20:00h – **[Juegos temáticos](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Juan de Dios)
*   18:00h – **Master Class Maquillaje de Carnaval ‘Fantasía Makeup’** (Fundación Cajasol)
*   18:00h – **[Teatro de Títeres ‘Titirimagionetas especial Carnaval’](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Francisco)
*   19:00h – **[Certamen de Coplas para la cantera](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza S. Juan de Dios y Barrio Santa María)
*   19:30h – **[Circuito de Agrupaciones](https://www.codigocarnaval.com/circuito-agrupaciones-carnaval/)**
*   20:00h – **[Concurso de Presentaciones ‘Holaquilloquepasa’](https://www.codigocarnaval.com/concurso-de-presentaciones/)** (Plaza Mentidero)
*   20:00h – **Tarde de Callejeras en Bar La Casapuerta de Luisa** (Sagasta 40)
*   20:30h – **[Concurso Popurri La Viña y Piropo a Cádiz](https://www.codigocarnaval.com/concurso-popurri-la-vina/)** (Calle La Palma)
*   21:00h – **Concierto de Javi Medina** (Plaza San Antonio)
*   21:00h – **XXIV Concurso de Pasodobles en Peña Paco Alba** (Bóvedas Sta. Elena)
*   21:00h – **Circuito de Romanceros ‘A gorpe de cartelón’** (Barrio Santa María)
*   21:30h – **[Entrega ‘Aguja de oro’ y actuaciones](https://www.codigocarnaval.com/aguja-oro-carnaval-cadiz/)** (Plaza San Francisco)
*   22:00h – **Carrusel de ilegales por el barrio del Pópulo y alrededores**
*   23:00h – **Concierto Riki Rivera** (Plaza San Antonio)

### Viernes, 16 de febrero

*   16:00h a 20:00h – **[Juegos temáticos](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Juan de Dios)
*   16:00h – **Concurso de baile por tanguillos** organizado por la AVV Murallas San Carlos (Plaza España)
*   17:00h – **[Actuación de agrupaciones de la cantera en Peña La Estrella](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)** (Plaza Candelaria)
*   19:00h – **[Certamen de Coplas para la cantera](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza S. Juan de Dios y Barrio Santa María)
*   20:30h – **[Final Concurso Unicaja](https://www.codigocarnaval.com/concurso-unicaja-carnaval-de-cadiz/)** (Plaza S. Agustín)
*   20:30h – **[Final Concurso Popurri La Viña y Piropo a Cádiz](https://www.codigocarnaval.com/concurso-popurri-la-vina/)** (Calle La Palma)
*   21:00h – **Final concurso ‘Cartelón de Oro’** (Barrio del Pópulo)
*   22:00h – **Concierto Sofía Ellar** (Plaza San Antonio)
*   23:30h – **Concierto DJ Valdi** (Plaza San Antonio)

### Sábado, 17 de febrero

*   16:00h – **Final XLIV Concurso de Tanguillos** (Gran Teatro Falla)
*   12:00h – **XXXVI Panizada Popular** (Bóvedas Sta. Elena, explanada frente a Procasa)
*   12:30h – **[Concierto de Luly Pampín](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza de San Antonio)
*   13:00h – [**Carrusel de coros**](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/) (Plaza del Mentidero y La Viña)
*   13:00h – **[Degustación Papas Aliñás](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** (Plaza La Merced, Barrio Santa María)
*   13:00h – **[XLV Tortillada Popular de Camarones](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** en Loreto
*   13:30h – **[XXVII Degustación Migas Extremeñas en Casa de Extremadura](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** (c/ Regimiento de Infantería 7, bajo)
*   14:00h – **Final XXIV** **Concurso de Pasodobles en Peña Paco Alba** (Bóvedas Sta. Elena)
*   14:00h a 18:00h – **[La cantera callejea](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio y San Juan de Dios)
*   19:00h – **[Cabalgata del Humor](https://www.codigocarnaval.com/cabalgata-del-humor-carnaval-cadiz/)** (Calles del casco histórico)
*   22:00h – **Concierto ‘El Arrebato’** (Plaza de San Antonio)
*   23:30h – **Concierto de Luigii López** (Plaza de San Antonio)

El segundo sábado viene marcado por una importante oferta gastronómica gracias a las diferentes peñas y asociaciones vecinales.

Así, podremos encontrar un extenso menú para **[comer gratis en el Carnaval de Cádiz](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** con degustaciones de papas aliñás, migas extremeñas, panizas, tortillas de camarones…

### Domingo, 18 de febrero

*   12:30h – **[Espectáculo musical infantil Cantajuego](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio)
*   12:30h – **[XLVII Degustación de Pescaíto Frito con actuaciones de las agrupaciones premiadas](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)** (Plaza Candelaria)
*   13:00h – **[Final concurso presentaciones ‘Holaquilloquepasa](https://www.codigocarnaval.com/concurso-de-presentaciones/)‘** (Plaza del Mentidero)
*   13:00h – **[Carrusel de Coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** (Mercado Central y Plaza de Mina)
*   13:00h – **[XL Gran Berzá Carnavalesca con actuaciones de las agrupaciones premiadas](https://www.codigocarnaval.com/agenda-domingo-de-pinata/)** (Plaza España)
*   13:00h – **[II Pinchitada Popular](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** organizada por AVV del Mentidero en la **plaza del Mentidero**
*   14:00h a 18:00h – **[La cantera callejea](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Plaza San Antonio y San Juan de Dios)
*   14:00h a 18:00h – **[La gran piñata infantil](https://www.codigocarnaval.com/carnaval-con-ninos/)** (Glorieta Ana Orantes)
*   22:00h – **Quema de la Bruja Piti** (Pza. Fernando Quiñones / Playa La Caleta)
*   22:15h – **Espectáculo de luces y sonidos Fin del Carnaval** (Plaza Fernando Quiñones / Playa La Caleta)

### Domingo, 25 de febrero

*   12:00h – **Anchoada popular Gaditana** (Plaza Fray Pablo de Cádiz)
*   **[Carnaval chiquito o Carnaval de los jartibles](https://www.codigocarnaval.com/carnaval-chiquito/)**

Alojamientos para el Carnaval de Cádiz
--------------------------------------

El Carnaval es la fiesta más importante de la ciudad de Cádiz, por tanto, son miles los aficionados y viajeros que cada año reservan su alojamiento en la ‘Tacita de Plata’ para disfrutar de sus carnavales.

Lo ideal es que reserves tu alojamiento en Cádiz capital, ya que cuanta más cercanía mejor. Además, si reservas por el centro histórico, no tendrás que usar el coche ni ningún medio de transporte para disfrutar de toda la oferta que la ciudad brinda al ciudadano.

Aún así, también existen numerosas opciones de hoteles y hostales por otras zonas a precios más asequibles, o también la opción de buscar algo con vistas al mar para que tu estancia sea redonda.

¿Cuáles son los mejores días para venir al Carnaval de Cádiz?
-------------------------------------------------------------

![Image 1: agrupaciones calle](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20600'%3E%3C/svg%3E)

Elegir los mejores días para venir al Carnaval de Cádiz puede resultar en ocasiones algo complicado si no se tiene muy claro que se busca, o mejor dicho, que se ofrece durante la semana.

**Hay ambientes para todos los gustos**, desde los que buscan más fiesta y conciertos, para los que buscan escuchar todo lo posible a las agrupaciones, quienes quieren aprovechar para conocer la ciudad, los que buscan el carnaval callejero o incluso un ambiente más familiar o para que los niños disfruten.

No te pierdas nuestro artículo, donde te desgranamos todo lo que puedes encontrar cada día para que así, elijas la mejor opción.

*   📌 **[Los mejores días para venir al Carnaval de Cádiz](https://www.codigocarnaval.com/mejores-dias-para-venir-al-carnaval-de-cadiz/)**

Si quieres algo más extenso, te ofrecemos la mejor **[guía para comer en Cádiz](https://www.codigocarnaval.com/donde-comer-carnaval-cadiz/)**, donde te desvelamos los mejores lugares para tapear, desayunos, almuerzos, cenas… ¡Quien se quede con hambre es porque quiere!

¿Dónde ver y encontrar las agrupaciones del Carnaval de Cádiz?
--------------------------------------------------------------

![Image 2: agrupaciones carnaval calle](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)

Llegas a Cádiz con toda la intención de encontrar agrupaciones, pero claro, tienes el problema que **no sabes dónde buscar**. Y sí, es obvio, que dando un paseo te vas a encontrar alguna en cada esquina, pero posiblemente algunos ya vayan buscando agrupaciones concretas o con algo más de calidad.

En la calle podrás encontrar tanto agrupaciones del concurso como charangas familiares, agrupaciones callejeras, romanceros, carruseles de coros… ¡Hay donde elegir!

### Las callejeras y romanceros

Las **[agrupaciones callejeras](https://www.codigocarnaval.com/agrupaciones-callejeras/)** (o también llamadas ilegales) no participan en el COAC. Son de carácter más anárquico y no tienen un orden preestablecido de horarios ni orden de actuación. Aunque si bien es cierto, que muchas de ellas tienen muchos de los denominados ‘puntos calientes’, donde a buen seguro con algo de suerte podrás coincidir con ellas.

‘**Los del perchero’, ‘La chirigota del Airon’, ‘Chirigota de Casapuerta’, ‘Las cadiwoman’, ‘Las niñas de las botas de agua’, ‘Los del Ukelele’, ‘La chirigota Rockera’.**.. hay una infinidad de agrupaciones que cada año nos brindan sus repertorios con un ingenio sin igual.

Tampoco podemos olvidarnos de los **[romanceros](https://www.codigocarnaval.com/romanceros/)**, hombres y mujeres solitarios con un gran cartelón, nos contarán una historia desternillante llena de humor, crítica y sátira. Sin dudas no te los puedes perder.

### Seguimiento en vivo en nuestro canal Telegram

![Image 3: telegram](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201024%20536'%3E%3C/svg%3E)

Durante la semana del Carnaval de Cádiz, en nuestro **[canal Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)** solemos hacer un seguimiento en vivo de las agrupaciones y de sus actuaciones. Solemos ir publicando sus rutas de actuaciones (principalmente las agrupaciones del COAC) e incluso vamos avisando en vivo y directo dónde se encuentran cantando o hacia donde van.

No olvides unirte, ya que nuestro canal trabaja los 365 días del año, ofreciendo todo el contenido más fresco del Carnaval, con noticias, rumores, reportajes, los mejores vídeos…

¿Qué ver en Cádiz?
------------------

![Image 4: campo del sur cadiz](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20533'%3E%3C/svg%3E)

¿Te gustaría conocer más a fondo la ciudad de Cádiz? ¡Genial, porque también podrás encontrar toda la información que necesitas!

Si además del carnaval, quieres disfrutar conociendo la ciudad, hemos preparado una pequeña guía sobre Cádiz, con los mejores rincones que ver, que hacer y qué visitar, para que tu estancia sea absolutamente al 100%

*   📌 **[¿Qué ver en Cádiz?](https://www.codigocarnaval.com/que-ver-en-cadiz/)** – La guía más completa

Además si estáis interesados en mucha más información sobre Cádiz y su provincia, os invitamos a visitar **[Código Travel](https://www.codigotravel.com/)**, nuestro otro proyecto, donde contamos nuestra experiencia en viajes por todo el mundo, con especial atención a nuestra tierra. Aquí te dejamos algunos artículos que podrían interesarte

#### Imprescindibles que ver en Cádiz

¿Dónde aparcar en el Carnaval de Cádiz?
---------------------------------------

Encontrar aparcamientos en Cádiz puede resultar ser una tarea bastante difícil, y más aún si hablamos en las fechas del Carnaval de Cádiz.

Una de las mejores opciones es dejar el vehículo en un parking, o incluso en la entrada de la ciudad y usar el transporte público.

Aún así, te hemos preparado una pequeña guía con lo que debes saber a la hora de buscar aparcamiento en Cádiz. ¡No te lo pierdas!

*   **[Aparcamientos en el Carnaval de Cádiz](https://www.codigocarnaval.com/donde-aparcar-en-cadiz-en-carnaval/)** – Guía completa

#### Artículos de interés sobre el Carnaval de Cádiz
