Title: BATALLA DE COPLAS 2024 (Cádiz) - Horarios y escenarios

URL Source: https://www.codigocarnaval.com/batalla-coplas-carnaval/

Published Time: 2019-10-09T12:56:53+02:00

Markdown Content:
La **Batalla de Coplas Carnaval de Cádiz 2024**, es un evento organizado por el Ayuntamiento de Cádiz, en el cual las agrupaciones del **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)** realizan actuaciones en diferentes tablaos o escenarios.

Este evento forma parte de la oferta de los **[diferentes escenarios o tablaos](https://www.codigocarnaval.com/los-tablaos-del-carnaval-de-cadiz/)** que podrás encontrar en Cádiz durante la semana de Carnaval.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Fecha Batalla de Coplas Carnaval 2024
-------------------------------------

La Batalla de Coplas tiene lugar el **sábado 10 de febrero**, en los alrededores del **Mercado Central** y **Plaza del Palillero**.

En ellos actuarán las **agrupaciones semifinalistas** y **agrupaciones premiadas** del **COAC 2024** en cuatro escenarios: **Desamparados**, **La Marina**, **El Palillero** y **Merodio**.

Cada escenario tendrá una programación, por el que pasarán un número de agrupaciones a ofrecer los repertorios. Habitualmente, las actuaciones tienen una duración de unos 20 minutos.

Tablaos y horarios Batalla de Coplas Carnaval 2024
--------------------------------------------------

### Escenario Plaza Palillero

Comienzo a partir de las 14:00h aproximadamente. En los huecos vacíos no habrá actuaciones durante ese tiempo.

*   –
*   **[La Resbalaera](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   **[El Gremio](https://www.codigocarnaval.com/coac-2024/el-gremio/)**
*   –
*   **[La Chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   **[Asesinato en el Cádiz Express](https://www.codigocarnaval.com/coac-2024/asesinato-en-el-cadiz-express/)**
*   **[Que ni las hambre las vamo a sentí](https://www.codigocarnaval.com/coac-2024/que-ni-las-hambre-las-vamo-a-senti/)**
*   **[Donde fuimos Felices](https://www.codigocarnaval.com/coac-2024/donde-fuimos-felices/)**
*   **[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   **[Vuelve ya el 3×4](https://www.codigocarnaval.com/coac-2024/vuelve-ya-el-3x4/)**
*   **[El Joyero](https://www.codigocarnaval.com/coac-2024/el-joyero/)**
*   **[El niño de Isabelita 2](https://www.codigocarnaval.com/coac-2024/el-nino-de-isabelita-2/)**
*   **[Los plácidos domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**

### Escenario Merodio

Comienzo a partir de las 14:00h aproximadamente. En los huecos vacíos no habrá actuaciones durante ese tiempo.

*   –
*   **[La chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   **[Donde fuimos felices](https://www.codigocarnaval.com/coac-2024/donde-fuimos-felices/)**
*   **[Los Chabolis](https://www.codigocarnaval.com/coac-2024/los-chabolis/)**
*   **[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   **[Los plácidos domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**
*   **[La resbalaera](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   **[El Gremio](https://www.codigocarnaval.com/coac-2024/el-gremio/)**
*   **[El baúl de la Piquer](https://www.codigocarnaval.com/coac-2024/el-baul-de-la-piquer/)**
*   **[Vuelve ya el 3×4](https://www.codigocarnaval.com/coac-2024/vuelve-ya-el-3x4/)**
*   **[Que ni las hambre las vamo a senti](https://www.codigocarnaval.com/coac-2024/que-ni-las-hambre-las-vamo-a-senti/)**
*   **[El niño de isabelita 2](https://www.codigocarnaval.com/coac-2024/el-nino-de-isabelita-2/)**

### Escenario Calle Desamparados

Comienzo a partir de las 14:00h aproximadamente. En los huecos vacíos no habrá actuaciones durante ese tiempo.

*   **[Donde fuimos felices](https://www.codigocarnaval.com/coac-2024/donde-fuimos-felices/)**
*   **[Los Chabolis](https://www.codigocarnaval.com/coac-2024/los-chabolis/)**
*   **[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   –
*   **[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   **[El niño de Isabelita 2](https://www.codigocarnaval.com/coac-2024/el-nino-de-isabelita-2/)**
*   **[El Baúl de la Piquer](https://www.codigocarnaval.com/coac-2024/el-baul-de-la-piquer/)**
*   **[Los Plácidos Domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**
*   **[Que ni las hambre las vamo a senti](https://www.codigocarnaval.com/coac-2024/que-ni-las-hambre-las-vamo-a-senti/)**
*   **[Asesinato en el Cádiz Express](https://www.codigocarnaval.com/coac-2024/asesinato-en-el-cadiz-express/)**
*   **[El Joyero](https://www.codigocarnaval.com/coac-2024/el-joyero/)**

### Escenario Esquina Café La Marina

Comienzo a partir de las 14:00h aproximadamente. En los huecos vacíos no habrá actuaciones durante ese tiempo.

*   **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   –
*   **[La Resbalaera](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   **[El Gremio](https://www.codigocarnaval.com/coac-2024/el-gremio/)**
*   **[Los Chabolis](https://www.codigocarnaval.com/coac-2024/los-chabolis/)**
*   –
*   **[La chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   **[El Joyero](https://www.codigocarnaval.com/coac-2024/el-joyero/)**
*   **[Asesinato en el Cádiz Express](https://www.codigocarnaval.com/coac-2024/asesinato-en-el-cadiz-express/)**
*   **[El Baúl de la Piquer](https://www.codigocarnaval.com/coac-2024/el-baul-de-la-piquer/)**
*   **[Vuelve ya el 3×4](https://www.codigocarnaval.com/coac-2024/vuelve-ya-el-3x4/)**

**Datos de interés sobre la Batalla de Coplas 2024**

📅 **Fecha:** Sábado 10 de febrero  
📍 **Lugar:** Mercado Central y alrededores  
🛏 **Ofertas de alojamientos en Booking:** **[Busca en Booking](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)**  
🛏 **El mejor comparador de alojamientos en Cádiz:** **[Mejores precios en Cádiz](https://www.hotelscombined.es/Place/Cadiz.htm?a_aid=178580)**
