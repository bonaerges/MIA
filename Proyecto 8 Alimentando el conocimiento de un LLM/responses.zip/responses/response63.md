Title: Las modalidades del Carnaval de Cádiz - Codigo Carnaval

URL Source: https://www.codigocarnaval.com/modalidades-carnaval/

Published Time: 2021-05-26T14:05:54+02:00

Markdown Content:
El Carnaval de Cádiz se está transformando poco a poco en todo un referente en el panorama nacional, gracias a sus diferentes modalidades que reinan en la fiesta.

La ironía, la sátira, la burla, el doble sentido, la crítica y el humor se funden cada año en los repertorios de las chirigotas, comparsas, coros, cuartetos, romanceros o callejeras durante los meses de enero y febrero (e incluso durante todo el año, gracias a los numerosos eventos)

Y es que el **[Carnaval de Cádiz](https://www.codigocarnaval.com/carnaval-de-cadiz/)** fue capaz de burlar a la censura en tiempos de la dictadura y no se frenó ni siquiera ante un Golpe de Estado como ocurrió en el famoso 23-F.

¿Aún no reconoces las diferentes modalidades? Aquí podrás ver las características principales de cada una,

Chirigotas
----------

![Image 1: Chirigota no aguantamos mas vamos de impacientes](https://www.codigocarnaval.com/wp-content/uploads/2019/11/Chirigota-no-aguantamos-mas-vamos-de-impacientes.jpg.webp)

La **chirigota** representa muchos de los caracteres más puros de la ciudad de Cádiz: La ironía, el doble sentido y la risa forman parte de los repertorios de esta modalidad.

Suelen estar compuestos por un número de **12 componentes**, con una instrumentación formada por 2 guitarras, caja y bombo. Sus repertorios se componen por presentación, pasodobles, cuplés, estribillo y popurrí.

Sus músicas suelen ser más alegres que la chirigota, pese a tocar a menudo los mismos temas. En ocasiones, se suelen tocar temas localistas, pero últimamente suelen encontrarse temas de todo tipo, donde no se dejan ‘títeres sin cabeza’ en especial a los gobernantes o algunas celebridades.

Dentro de la propia chirigota podemos encontrar algunos estilos bien diferenciados. Algunas conocidas como chirigotas clásicas, buscan seguir la herencia de un compás más añejo y clásico, mientras otras agrupaciones buscan romper con lo establecido.

Comparsas
---------

![Image 2: Comparsa La Gaditanissima](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20687'%3E%3C/svg%3E)

La **comparsa** es la modalidad que más pasiones desata, y la que actualmente genera una mayor masa social de seguidores.

Generalmente están compuesto por **15 componentes**, ataviados con 3 guitarras, caja y bombo como instrumentación. La comparsa suele abordar temas más serios, con letras sobre temas sociales o políticos, utilizando la ironía y sobre todo la poesía para la composición de sus repertorios, que se dividen en presentación, pasodobles, cuplés, estribillo y popurrí.

Al conileño Francisco Alba Medina **‘Paco Alba’** se le considera el creador de esta modalidad, ya que sus chirigotas, allá por los años 60 desprendían un estilo muchísimo más fino y serio que el resto de agrupaciones. Por ello, se decidió ubicar esa nueva forma de componer agrupaciones como una nueva modalidad.

#### Más artículos de interés

Coros
-----

![Image 3: cuarteto el cuarteto del more](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20667'%3E%3C/svg%3E)

El coro es una de las modalidades más castizas y señeras del Carnaval de Cádiz. Son el grupo más grande, que suelen aglutinar hasta **45 componentes** (algunos grupos punteros llevan incluso reservas).

La temática de los coros también llevan un híbrido entre el humor y la crítica social o el piropo, siendo estos dos últimos mucho más recurridos que el primero. No obstante, en los últimos años hemos podido comprobar como algunos coros muestran un aspecto mucho más jovial y cómico.

Su repertorio está compuesto por **presentación, tangos, cuplés, estribillos y popurrí**. En cuanto a instrumentación, los coros suelen usar **guitarras, bandurrias y laúdes**, sin usar cajas ni bombos por norma general (aunque algunos pueden hacer uso de ellos en algunas partes determinadas de su presentación o popurrí).

Durante la semana del carnaval en la calle, los coros ofrecen sus repertorios subidos en bateas tiradas por tractores que recorren las calles de la ciudad de Cádiz en los días denominados ‘**[carruseles de coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)**‘.

Cuartetos
---------

![Image 4: cuarteto el cuarteto del more](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20667'%3E%3C/svg%3E)

Los **cuartetos** son a buen seguro una de las modalidades más complicadas del Carnaval de Cádiz. Son el grupo más reducido de los que se presentan al Concurso Oficial de Agrupaciones en el Gran Teatro Falla (COAC).

A pesar del nombre, esta modalidad puede estar compuesto por un mínimo de **tres componentes y un máximo de cinco**. Su instrumentación se basa en las **claves de madera** que lleva uno de los componentes para marcar los ritmos. También usan el pito de carnaval, o más recientemente la guitarra para los finales de popurrí.

Su repertorio **es lo más parecido a una obra de teatro**. En su día, la mayoría de grupos apostaban por versos rimados, aunque a día de hoy existen grupos que no lo hacen. Su misión es hacer reír constantemente al público, algo bastante complicado.

El formato del repertorio del cuarteto se basa en **parodia, cuplés, estribillo y popurrí o tema libre** (aquí cada grupo puede elegir lo que prefiera).

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

Callejeras
----------

![Image 5: Carnaval Cadiz](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20524'%3E%3C/svg%3E)

Las **[agrupaciones callejeras](https://www.codigocarnaval.com/agrupaciones-callejeras/)** o también llamadas **‘ilegales’** forman parte de uno de los reductos más puros de la verdadera esencia del Carnaval de Cádiz.

A diferencia del resto, las agrupaciones callejeras no participan en el concurso oficial del Gran Teatro Falla, ofreciendo sus repertorios en la calle durante la semana de carnaval.

Su estructura es la más anárquica de todas. No existe un número de componentes estipulado, ni un formato concreto a la hora de interpretar el repertorio. Por lo general, las callejeras suelen realizar varias tandas de cuplés.

Su temática es absolutamente libre, y en ocasiones está repleta de humor negro, ironía y doble sentido.

Romanceros
----------

![Image 6: romancero-hulk](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)

Ataviados con un cartelón, **los [romanceros](https://www.codigocarnaval.com/romanceros/)** están compuestos generalmente por una persona, pero también es común verlos de dos componentes.

Estos dedican versos rimados al público, contando una historia acorde a su disfraz, con escenas representadas en su cartel. Es una de las modalidades que menos ha variado a lo largo del tiempo.

Los romanceros también tienen un carácter callejero, aunque esta modalidad también participa en un concurso que se celebra en el Gran Teatro Falla, pero de manera independiente del COAC.
