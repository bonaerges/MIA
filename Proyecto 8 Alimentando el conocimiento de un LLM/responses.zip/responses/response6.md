Title: ▷ ERIZADA 2024 (Carnaval de Cádiz) - Fechas, Agrupaciones...

URL Source: https://www.codigocarnaval.com/erizada/

Published Time: 2019-10-09T10:10:01+02:00

Markdown Content:
La **Erizada Popular** es una de las fiestas gastronómicas más conocidas en la ciudad de Cádiz. Este evento es uno de los que da el pistoletazo de salida al **[Carnaval de Cádiz](https://www.codigocarnaval.com/)**  y donde generalmente pueden oírse las primeras coplas.

En esta ocasión, el concurso estará ya casi terminado por lo que podemos escuchar agrupaciones que ya han participado en el **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)** del Carnaval de Cádiz.

La Erizada 2024 se celebrará el próximo **domingo 4 de febrero** en los aledaños del barrio de La Viña, un evento organizado por la Federación de Peñas y Entidades Caleteras y que en esta ocasión llegará con el concurso alcanzando la fase de semifinales.

Se estima que el evento comenzará a partir de las 13:00h del mediodía.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

Todo lo que debes saber sobre la Erizada
----------------------------------------

### ¿Qué es la erizada?

La erizada es un evento gastronómico, en el cual se degustan erizos de mar, recién cogidos del mar, sirviéndolos bien fresquitos a todos aquellos que quieran probarlos.

### ¿Cómo se come el erizo?

Para comer un erizo, es necesario primero cortarlo por la mitad con un cuchillo, y su carne rojiza del interior es lo que se come. Generalmente, el erizo se come crudo, y tiene un sabor intenso a mar.

También es común comerlos cocidos. Su temporada comprende entre enero y marzo.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Agrupaciones que participan en la Erizada 2024
----------------------------------------------

A lo largo del día, el acto gastronómico estará acompañado por actuaciones de agrupaciones participantes en el COAC 2024 o diferentes antologías de coplas que se darán cita en el escenario que se sitúa en la calle Virgen de La Palma.

*   Antología ‘**De mil colores**‘
*   Antología ‘**La tropa del 3×4**‘
*   Romancero Cuqui y Ketama ‘**El trastero**‘
*   Antología ‘**La chirigota del Noly**‘
*   Antología ‘**José Luis Arniz con el Vaporcito**‘

### Degustación gratuita de Erizos

![Image 1: erizada cadiz](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)

La **Federación de Peñas y Entidades Caleteras** reparte cada año en torno a unos 2500 kilos de erizos para que el público que se acerque al barrio de La Viña pueda degustarlos de manera gratuita.

Aunque también, si uno no quiere esperar colas, es muy común encontrarse a pescadores con una mesa a modo de puesto ambulante para ofrecer una ración de ellos, eso sí, pagando.
