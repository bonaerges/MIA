Title: Artículos - Codigo Carnaval

URL Source: https://www.codigocarnaval.com/category/articulos/

Markdown Content:
[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 1: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/penas-de-carnaval/)

Son las 12 de la mañana de un sábado y por Los Callejones, un cierto aroma a nostalgia impregna la …

[Leer más](https://www.codigocarnaval.com/articulos/penas-de-carnaval/#more-10195"Laspeñas,aquelherviderodecoplas")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 2: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/epoca-bisagra-carnaval/)

En una de esas fantásticas retransmisiones locales del concurso por Onda Cádiz, escuché decirle a Enrique Miranda que andábamos en …

[Leer más](https://www.codigocarnaval.com/articulos/epoca-bisagra-carnaval/#more-10148"UnaépocabisagraenelCarnavaldeCádiz")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 3: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/generacion-tangai-generacion-onda-cadiz/)

El Concurso Oficial de Agrupaciones del Carnaval de Cádiz (COAC) llegó a nuestras casas a través de la pequeña pantalla …

[Leer más](https://www.codigocarnaval.com/articulos/generacion-tangai-generacion-onda-cadiz/#more-10044"GeneraciónTangaiygeneraciónOndaCádiz")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 4: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/cuarteto-mil-formas-hacer-reir/)

El cuarteto siempre ha sido considerada una de las modalidades más complicadas de ejecutar en el concurso del Carnaval de …

[Leer más](https://www.codigocarnaval.com/articulos/cuarteto-mil-formas-hacer-reir/#more-7682"Elcuarteto:milmanerasdehacerreír")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 5: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/paloma-el-alma-del-pay-pay/)

Falta una hora y media para el comienzo del espectáculo, cuando un crujir de maderas se hace eco en el …

[Leer más](https://www.codigocarnaval.com/articulos/paloma-el-alma-del-pay-pay/#more-7641"Paloma,elalmadelPay-Pay")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 6: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/pasodobles-san-valentin/)

El 14 de febrero se celebra el día de San Valentín, es decir, el día de los enamorados. Un día …

[Leer más](https://www.codigocarnaval.com/articulos/pasodobles-san-valentin/#more-5287"PasodoblesparaSanValentin")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 7: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-2010-2020/)

La década de los años 2010 a 2020 cierra una etapa grande en el Carnaval de Cádiz. Volvimos a ver …

[Leer más](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-2010-2020/#more-5168"ElCarnavaldeCádizenlosaños2010-2020")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 8: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-2000-2010/)

Una vez finalizados los próliferos años 90 en el Carnaval de Cádiz, entramos en un nuevo siglo y un nuevo …

[Leer más](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-2000-2010/#more-5149"ElCarnavaldeCádizenlosaños2000-2010")

[Inicio](https://www.codigocarnaval.com/) » Artículos

[![Image 9: carnaval-cadiz-años-90](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20400'%3E%3C/svg%3E)](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-90/)

Una nueva década daba comienzo en el Carnaval de Cádiz. Dejados atrás los años 80, una era de luces y …

[Leer más](https://www.codigocarnaval.com/articulos/carnaval-cadiz-anos-90/#more-5080"ElCarnavaldeCádizenlosaños90")
