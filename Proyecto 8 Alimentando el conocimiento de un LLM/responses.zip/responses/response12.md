Title: COAC 2024 ➤ Fechas, agrupaciones, entradas - Guía Completa

URL Source: https://www.codigocarnaval.com/coac-2024/

Published Time: 2022-06-30T14:15:00+02:00

Markdown Content:
El **COAC** **2024** es el Concurso Oficial de Agrupaciones que se celebra en el Gran Teatro Falla. En él, chirigotas, comparsas, cuartetos y coros luchan por alcanzar el primer premio a lo largo de las diferentes fases del certamen.

**El COAC 2024** contará con 145 agrupaciones inscritas en esta edición, en la cual, 109 serán agrupaciones de la modalidad de adultos. De ellos, habrá 54 comparsas, 35 chirigotas, 15 coros y 5 cuartetos.

En la modalidad infantil habrá 22 agrupaciones (6 comparsas, 8 chirigotas y 8 cuartetos). Mientras que en juveniles habrá 14 agrupaciones (6 comparsas, 4 chirigotas, 3 cuartetos y 1 coro).

*   **Fechas:** Del 9 de enero al 9 de febrero
*   **Pregonero:** Juan Manuel Braza Benítez ‘El Sheriff’
*   **Dios Momo:** David Márquez Mateos ‘David Carapapa’

Fechas COAC 2024 ¿Cuándo empieza?
---------------------------------

El concurso comenzará el próximo **martes 9 de enero de 2024**, extendiéndose durante todo un mes entre todas las modalidades (adultos, juveniles e infantiles) así como en todas sus fases.

**El horario de inicio de todas las sesiones de adultos será a las ocho de la tarde**, mientras que las **funciones de la cantera arrancarán a las doce del mediodía**. Tan sólo la Final de la categoría de juveniles cambiará este horario para dar inicio a las 16 horas. 

### Calendario COAC 2024 – Adultos

*   **Preliminares:** 9 de enero al 25 de enero (20:00h)
*   **Cuartos de Final:** 26 de enero al 1 de febrero (20:00h)
*   **Semifinales:** 4 al 7 de febrero (20:00h)
*   **Gran Final:** 9 de febrero (20:00h)

### Calendario COAC 2024 – Infantiles

*   **Semifinales infantiles:** 13, 14 y 20 de enero (12:00h)
*   **Final Infantil:** 3 de febrero (12:00h)

### Calendario COAC 2024 – Juveniles

*   **Semifinales juveniles:** 27 y 28 de enero (12:00h)
*   **Final Juvenil:** 2 de febrero (16:00h)

![Image 1: Entradas Carnaval Cadiz](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20668'%3E%3C/svg%3E)

Las **entradas para el Carnaval 2024** se pueden conseguir mediante la compra en las taquillas físicas como online, para ello, habitualmente se pone a la venta el 50% del aforo de cada función en ambos formatos.

Los precios de las entradas varían en función de la fase y de la localidad, llegando a rondar entre los 15€ la más barata y 92€ la más cara.

**La venta de entradas físicas no tiene un punto fijo de venta establecido**. Es decir, se suele utilizar el hall (en preliminares) o las taquillas del Gran Teatro Falla para la venta de las mismas, pero también se han utilizado en otras fases edificios como el centro ECCO.

**La puesta a la venta de las entradas suele anunciarse con poco tiempo de antelación**, para evitar que se formen colas y pernoctaciones en los puntos físicos.

**VENTA DE ENTRADAS**  
Si quieres enterarte de todos los detalles necesarios, así como los precios, requisitos y fechas para la venta visita nuestro artículo de **[entradas COAC 2024](https://www.codigocarnaval.com/coac-2024/entradas-2024/)**.

[![Image 2: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/entradas-2024/"EntradasCOAC2024")

[![Image 3: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/jurado-2024/"JuradoCOAC2024")

[![Image 4: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/orden-actuacion-preliminares-2024/"OrdenActuaciónPreliminares2024")

[![Image 5: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/orden-actuacion-semifinales-infantiles-2024/"Ordenactuaciónsemifinalesinfantiles2024")

[![Image 6: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/orden-actuacion-semifinales-juveniles-2024/"Ordenactuaciónsemifinalesjuveniles2024")

Cartel Oficial Carnaval 2024
----------------------------

![Image 7: cartel carnaval de cadiz 2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20500%20625'%3E%3C/svg%3E)

Orden de actuación
------------------

*   **[Orden actuación PRELIMINARES 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-preliminares-2024/)**
*   **[Orden actuación CUARTOS DE FINAL 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-cuartos-2024/)**
*   **[Orden actuación SEMIFINALES 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-semifinales-2024/)**
*   **[Orden actuación GRAN FINAL 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/)**

**Cantera**

*   **[Orden actuación semifinales INFANTILES 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-semifinales-infantiles-2024/)**
*   **[Orden actuación semifinales JUVENILES 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-semifinales-juveniles-2024/)**

Agrupaciones
------------

Pincha en la modalidad que prefieras para ver sus fichas, su información previa y sus actuaciones en el Gran Teatro Falla durante el concurso. Si quieres puedes ver el listado completo de los **[nombres de agrupaciones 2024](https://www.codigocarnaval.com/coac-2024/nombres-agrupaciones-2024/)**.

[![Image 8: CUARTETOS 2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/comparsas-2024/"Comparsas2024")

[![Image 9: CUARTETOS 2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/chirigotas-2024/"Chirigotas2024")

[![Image 10: CUARTETOS 2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/coros-2024/"Coros2024")

[![Image 11: CUARTETOS 2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20450'%3E%3C/svg%3E)](https://www.codigocarnaval.com/coac-2024/cuartetos-2024/"Cuartetos2024")

### Agrupaciones cabezas de serie COAC 2024

Estas son las agrupaciones que formarán parte de las cabezas de serie del COAC 2024 a lo largo de la fase de preliminares. Para el sorteo, se han establecido un total de 20 agrupaciones.

#### Chirigotas

*   **[La callejera invisible](https://www.codigocarnaval.com/coac-2024/la-callejera-invisible/)**
*   **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   **[El grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**
*   **[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)**
*   **[Carnaval, me cago en tus muertos](https://www.codigocarnaval.com/coac-2024/carnaval-me-cago-en-tus-muertos/)**

#### Comparsas

*   **[La oveja negra](https://www.codigocarnaval.com/coac-2024/la-oveja-negra/)**
*   **[Los Colgaos](https://www.codigocarnaval.com/coac-2024/los-colgaos/)**
*   **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   **[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   **[Los Sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   **[La Resbalaera](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   **[Las herederas](https://www.codigocarnaval.com/coac-2024/las-herederas/)**

#### Coros

*   **[Los Luciérnagas](https://www.codigocarnaval.com/coac-2024/los-luciernagas/)**
*   **[Los iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**
*   **[El paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**
*   **[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   **[El gremio](https://www.codigocarnaval.com/coac-2024/el-gremio/)**
*   **[Asesinato en el Cádiz Express](https://www.codigocarnaval.com/coac-2024/asesinato-en-el-cadiz-express/)**
*   **[El baúl de la piquer](https://www.codigocarnaval.com/coac-2024/el-baul-de-la-piquer/)**

#### Cuartetos

*   **[Punk y circo, la lucha continúa](https://www.codigocarnaval.com/coac-2024/punk-y-circo-la-lucha-continua/)**

¿Cómo ir al COAC 2024?
----------------------

Si tienes pensado acudir al **COAC 2024** en el Gran Teatro Falla es posible que tengas algunas dudas sobre que tipo de localidades escoger, o que información necesitas saber antes de acudir al concurso.

En estos dos artículos puedes ver al detalle y solucionar todas tus dudas.

[![Image 12: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/consejos-gran-teatro-falla/"ConsejosGranTeatroFallaparaelCOAC")

[![Image 13: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20628'%3E%3C/svg%3E)](https://www.codigocarnaval.com/aforo-gran-teatro-falla/"AforoGranTeatroFalla")

El Sheriff, pregonero del Carnaval de Cádiz 2024
------------------------------------------------

![Image 14: chirigota los del veredicto](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20533'%3E%3C/svg%3E)

Juan Manuel Braza Benítez ‘**El Sheriff**‘ ha sido elegido como **[pregonero del Carnaval de Cádiz](https://www.codigocarnaval.com/pregon-carnaval-cadiz/)** 2024.

Gaditano, de 55 años, comenzó su carrera en la fiesta en el año 1987, siendo autor de la chirigota ‘**Los Feicios**‘.

Ha alcanzado en dos ocasiones el primer premio en chirigotas, concretamente en el año 1997 con ‘**Los Aleluyas**‘ y en el año 2006, con ‘**Los Aguafiestas**‘. Para este año 2024 se presentará con ‘**[El Grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**‘.

Encarnó la figura del **dios Momo** en 2007, recibió el **antifaz de oro** en el año 2016 y también ha sido **Baluarte del Carnaval de Cádiz** por la Fundación Cruzcampo.

Antifaces de oro 2024
---------------------

Cada año, la asamblea de **Antifaces de Oro** propone entregar este distinguido galardón a autores y componentes del Carnaval de Cádiz con una dilatada trayectoria y que haya tenido gran repercusión en la historia de la fiesta.

Para este 2024, estos son los galardonados

*   Manuel Albaiceta Revuelta
*   Carlos Sibón Pedemonte
*   Alejandro Monzón Cruz
*   José Antonio Flores Pérez **‘Ensaladilla’**
*   Francisco Díaz García **‘Pelahigo’** _(A título póstumo)_

Puedes consultar aquí el listado completo de **[Antifaces de Oro](https://www.codigocarnaval.com/antifaces-de-oro/) del Carnaval de Cádiz**

Las fases del COAC
------------------

![Image 15: Palcos Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20389'%3E%3C/svg%3E)

### Preliminares (9 al 25 de enero)

Las **Preliminares** son la primera fase del concurso en la modalidad de adultos. En ella, gracias a un **[sorteo de orden de actuación](https://www.codigocarnaval.com/coac-2024/orden-actuacion-preliminares-2024/)**, que se celebra en torno a un mes antes, se aglutinan todas las agrupaciones inscritas en el concurso a lo largo del calendario.

Se determinan **agrupaciones cabezas de serie**, gracias a su clasificación en el anterior concurso (generalmente finalistas y semifinalistas), con el fin de garantizar actuaciones de interés durante cada función de las preliminares.

Una vez concluida esta fase, el último día, el jurado del concurso elabora su listado de agrupaciones que pasarán al siguiente corte gracias a un sistema de puntuación que realizan in-situ durante las actuaciones. El número máximo de agrupaciones que pasan a la siguiente fase suele determinarse previamente.

**56 agrupaciones** pasarán a cuartos como máximo (10 coros, 20 chirigotas, 20 comparsas y 6 cuartetos)

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

### Cuartos de Final (26 enero al 1 de febrero)

Los **cuartos de final** son la segunda fase del concurso. Tras el fallo del jurado, las agrupaciones participan en otra fase donde deberán estrenar pasodobles (en caso de chirigotas y comparsas), tangos (en caso de coros) y parodia y tema libre (en cuartetos).

Los cuplés, en todas las modalidades también serán a estrenar, manteniendo únicamente la presentación y el popurrí como piezas fijas si se desea, algo que ocurre en todas las fases, excepto en la Final donde si se puede repetir una pieza (pasodoble, cuplé, tango…)

El orden de actuación lo marcará el calendario de preliminares. Es decir, los que actuaron los primeros días y han conseguido pasar, seguirán haciéndolo los primeros días de cuartos. Eso sí, se realiza un sorteo previo para determinar el orden de actuación dentro de la función, quedando ya inutilizada la fórmula de cabezas de serie.

**32 agrupaciones** como máximo pasarán a semifinales (7 coros, 10 chirigotas, 10 comparsas y 5 cuartetos)

### Semifinales (4 al 7 de febrero)

La fase de **Semifinales** es una de las fases con más calidad del concurso, ya que aquí las agrupaciones tendrán que echar toda la carne en el asador de sus repertorios para conseguir un hueco en la Gran Final.

Al igual que en Cuartos de Final, **el orden de actuación lo marcará el calendario de la fase anterior**.

Una vez actúa la última agrupación, el jurado se reúne para dar el veredicto de las agrupaciones que pasan a la Gran Final. A esta noche se le conoce como la _**‘noche de los cuchillos largos’**_.

### Gran Final (9 de febrero)

Es la última fase del concurso. En la modalidad de adultos pueden pasar hasta un máximo de 4 agrupaciones por modalidad, y en ningún caso se rellenan los huecos con agrupaciones de otras modalidades si uno de esos huecos queda desierto.

La Gran Final del Falla se vive con gran entusiasmo tanto en la ciudad como en muchos rincones de Andalucía, donde los aficionados se reúnen frente al televisor en una jornada maratoniana de coplas de carnaval que dura hasta las primeras horas del día siguiente.

La **[Gran Final del Falla 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/)** tendrá lugar el **viernes 9 de febrero**.

Una vez conocidos los premios, se da comienzo oficialmente al Carnaval de Cádiz en la calle y su programación.

También te puede interesar

Los cambios del COAC 2024 ¿Qué tenemos nuevo?
---------------------------------------------

Una de las principales novedades de estas nuevas bases será el aumento de la cuantía de los premios del certamen en las dos categorías (adultos e infantiles y juveniles) de 112.000 euros, lo que supone un 17% con respecto al pasado año. De este modo, en la categoría de adultos, los premios serán los siguientes: 

*   **500 euros:** Para todas las modalidades en Preliminares.
*   **4.200** **euros:** Para las agrupaciones que pasen a Cuartos de Final.
*   **10.900 euros:** Para los coros que lleguen a Semifinales. **10.450** para las comparsas y chirigotas, y **10.100** para los cuartetos. 

Los primeros premios serían los siguientes.

*   En Coros **25.000 euros** para el primero, **22.300** para el segundo; **21.700** para el tercero; **20.400** para el cuarto y **14.700** para el primer accésit.
*   En Comparsas y Chirigotas serían **21.450** euros para el primero; **19.550** euros para el segundo; **18.950** para el tercero y **18.350** para el cuarto, mientras que el primer accésit se llevaría **12.800** euros.
*   En Cuartetos los premios son **18.100, 17.100, 16.900** y **16.600** euros respectivamente, del primero al cuarto, así como **11.300** euros para el primer accésit. 

Otra de las novedades en las bases estriba en un **cambio en las agrupaciones que pasan a la fase de cuartos de final**, de manera que **se reduce la presencia de coros de doce a diez** y **se aumenta una comparsa y una chirigota**.

Asimismo, se recoge por primera vez la **prohibición de publicidad de bebidas alcohólicas, tabacos, sustancias prohibidas o juegos de azar** en cualquier tipo de soporte y su incumplimiento será considerado una falta muy grave.

En la cantera, que también se ha visto beneficiada por el aumento de los premios, hay una serie de novedades en las bases. Para empezar, **se incluye la definición sobre los componentes que pueden participar en cada categoría** y **no habrá criterios de puntuación como en los adultos**, donde se rigen por una serie de parámetros numéricos.

¿Cómo seguir el concurso y dónde verlo?
---------------------------------------

El **COAC 2024** se puede seguir en directo durante todas las fases del concurso gracias a los diferentes medios de comunicación.

**Televisión:** La cadena local Onda Cádiz TV emite todo el concurso desde las Preliminares hasta la Gran Final en adultos y todas las fases de la cantera. Posteriormente, también suele llegar a acuerdos con otras cadenas como Canal Sur TV o 7TV para que retransmitan diferentes fases.

**Internet:** Para quienes no les llegue la señal de Onda Cádiz, la cadena local emite en streaming el concurso gracias al Livestream a través de su página oficial, así como en su canal de YouTube en directo o en la plataforma Twitch. La cadena andaluza Canal Sur si consigue los derechos también lo suele hacer por su canal Youtube.

**Radio:** También es posible seguir mediante la radio (tradicional u online) el concurso a través de los diferentes diales de radio. Onda Cádiz Radio, Punto Radio, Onda Cero, Cadena Ser, Cadena Cope o Canal Sur emiten el concurso en directo durante todos los días.

**¿CÓMO SEGUIR EL CONCURSO?**  
Si quieres información más ampliada sobre cómo y donde seguir el concurso visita nuestro artículo del **[CONCURSO EN DIRECTO](https://www.codigocarnaval.com/coac-directo-online/)** para enterarte de todo.

Los más pequeños también tienen cabida en el concurso del Carnaval de Cádiz (COAC), en las que participan en dos modalidades en función de su edad: **infantiles** y **juveniles**.
