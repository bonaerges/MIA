Title: ➤ Aforo Gran Teatro Falla - Todo lo que debes saber

URL Source: https://www.codigocarnaval.com/aforo-gran-teatro-falla/

Published Time: 2019-10-09T12:35:10+02:00

Markdown Content:
El Gran Teatro Falla de Cádiz es uno de los iconos más representativos del Carnaval de Cádiz, debido que en él se celebra cada año el COAC (Concurso Oficial de Agrupaciones Carnavalescas).

Fue construido entre 1884 y 1905, sobre las cenizas del otro antiguo teatro que ardió pasto de las llamas debido a un incendio. Se caracteriza sobre todo por su fachada, de ladrillos rojos con estilo mudéjar.

![Image 1: Aforo Gran Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20535'%3E%3C/svg%3E)

El Gran Teatro Falla tiene un aforo de **1214 personas** repartidas entre las diferentes localidades: **butacas, palcos, anfiteatro y gallinero**.

Cabe recordar, que durante el concurso, **no se pone esa cifra en su totalidad**, ya que un porcentaje está destinado a las entradas de protocolo, organizaciones, estamentos y medios de comunicación.

Localidades del Gran Teatro Falla
---------------------------------

Si has decidido **[comprar entradas para el COAC](https://www.codigocarnaval.com/coac-2024/entradas-2024/)** desde el Gran Teatro Falla pero aún tienes dudas sobre qué localidades escoger, te ofrecemos los siguientes datos que seguramente puedan servirte de utilidad.

Os dejamos un video donde se explica como es el Teatro Falla por dentro.

### Patio de Butacas

![Image 2: Patio de butacas Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20533'%3E%3C/svg%3E)

En su zona central, el Teatro Falla goza de un patio de butacas, donde la visibilidad es muy buena. Es una de las zonas más caras, gracias a su comodidad.

Su precio suele rondar durante el concurso entre los 25€ y 90€ aproximadamente entre las Preliminares (las más baratas) y la Gran Final (la más cara).

*   **[Anécdotas y curiosidades sobre el Gran Teatro Falla](https://www.codigocarnaval.com/articulos/curiosidades-gran-teatro-falla/)**
*   **[Consejos antes de ir al Gran Teatro Falla](https://www.codigocarnaval.com/consejos-gran-teatro-falla/)**

### Palco Platea

![Image 3: Palcos Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20389'%3E%3C/svg%3E)

El teatro Falla tiene forma de herradura en su interior. En la planta baja o entresuelo, rodeando al patio de butacas podemos encontrar los palcos platea. Algunos de ellos se reservan para la televisión (Onda Cádiz y Canal Sur), antifaces de oro y protocolos.

Junto a butacas y palcos principales, son las localidades más caras durante el concurso, y también suelen oscilar entre los 30€ y los 95€ durante las diferentes fases del COAC.

### Palcos Principales

![Image 4: Gallinero Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20550'%3E%3C/svg%3E)

En la primera planta podemos encontrar los palcos a los que se accede por pequeños camerinos. Normalmente tienen una capacidad de 4 a 6 personas. 4 butacas, y dos sillas altas al fondo. Esas son las más incómodas, por lo que te recomendamos coger las otras si es posible.

Existen 22 palcos principales, de los cuales en torno a unos 7 se reservan para diferentes protocolos (Jurado Oficial, televisiones, pregonero, movilidad reducida…etc)

En cuanto a precios, tienen el mismo precio que butacas y palcos platea.

### Palco Segundo

![Image 5: Palcos Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20389'%3E%3C/svg%3E)

Están situados en la segunda planta, pero únicamente en la zona de los laterales del teatro. Estos tienen las mismas características que los palcos principales (entre 4 y 6 personas por palco) a diferencia de que estos se sitúan en la segunda planta.

Tienen un precio inferior a los palcos principales, y sus precios varían entre los 25€ y 80€, según la fase a la que se acceda.

### Anfiteatro y anfiteatro delantero

En la segunda planta del teatro también podemos encontrar el anfiteatro, que consta de dos partes: Anfiteatro y Anfiteatro delantero.

Digamos que la segunda planta del Falla la ocuparía una parte central (anfiteatro) y la zona lateral con los Palcos Segunda, tomando como dijimos siempre, la imagen de una herradura.

El anfiteatro delantero son una linea de butacas, en primera fila del primer piso haciendo forma de herradura. Desde ahí, la visibilidad es excelente.

Luego, el anfiteatro se sitúa justo detras del anfiteatro delantero, en torno a unas tres filas de butacas. Aquí hay que tener cuidado, porque hay algunas localidades llamadas de ‘visibilidad reducida’ y es debido a que tienen columnas en algunas zonas que impiden la visualización cómoda al 100% desde la localidad.

El delantero anfiteatro está entre los 25€ y los 80€, mientras que anfiteatro estará entre los 20€ y 70€.

### Paraiso o gallinero

![Image 6: Gallinero Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20550'%3E%3C/svg%3E)

Es la parte más alta del teatro, **la más económica y también por consecuencia la más bulliciosa**. Con capacidad para **400 espectadores**, a los que hay que restar los autores que acceden con su credencial.

**No existen asientos de butacas** como tal como en el resto del teatro, lo que encontramos son largos bancos de madera. Estas localidades no están numeradas, por lo que se recomienda llegar con bastante antelación si se quiere coger un buen sitio.

Los precios del gallinero rondan entre los 15€ y los 45€, dependiendo de la fase del concurso.

El ambigú
---------

![Image 7: Palcos Teatro Falla](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20389'%3E%3C/svg%3E)

El Teatro Falla tiene en la segunda parte una zona de descanso común, llamada **ambigú**. En ella podemos encontrar una barra con todo tipo de bebidas y bocadillos.

Una oportunidad para tomarse algo, reponer fuerzas o airearse, si la agrupación que está en escena no es del agrado.
