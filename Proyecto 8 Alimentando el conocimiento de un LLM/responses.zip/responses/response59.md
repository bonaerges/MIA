Title: ▷ Cabalgata del Humor Carnaval 2024 | Código Carnaval

URL Source: https://www.codigocarnaval.com/cabalgata-del-humor-carnaval-cadiz/

Published Time: 2019-10-15T13:11:08+02:00

Markdown Content:
La cabalgata del humor es uno de los atractivos del segundo sábado de carnaval, recorriendo las calles del casco antiguo de la ciudad.

Está previsto que sea el **sábado 17 de febrero**, en torno a las 19:00 cuando la cabalgata inicie su recorrido que hará por las calles del casco antiguo.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Itinerario Cabalgata del humor Cádiz 2024
-----------------------------------------

**Recorrido:** Salida del Colegio de Santa Teresa – Avda. Duque de Nájera – Rosa – Sagasta – San Pedro – Beato Diego José de Cádiz – San Francisco – Nueva – Plaza de San Juan de Dios

Durante este recorrido, numerosas carrozas y componentes desfilan por las calles de Cádiz en una exposición de la crítica social e ironía que caracteriza al Carnaval de Cádiz.

Datos de interés sobre la Cabalgata del Humor

🗓️ **Fecha:** Sábado, 25 de febrero

📍 **Lugar:** Colegio Santa Teresa (salida)

🛏️ **Ofertas de alojamientos en Cádiz:** **[Busca en Booking](http://bit.ly/33RYCWg)**

🛏️ **El mejor comparador de Alojamientos en Cádiz:** **[Mejores precios en Cádiz](http://www.hotelscombined.es/Place/Cadiz.htm?a_aid=178580)**
