Title: Concurso de Presentaciones 'Holaquilloquepasa' 2024

URL Source: https://www.codigocarnaval.com/concurso-de-presentaciones/

Published Time: 2024-01-30T10:55:58+01:00

Markdown Content:
En la Plaza del Mentidero se llevará a cabo durante la semana de carnaval el XIII Concurso de Presentaciones ‘Holaquilloquepasa’ del Carnaval de Cádiz.

Este evento está organizado por la Asociación y los Comerciantes del Barrio del Mentidero y por su escenario pasarán numerosas agrupaciones del **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)** que decidan inscribirse en este concurso.

El concurso se celebrará en el escenario ubicado en la **Plaza del Mentidero** y en este 2024 se dedicará a **Francisco Moray Velatta ‘Paquito del Mentidero’**.

Las fechas del concurso serán entre los días **13, 14 y 15 de febrero**, a partir de las **20:00h**. Dependiendo del volumen de agrupaciones inscritas, se podría ampliar un día más, al 11 de febrero a partir de las **13:30h**.

La **Gran Final** del concurso de presentaciones se celebrará el **18 de febrero** a partir de las **13:00h**.

Orden actuación Concurso de Presentaciones 2024
-----------------------------------------------

### Domingo 11 de febrero

*   13:00h – Cuarteto infantil ‘Había una vez’
*   13:20h – Comparsa juvenil ‘La Barricada’
*   13:40h – Chirigota infantil ‘A las cuatro nos vemo en lado’
*   14:00h – Comparsa juvenil ‘La ciudad de las Estrellas’
*   14:20h – Comparsa juvenil ‘ La casa del carnaval’
*   14:40h – Comparsa infantil ‘Si yo te contara’
*   15:00h – Chirigota infantil ‘ El maestro chocolatero y sus niños chirigoteros’
*   15:45h – Chirigota ‘Carnaval, me cago en tus muertos’
*   16:15h – Comparsa ‘El paseito’
*   17:00h – Comparsa ‘Que bonita es Cádiz’
*   17:30h – Chirigota ‘ La última y nos vamos’
*   18:00h – Chirigota ‘¡Por fin lo despedimos!’
*   18:30h – Comparsa ‘Donde fuimos felices’
*   19:00h – Chirigota ‘ Los del canal sur’
*   19:30h – Comparsa ‘Los despertadores’
*   20:00h – Comparsa ‘Los ofendiditos’
*   20:30h – Chirigota ‘El niño de Isabelita 2’
*   21:00h – Comparsa ‘Cádiz Puro’
*   21:30h – Comparsa ‘Y seguimos cantando’

### Martes 13 de febrero

*   20:00h – Comparsa Juvenil **‘Los Visitantes’**
*   20:20h – **Campamento de verano gaditano: Er tío Chano**
*   20:40h – Comparsa infantil **‘Las hijas de Neptuno’**
*   21:00h – Cuarteto infantil ‘**Alchicofradía del Shangai a ver si llegamos a Cai’**
*   21:30h – Coro – **[Los Vitamina](https://www.codigocarnaval.com/coac-2024/los-vitamina/)**
*   22:00h – Chirigota – **[Los Super-Ego](https://www.codigocarnaval.com/coac-2024/los-super-ego/)**
*   22:30h – Coro – **[La Coctelera](https://www.codigocarnaval.com/coac-2024/la-coctelera/)**
*   23:00h – Chirigota – **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   23:30h – Comparsa – **[Los Benditos](https://www.codigocarnaval.com/coac-2024/los-benditos/)**
*   00:00h – Coro – **[El Gremio](https://www.codigocarnaval.com/coac-2024/el-gremio/)**
*   00:30h – Chirigota – **[Los Plácidos Domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**
*   01:00h – Comparsa – [**Las Herederas**](https://www.codigocarnaval.com/coac-2024/las-herederas/)

### Miércoles 14 de febrero

*   20:00h – Comparsa Infantil **¡Vaya Cacao de Comparsa!**
*   20:15h – Chirigota **El maestro chocolatero y sus niños chirigoteros**
*   20:20h – Cuarteto infantil **Un cuarteto en peligro de extinción**
*   20:40h – Chirigota infantil **Tochiko mi Kay**
*   21:00h – Cuarteto juvenil **Los que se montan su propia película**
*   21:30h – Comparsa **[Los amuletos](https://www.codigocarnaval.com/coac-2024/los-amuletos/)**
*   22:00h – Coro **[Los iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**
*   22:30h – Comparsa **[La chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   23:00h – Chirigota **[Los de la arritmia al 3×4](https://www.codigocarnaval.com/coac-2024/los-de-la-arritmia-al-3x4/)**
*   23:30h – Coro **[La dama de Cádiz](https://www.codigocarnaval.com/coac-2024/la-dama-de-cadiz/)**
*   00:00h – Comparsa **[Los sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   00:30h – Chirigota **[Los chabolis](https://www.codigocarnaval.com/coac-2024/los-chabolis/)**
*   01:00h – Chirigota [**El niño de Isabelita 2**](https://www.codigocarnaval.com/coac-2024/el-nino-de-isabelita-2/)

### Jueves 15 de febrero

*   20:00h – Cuarteto infantil ‘Vaya elementos’
*   20:20h – Comparsa juvenil **‘El Arca de Cádiz’**
*   20:40h – Cuarteto infantil **‘La vida es así’**
*   21:00h – Comparsa ‘Los Fabricantes**‘**
*   21:20h – Comparsa infantil ‘Si yo te contara’
*   21:30h – Comparsa juvenil ‘Las añejas’
*   22:00h – Coro – **[Los Luciérnagas](https://www.codigocarnaval.com/coac-2024/los-luciernagas/)**
*   22:30h – Comparsa – **[Pueblejito la Frontera](https://www.codigocarnaval.com/coac-2024/pueblejito-la-frontera/)**
*   23:00h – Comparsa – **[La Resbalaera](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   23:30h – Coro – **[La Fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   00:00h – Chirigota – **[Sácamela de la boca](https://www.codigocarnaval.com/coac-2024/sacamela-de-la-boca/)**
*   00:30h – Chirigota – **[El Grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**

Premios Concurso de Presentaciones 2024
---------------------------------------

Los coros, comparsas y chirigotas que obtengan el primer premio recibirán 900€, mientras que el segundo premio se llevará 500€ con una placa conmemorativa para ambos casos.

Para la cantera también habrá un primer premio de 200€ y un segundo de 150€. También habrá un premio especial a la mejor parodia de cuarteto de la cantera con 100€.

### Orden de Actuación de la Final del concurso de Presentaciones ‘Holaquilloquepasa’

*   13:00h – **[La fiesta de los Locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)** _(Segundo premio de Coros)_
*   13:30h – **[Los luciérnagas](https://www.codigocarnaval.com/coac-2024/los-luciernagas/)** _(Primer premio de Coros)_
*   14:00h – **Tritón aqui está tu hija** _(Romancero)_
*   14:10h – **¡Vaya cacao de comparsa!** _(Segundo premio de comparsa Infantil)_
*   14:30h – **Las añejas** _(Primer premio de comparsa juvenil)_
*   15:00h – **Vaya Elementos** _(Segundo premio de cuarteto infantil)_
*   15:30h – **[Los Exageraos](https://www.codigocarnaval.com/coac-2024/los-exageraos/)** _(Chirigota invitada especial)_
*   16:00h – **IA IA OH** _(Romancero)_
*   16:30h – **[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)** _(Segundo premio de chirigotas)_
*   17:00h – **[Donde fuimos felices](https://www.codigocarnaval.com/coac-2024/donde-fuimos-felices/)** _(segundo premio comparsas)_
*   17:30h – **Quillo tómatelo con filosofía** _(romancero)_
*   18:00h – **[El Grinch de Cái](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)** _(primer premio de chirigotas)_
*   18:30h – **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)** _(primer premio de comparsas)_

_\*Imagen de Portada: AVV Mentidero y San Lorenzo_
