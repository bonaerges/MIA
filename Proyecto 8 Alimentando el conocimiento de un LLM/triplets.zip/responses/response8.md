Title: CARNAVAL CHIQUITO 2024 / Carnaval de los Jartibles Cádiz

URL Source: https://www.codigocarnaval.com/carnaval-de-cadiz/carnaval-chiquito/

Published Time: 2019-10-14T12:53:26+02:00

Markdown Content:
El **carnaval chiquito**, o también denominado ‘**carnaval de los jartibles**‘, pone el punto y final al Carnaval de Cádiz.

Los más jartibles, parecen no haberse quedado satisfechos con la semana carnavalera, y como es tradición, al siguiente domingo de la semana se vuelve a celebrar un carnaval mucho menos masificado, más anárquico, pero con las mismas ganas de pasarlo bien.

El centro de Cádiz vuelve a inundarse de papelillos, chirigotas ilegales, charangas y romanceros.

La plaza de abastos, plaza de Las Flores, Torre Tavira, callejones, barrio del Pópulo y aledaños, son los escenarios habituales donde poder disfrutar de la última ración de coplas carnavaleras de 2023.

### Fechas Carnaval Chiquito 2024

Este año, el **Carnaval de los Jartibles 2024** se celebrará el **domingo 25 de** **febrero** por las calles de Cádiz, es decir, una semana después del **[domingo de piñata](https://www.codigocarnaval.com/carnaval-de-cadiz/agenda-domingo-de-pinata/)**.

Si quieres estar al tanto de las agrupaciones que estarán por Cádiz el domingo, síguenos en nuestro **[canal Telegram](https://t.me/codigocarnaval)** donde iremos colgando todas las programaciones y geolocalización en directo.

Programación Carnaval Chiquito
------------------------------

Como puntos calientes para la actuación de las agrupaciones callejeras o ilegales _(como también la denominamos)_, tendremos el **Mercado Central, Palillero, Torre Tavira, Plaza de las Flores, San Agustín, Rosario y aledaños**.

A esto le podemos añadir diferentes eventos que se organiza oficialmente para estas fechas como pueden ser: El carnaval Chiquito de mujeres, la anchoada popular o la recién creada croquetada popular.

Destacar también, que la **Peña La Estrella** suele habilitar un escenario, para que las agrupaciones que quieran puedan actuar en el mismo.

### XIII Carnaval Chiquito de Mujeres 2024

Los alrededores del Mercado Central, volverán a ser nuevamente el punto más neurálgico, con la celebración del **Carnaval Chiquito de Mujeres** organizado por Izquierda Unida y el PCE, donde surgió en 2009 para reivindicar la presencia de la mujer en el carnaval, que contará con un gran número de agrupaciones femeninas que pasarán por su escenario en la **Calle Libertad nº11**, **a** **partir de las 13:00h.**

#### Orden actuación

*   13:00h – **Las zorras del carnaval**
*   13:30h – **El cambio climático**
*   14:00h – **Las cuentacuentos**
*   14:30h – **Cádiz, la exnovia del mar**
*   15:00h – **Las marimorenas**
*   15:30h – **Unos años más**
*   16:00h – **G-LOCAS-TINAS**
*   16:30h – **De venta en venta**
*   17:00h – **Las locas del climax**

### XI Anchoada Popular

La Asociación Carnavalescas Holoturias Caleteras organiza el evento en la barriada La Paz, concretamente en la **calle Fray Pablo de Cádiz** donde se ofrecerá anchoas y boquerones del cantábrico a partir de las 13:00h.

A este evento lo acompañará las actuaciones del coro **[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**, **La antología del Noly** y **Los Cleriguillos.**

### I Croquetada Popular

**El Bar Nuevo V Centenario** organiza esta vez la **primera Croquetada Popular**, situado en el barrio de **San Carlos**, concretamente el la calle Isabel la católica nº 3. El evento dará comienzo a las 13:00h donde se podrá degustar gratuitamente cervezas y croquetas.

¿Qué es y cuando nace el Carnaval Chiquito?
-------------------------------------------

**El carnaval chiquito nace en el año 1987**, impulsado por **Paco Leal**. Su agrupación callejera **‘Autopista hasta Benalup’** había calado muchísimo entre el público, y quedaron con ganas de más.

![Image 1: origen carnaval chiquito - codigo carnaval](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201000%20549'%3E%3C/svg%3E)

De una manera espontánea y esporádica, hicieron una convocatoria a las agrupaciones para el domingo siguiente en la Plaza San Antonio, donde para su sorpresa se unieron varias agrupaciones más bajo el lema ‘Carnaval Chiquito para los más jartibles’.

El Ayuntamiento de Cádiz lo incluye en su programación oficial hasta 2014, pero no organizando ningún acto, ya que siempre se prefirió que este festejo mantuviese su carácter original esporádico.
