Title: LIBROS sobre el Carnaval de Cádiz | Los más buscados ✅

URL Source: https://www.codigocarnaval.com/libros-carnaval-cadiz/

Published Time: 2019-10-16T10:35:50+02:00

Markdown Content:
El **[Carnaval de Cádiz](https://www.codigocarnaval.com/)** está avanzando de manera vertiginosa en los últimos años, y el género ya traspasa lo escénico, para colarse a través de los libros. Te recomendaremos los libros carnaval de Cádiz que no puedes perderte.

Es así, como numerosos autores y escritores, se han sumado a lo largo de los años a dar otro enfoque completamente distinto, o más íntimo sobre nuestra fiesta, ya sea desde el punto de vista histórico, poético, o tocando géneros como la novela.

A continuación, os dejamos una serie de libros que podría interesaros, ya sea para vuestra lectura propia, o bien para hacer un regalo a algún familiar que sea un ‘picao’ en esto del Carnaval de Cádiz.

Las compras están disponibles a través del portal de Amazon, una garantía segura de envío, rapidez y eficacia.

Juan Carlos Aragón
------------------

[![Image 1: El pasodoble interminable](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20337%20512'%3E%3C/svg%3E)](https://amzn.to/3yEKLmE)

El último libro del autor de comparsas, Juan Carlos Aragón Becerra, ‘**[El Pasodoble Interminable](https://amzn.to/3CHKeQP)**‘ transporta al lector al proceso de creación de la comparsa ‘Los Peregrinos’, hasta días antes de saber el veredicto final del jurado del COAC 2017.

Sin lugar a dudas, todo un acierto para aquellos amantes de los versos del autor y sus comparsas.

De **[Juan Carlos Aragón](https://www.codigocarnaval.com/juan-carlos-aragon/)** también podemos encontrar otros títulos, aunque de momento en la mayoría de casos están descatalogados

*   **El Carnaval sin apellidos**
*   **El carnaval sin nombre**
*   **[La risa que me escondes](https://amzn.to/3fyDVcd)** (Poemario)
*   **Los últimos versos del Capitán Veneno**

También está previsto que próximamente salga a la luz su último libro, escrito meses antes de su muerte titulado ‘**El carnaval sin mi**‘, pero de momento ha habido una serie de problemas legales que han impedido su publicación hasta la fecha.

Miguel Ángel García Argüez ‘Chapa’
----------------------------------

El gaditano **[Miguel Ángel García Argüez](https://www.codigocarnaval.com/miguel-angel-garcia-arguez/)**, más conocido coloquialmente como ‘Chapa’, también ha publicado en los últimos años un gran número de novelas, algunas relacionadas con el Carnaval de Cádiz, como la biografía de Ángel Subiela **[‘El corazón del Ángel’](https://amzn.to/3aDDhIm)** o su libro [**‘Doce pájaros sobre el alambre’**](https://amzn.to/3clCSuU).

Si te gusta este autor, algunas novelas suyas que no deberías de perderte, aunque no están relacionadas con el Carnaval de Cádiz son:

*   **[Aguaviento](https://amzn.to/32cxNQf)**
*   **[El bombero de Pompeya](https://amzn.to/3oNIIYh)**

Fernando Macías
---------------

Fernando Macías es uno de los clásicos de esta sección de libros sobre el Carnaval de Cádiz, ya que es uno de los pioneros en publicar novelas sobre esta temática.

[![Image 2: El asesino de comparsistas](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20333%20500'%3E%3C/svg%3E)](https://amzn.to/3z5Gt94)

Debutó hace varios años con su saga ‘**[El asesino de comparsistas](https://amzn.to/3O7Si32)‘**, una original novela negra que ha conseguido embaucar a muchísimos lectores.

En la actualidad podemos encontrar hasta 3 partes de esta saga

*   **[El asesino de Comparsistas](https://amzn.to/3Psh9zn)**
*   **[El asesino de Comparsistas 2: Tras la máscara](https://amzn.to/3aBWf2k)**
*   **[El asesino de Comparsistas 3: La última cuarteta](https://amzn.to/3Pt2xA2)**

Posteriormente, ha editado otros libros como ‘**[Yo me enamoré de ti por culpa de los carnavales](https://amzn.to/3l11cDM)**‘. En esta ocasión, se aparta el género de novela negra, para acercarnos a una reflexión amorosa, sobre adolescentes, la vida y por supuesto, con el Carnaval de Cádiz como fondo.

Otra que tampoco podemos perdernos es ‘**[Loquito por verte a mi vera](https://amzn.to/3nGt0ip)**‘ o ‘**[MicroCádiz](https://amzn.to/3xd2KPL)**‘ junto a Cristina Gómez del Amo, presentan una serie de pequeños cuentos relacionados con Cádiz y su carnaval.

Fran Reyes
----------

[![Image 3: salud febrero y amor](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20333%20499'%3E%3C/svg%3E)](https://amzn.to/3RyNkxU)

B. despierta en la cama de un hospital sin ningún recuerdo salvo que tiene que ir lo antes posible a Cádiz y encontrar al chico del que está enamorada.

Así, comienza una búsqueda, una aventura entre el laberinto de recuerdos y secretos que es Cádiz, y la acompañaremos a entrar en el universo del Palacio de las Coplas. «Cada copla tiene un corazón latiendo dentro en cada momento, el de quien la compone, el de quien la canta, y el de quien la oye y la hace suya.»

**[Salud, febrero y amor](https://amzn.to/3SVidxK)** es una obra de Fran Reyes.

Luis Rossi
----------

[![Image 4: el concurso perdido de gades](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20335%20500'%3E%3C/svg%3E)](https://amzn.to/3e23G4j)

**[El concurso perdido de Gades](https://amzn.to/3e23G4j)**, es una novela del periodista Luis Rossi, que juega con mucha audacia con el rigor histórico y la ficción para contar una aventura con el Carnaval de Cádiz como trasfondo. Las coplas, traducidas al latín, van guiando una historia ágil que reflexiona, con tintes de un humor desternillante, sobre el valor de lo que se pierde y el amor por recuperar la esencia de la identidad de la tierra.

Manuel Salguero
---------------

El conileño **Manuel Salguero** es otro de los autores más activos con respecto a novelas relacionadas con el Carnaval de Cádiz, ya que hasta la fecha ha publicado hasta cuatro libros.

Rafael Pastrana
---------------

El autor de comparsas y coros, **Rafael María Pastrana Lorenzo**, se lanza al mundo literario con un par de libros que seguro que no te dejarán indiferente. Y no únicamente por su nombre.

**[Sexo, Droga y Carnaval:](https://amzn.to/3Eczxdp)** En ella conoceremos algunos de los trapos sucios y oscuros de la fiesta, un enfoque completamente original, que a buen seguro atraerá al lector desde las primeras páginas.

**[Roja, puta y gaditana:](https://amzn.to/3SRp9f9)** Literatura gamberra, cruda, sin filtro ni corrección política. 1936. En España está a punto de estallar la Guerra Civil. En el corazón de María, los carnavales de Cádiz.

Jaime Cedillo
-------------

[![Image 5: el carnaval birlado](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20357%20499'%3E%3C/svg%3E)](https://amzn.to/3RzKc4L)

El joven poeta toledano ‘Jaime Cedillo’ hace un análisis de la obra de Juan Carlos Aragón Becerra a lo largo del Carnaval de Cádiz en su libro ‘**[Juan Carlos Aragón, el carnaval con mayúsculas](https://amzn.to/3RzKc4L)**‘

Cristina Braza
--------------

[![Image 6: tras los versos del capitan veneno](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20192%20266'%3E%3C/svg%3E)](https://amzn.to/3UTEg9P)

**Cristina Braza** nos revela cuestiones de la obra de J.C. Aragón que hasta ahora no han sido puestas en valor desde una perspectiva filológica y literaria.

En ‘**[Tras los versos del Capitán veneno](https://amzn.to/3UTEg9P)**‘ Nos adentramos en el mundo controvertido del filósofo e irreverente autor gaditano, y más concretamente, en su universo poético, donde se contemplan temas como el amor y la figura de la mujer, la problemática social y política, la cuestión filosófica y metafísica, la religión y el problema de la fe, y el canto a la tierra.

Manolo Camacho
--------------

[![Image 7: el carnaval birlado](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20357%20499'%3E%3C/svg%3E)](https://amzn.to/3yelsIA)

Con una pandemia por culpa del coronavirus, el Carnaval de Cádiz 2021 no ha podido celebrarse, pero el periodista **Manolo Camacho** ha creado un proyecto a modo colaborativo, en el que varios autores del Carnaval de Cádiz se han unido para rellenar este libro de coplas titulado ‘**[El carnaval birlado](https://amzn.to/3yelsIA)**‘ que no pudieron ver la luz en 2021.

Historia del Carnaval de Cádiz
------------------------------

A continuación os dejamos con algunos libros que hacen referencia al Carnaval de Cádiz y su historia. Una buena elección para conocer las raíces de nuestra fiesta y otros puntos de vista muy interesantes.

📌 **[La Final del Falla:](https://amzn.to/3fzf8ot)** Esta obra, muestra cómo se lleva a cabo la realización televisiva del COAC. En ella se hace un recorrido histórico por la presencia de la televisión en el concurso con testimonios de autores, periodistas y realizadores de televisión.

📌 **[El carnaval en las coplas, un arte de Cádiz:](https://amzn.to/3RxbVmz)** Libro de carácter de ensayo, escrito por Maria Luisa Páramo. Este ejemplar pretende ir un poco más allá, y habla de las raíces culturales o la diversidad de las agrupaciones en el Carnaval de Cádiz. Un análisis exhaustivo de como la ciudad de Cádiz sirve de inspiración a numerosos artistas, que cada año postran miles de letras y músicas inéditas.

📌 [**Historia general del Carnaval de Cádiz: De Las Viejas Ricas a Juan Carlos Aragón**:](https://amzn.to/3rp8GDn) Un recorrido histórico por los inicios del Carnaval de Cádiz resolviendo muchas de las dudas que a día de hoy tenemos en la fiesta.

📌 **[La Canción de Cádiz:](https://amzn.to/3y9AsXZ)** Un viaje a la historia de la comparsa gaditana desde su creación con Paco Alba hasta nuestros días con hitos en el camino como el que supusieron Los Beatles de Cádiz de Enrique Villegas o Antonio Martínez Ares con Los piratas.

📌 **[**Al habla con el Moreno y Chatín: puntas y puntales de Paco Alba (1928-2018**)](https://amzn.to/3ydcCei):** la intrahistoria de las Fiestas Típicas Gaditanas, a través de las vicisitudes de dos destacados comparsistas, ambos adscritos a un maestro: Paco Alba (1918-2018), del que se cumple el centenario de su nacimiento.

📌 **El habla de Cádiz:** no es un libro sobre Carnaval al uso, pero es un libro indispensable para regalar a cualquier gaditano o sobre todo, a quien le guste nuestra tierra. Básicamente es un diccionario sobre el vocabulario de Cádiz y su gente, para entender aquellas palabras más gaditanas como ‘Bastinazo’, que tan curiosas son al resto.

Otros libros que recomendamos son:

*   **[Las coplas del Carnaval de Cádiz de la Segunda República](https://amzn.to/3SOjfv6)** (Santiago Moreno)
*   **[Cómo hacer una agrupación callejera del Carnaval de Cádiz](https://amzn.to/3fHJVQd)** (David Medina)
*   **Cádiz, cuna de dos cantes** (Javier Osuna)
*   **Entre lo divino y lo humano** (Antonio Martínez Ares)

Algunos de estos libros están descatalogados, como es el caso del de Martínez Ares, otros los podrás encontrar o encargar en algunas librerías gaditanas, como la librería ‘Manuel de Falla’.

*   [956227406](tel:+34956227406)
*   [info@libreriamanueldefalla.es](mailto:info@libreriamanueldefalla.es)

📌 **[Carne de carnaval:](https://amzn.to/3e1EBXs)** Una novela narrativa escrita por David Montiel, en el que un gaditano buscavidas recibe un encargo que le llevará a una espiral de intrigas, polémicas, dinero y mafias, con el Carnaval de Cádiz como nexo de unión en la trama principal.

📌 **[Cuaderno de Mari Pepa Marzo – Glosario de los tipos y coplas del Carnaval de Cádiz (1821-2020)](https://amzn.to/3C6wAsf)**: La polifacética Ana Barceló, más conocida como ‘Mari Pepa Marzo’ gracias a sus locuciones y descripciones de tipos en Canal Sur Radio edita un glosario muy interesante.

📌 **[Del Falla a La Caleta:](https://amzn.to/3STqmTf)** Una novela escrita por el autor de agrupaciones Antonio Rivas. Un libro dentro de otro libro donde se repasan unas cuatrocientas agrupaciones. Una novela y a la vez un análisis histórico y carnavalesco.

📌 **[Eterno Febrero:](https://amzn.to/3ruOikg)** Cádiz, carnaval y poesía. Esas son las tres palabras que definen esta obra, un libro donde diferentes poemas se alternan con imágenes de Cádiz y su fiesta por excelencia: el carnaval.

📌 **[En la ciudad de Cádiz](https://amzn.to/3C5g77E)**: En la ciudad de Cádiz existe un templo al que cada febrero peregrinan cientos de personas para rendirle culto y contarle, cantando, lo que ha sucedido en el mundo el último año. Un recinto sagrado de ladrillos ‘coloraos’ que durante un mes centra las miradas y los oídos de miles de aficionados al Carnaval en toda España.

📌 **[Carnaval Pop](https://amzn.to/3Ec3rOL)**: Fernando Lobo nos lleva a explorar la representación del Carnaval de Cádiz a través de otros géneros musicales.

📌 **[El valor turístico de las agrupaciones callejeras del Carnaval de Cádiz](https://amzn.to/3fyDVcd)**: Un interesante proyecto de Carlos Lendínez donde se debate si se están aprovechando correctamente los recursos del Carnaval de Cádiz en ámbitos de márketing y valores turísticos.
