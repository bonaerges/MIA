Title: ▷ Concurso Peña La Estrella 2023 (Tablao Plaza Candelaria)

URL Source: https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/

Published Time: 2019-10-16T20:50:34+02:00

Markdown Content:
La Asociación **Peña Cultural Carnavalesca La Estrella**, fundada el 21 de febrero de 1959 vuelve a organizar un año más sus concursos durante la semana del **Carnaval de Cádiz**.

Situada en el corazón de la **Plaza de Candelaria**, esta peña establece diversos premios con un tablao que se sitúa en la esquina de la plaza.

Allí, y durante la semana del carnaval en la calle, irán pasando numerosas agrupaciones de diferentes modalidades que han participado en el COAC.

**TABLAOS Y ESCENARIOS EN CÁDIZ  
**Si quieres ver todos los **[tablaos y escenarios del Carnaval de Cádiz](https://www.codigocarnaval.com/los-tablaos-del-carnaval-de-cadiz/)**, con su agenda y agrupaciones que actuarán cada día no te pierdas nuestro artículo más completo.

**Los premios que se otorgan son:**

*   Premio **Cañamaque**, a la mejor letra de cuplé (800€ / 650€ / 500€)
*   Premio **Tío de la Tiza** a la mejor letra de tango (1100€ / 800€ / 650€)
*   Premio **Paco Alba**, a la mejor letra de pasodoble (800€ / 650€ / 500€)
*   Premio **Agüillo**, a la mejor parodia de cuarteto (400€ / 300€ / 200€)
*   Premio **‘Manuel Merello’** al mejor estribillo y **‘Manuel Torres’** al mejor tipo (400€)

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Programación Peña La Estrella – Plaza de Candelaria
---------------------------------------------------

### Sábado 10 de febrero

*   15:30 – **[La Piñata](https://www.codigocarnaval.com/coac-2024/la-pinata/)**
*   16:00 – **[La Coctelera](https://www.codigocarnaval.com/coac-2024/la-coctelera/)**
*   16:30 – **[Los Vitamina](https://www.codigocarnaval.com/coac-2024/los-vitamina/)**
*   17:00 – **[La Dama de Cádiz](https://www.codigocarnaval.com/coac-2024/la-dama-de-cadiz/)**
*   17:30 – **[Los Luciérnagas](https://www.codigocarnaval.com/coac-2024/los-luciernagas/)**
*   18:00 – **[El Paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**
*   18:30 – **[La Fiesta de los Locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   19:30 – **[Los Iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**

### Domingo 11 de febrero

*   14:30h – **[El Paseíto](https://www.codigocarnaval.com/coac-2024/el-paseito/)**
*   15:00h – **[Por fin lo despedimos](https://www.codigocarnaval.com/coac-2024/por-fin-lo-despedimos/)**
*   15:30h – **[Los Despertadores](https://www.codigocarnaval.com/coac-2024/los-despertadores/)**
*   16:00h – **[Los Benditos](https://www.codigocarnaval.com/coac-2024/los-benditos/)**
*   16:30h – **[Los ofendiditos](https://www.codigocarnaval.com/coac-2024/los-ofendiditos/)**
*   17:00h – **[Las Herederas](https://www.codigocarnaval.com/coac-2024/las-herederas/)**
*   17:30h – **[Sácamela de la boca](https://www.codigocarnaval.com/coac-2024/sacamela-de-la-boca/)**
*   18:00h – **[Vuelve ya el 3×4](https://www.codigocarnaval.com/coac-2024/vuelve-ya-el-3x4/)**
*   18:30h – **[Los de la arritmia al 3×4](https://www.codigocarnaval.com/coac-2024/los-de-la-arritmia-al-3x4/)**
*   19:00h – **[Con lo bonito que era](https://www.codigocarnaval.com/coac-2024/con-lo-bonito-que-era/)**
*   19:30h – **[No eres tú, soy yo: Los egocéntricos](https://www.codigocarnaval.com/coac-2024/los-egocentricos/)**
*   20:00h – **[Carnaval, me cago en tus muertos](https://www.codigocarnaval.com/coac-2024/carnaval-me-cago-en-tus-muertos/)**
*   20:30h – **[He vuelto (El Barrio)](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/)**
*   21:00h – **[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)**

### Lunes 12 de febrero

*   13:00h – [**En mi caseta cabe todo el mundo**](https://www.codigocarnaval.com/coac-2024/en-mi-caseta-cabe-todo-el-mundo/)
*   13:30h – **[El malo más malote de las pelis de Harry Potter](https://www.codigocarnaval.com/coac-2024/el-malo-mas-malote-de-las-pelis-de-harry-potter/)**
*   14:00h – **[Los sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   14:30h – **[Los amuletos](https://www.codigocarnaval.com/coac-2024/los-amuletos/)**
*   15:00h – **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   15:30h – **[Que bonita es Cádiz](https://www.codigocarnaval.com/coac-2024/que-bonita-es-cadiz/)**
*   16:00h – **[Cadígenas](https://www.codigocarnaval.com/coac-2024/cadigenas/)**
*   16:30h – **[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   17:00h – **[El Grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**
*   17:30h – **[Pueblejito de la frontera](https://www.codigocarnaval.com/coac-2024/pueblejito-la-frontera/)**
*   18:00h – **[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   18:30h – **[Los coco de Cadi](https://www.codigocarnaval.com/coac-2024/los-cocos-de-cadi/)**
*   19:00h – **[La resbalaera, una comparsa de toda la vida…](https://www.codigocarnaval.com/coac-2024/la-resbalaera/)**
*   19:30h – **[Los plácidos domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**
*   20:00h – **[La chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   20:30h – **[Los poquito a poco](https://www.codigocarnaval.com/coac-2024/los-poquito-a-poco/)**
*   21:00h – **[Los super – ego](https://www.codigocarnaval.com/coac-2024/los-super-ego/)**

### Viernes 16 de febrero

Este viernes, a partir de las 17:00h habrá actuaciones de agrupaciones de la cantera del Carnaval de Cádiz.

*   Chirigota – **A las cuatro nos vemo en la dó**
*   Comparsa – **El batallón del Papelillo**
*   Comparsa – **Si yo te contara**
*   Cuarteto – **Había una vez**
*   Cuarteto – **Un cuarteto en peligro de extinción**
*   Chirigota – **Tochiko Mikay**
*   Chirigota – **El maestro chocolatero y sus chiquillos chirigoteros**
*   Cuarteto – **La vida es así**
*   Comparsa – **Las hijas de Neptuno**

### Domingo 18 de febrero

A partir del domingo 18 de febrero se realizará el popular frito gaditano, donde se repartirá pescaíto frito entre los asistentes.

Además, tendrá lugar la entrega de premios a las agrupaciones galardonadas en el concurso, con la actuación de las mismas.

**Orden actuación**

*   12:30h – **[Los Sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   13:00h – **[El Paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**
*   13:30h – **[Los iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**
*   14:00h – **[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**
*   15:30h – **[Una chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**
*   16:30h – **[Los Plácidos Domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**
*   17:00h – **[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**
*   18:00h – **[He vuelto: El barrio](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/)**
*   18:30h – **[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)**
*   19:00h – **[La chirigotera](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**
*   19:30h – **[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**
*   20:30h – **[El Grinch de Cai](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**

Premios Peña la Estrella 2024
-----------------------------

### Premio Tío de la tiza a la modalidad de coros

*   1 Premio (1.100 euros) ‘**[Los iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**‘
*   2 Premio: (800 euros) ‘**[El paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**‘
*   3 Premio (650 euros): ‘**[La fiesta de los locos](https://www.codigocarnaval.com/coac-2024/la-fiesta-de-los-locos/)**‘

### Premio Paco Alba a la modalidad de comparsa

1.  11 Premio (800 euros) ‘**[Los sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**‘
2.  22 Premio (650 euros) ‘**[La alegría de Cádiz](https://www.codigocarnaval.com/coac-2024/la-alegria-de-cadiz/)**‘
3.  33 Premios (500 euros) ‘**[Y seguimos cantando](https://www.codigocarnaval.com/coac-2024/y-seguimos-cantando/)**‘

### Premio Cañamaque a la modalidad de chirigotas

1.  11 Premio (800 euros) ‘**[El grinch de Ca](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)**i’
2.  22 Premio (650 euros) ‘**[Los plácidos domingos](https://www.codigocarnaval.com/coac-2024/los-placidos-domingos/)**‘
3.  33 Premios (500 euros) ‘**[La última y nos vamos](https://www.codigocarnaval.com/coac-2024/la-ultima-y-nos-vamos/)**‘

### Premio Agüillo a la modalidad de cuarteto

*   Primer premio (400 euros) ‘**[Los cocos de Cad](https://www.codigocarnaval.com/coac-2024/los-cocos-de-cadi/)**i’
*   Segundo premio (300 euros) ‘**[He vuelto (El Barrio)](https://www.codigocarnaval.com/coac-2024/he-vuelto-el-barrio/)**‘

### Premio Miguel Merello al mejor estribillo:

*   ‘**[Las chirigoteras](https://www.codigocarnaval.com/coac-2024/la-chirigotera/)**‘ (400 euros)

### Premio Manolo Torres al mejor tipo

*   ‘**[La chirigota clásica](https://www.codigocarnaval.com/coac-2024/la-chirigota-clasica/)**‘ (400 premios)

Galardones Peña La Estrella 2024
--------------------------------

Cada año, la Peña La Estrella otorga sus distinciones anuales a diversos colectivos o personalidades relacionadas con la fiesta.

Para este 2024, la **estrella de oro** recae en **José Antonio Alvarado Ramírez**, en reconocimiento a su trayectoria como autor carnavalesco. Impulsor junto a otros aficionados hispalenses de la Chirigota de Sevilla, esa que llegó en 2006 marcando un hito histórico como llevar a la Final del Concurso de Agrupaciones un grupo sevillano por primera vez en su historia

La estrella de plata será para ‘**Las Niñas de Cádiz**‘, que desde 2018 como compañía y mucho antes como parte del grupo de teatro Caramba, de la Universidad de Cádiz, han tendido un puente de arte entre la calle y los clásicos grecolatinos.

Una compañía teatral distinguida y reconocida con importantes premios como el MAX a al mejor espectáculo revelación, donde Ana López Segovia, Rocío Segovia, Alejandra López y Teresa Quintero recogen el arte milenario de lo teatral y la comedia para contar sobre el escenario cómo las cuestiones más universales son las mismas que pasean por nuestras calles; con la capacidad de transformarse de actrices a cuarteteras, romanceras o chirigoteras; eso sí todo en el Carnaval callejero, y es por eso, por su enorme trabajo llevando a Cádiz por bandera, por lo que se les reconoce méritos más que sobrados para recibir el nombramiento de la Peña.

Igualmente, el título de Socio de Honor y la Estrella de Plata lo recibirá también **Rafael Burgal Jiménez-Mena**, periodista y redactor de Diario de Cádiz, quien entre otras funciones, ilustra con sus crónicas, la crítica del paso de las agrupaciones de Carnaval por el Concurso Oficial de Agrupaciones de Cádiz

También concede el Titulo de Socio de Honor y la ESTRELLA DE PLATA a: **Pelayo García Borbolla**, industrial gaditano, recién jubilado, quien al frente del Bar Terraza se ha ganado el reconocimiento de sus clientes, muchos de ellos reconvertidos en amigos y que ha estado involucrado en todos los asuntos relacionados con la vida social de nuestra ciudad, Rey Mago, Gaditano del año, y varios etcéteras más.

Y finalmente, acuerda conceder el Titulo de Socio de Honor y la ESTRELLA DE PLATA a: **Lola Cazalilla Ramos**, hasta hace bien poco, Concejala de Fiestas del Ayuntamiento gaditano, y responsable de todo lo relacionado con el Carnaval de Cádiz.
