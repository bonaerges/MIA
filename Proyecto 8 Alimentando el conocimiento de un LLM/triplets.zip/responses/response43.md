Title: AUTORES CARNAVAL CADIZ - Guía Carnavalera

URL Source: https://www.codigocarnaval.com/autores-carnaval-cadiz/

Published Time: 2023-05-25T11:20:17+02:00

Markdown Content:
Bienvenidos al archivo de **Autores Carnaval de Cádiz**, en este apartado podrás conocer, pinchando en su ficha correspondiente toda la información sobre algunos de los autores más destacados de la fiesta y del **[COAC](https://www.codigocarnaval.com/coac-2024/)**.

Podrás acceder a su currículum carnavalesco, donde visualizarás todas sus agrupaciones. También tendrás disponible su palmarés, donde se podrá consultar todos los premios conquistados así como una breve historia sobre el autor en cuestión y su relevancia en el mundo del Carnaval de Cádiz.

Autores Carnaval de Cádiz
-------------------------

[![Image 1: Antonio Martínez Ares](https://www.codigocarnaval.com/wp-content/uploads/2021/06/Antonio-Martinez-Ares.jpg.webp)](https://www.codigocarnaval.com/antonio-martinez-ares/"AntonioMartínezAres")

[![Image 2: German Rendon](https://www.codigocarnaval.com/wp-content/uploads/2021/06/German-Rendon.jpg.webp)](https://www.codigocarnaval.com/german-rendon/"GermánRendón")

[![Image 3: hermanos carapapas](https://www.codigocarnaval.com/wp-content/uploads/2021/06/hermanos-carapapas.jpg.webp)](https://www.codigocarnaval.com/hermanos-carapapas/"HermanosCarapapas")

[![Image 4: Joaquin Quiñones](https://www.codigocarnaval.com/wp-content/uploads/2021/12/Joaquin-Quinones.jpg.webp)](https://www.codigocarnaval.com/joaquin-quinones-madera/"JoaquínQuiñonesMadera")

[![Image 5: El Selu Garcia Cossio](https://www.codigocarnaval.com/wp-content/uploads/2021/08/El-Selu-Garcia-Cossio.jpg.webp)](https://www.codigocarnaval.com/jose-luis-garcia-cossio-el-selu/"JoséLuisGarcíaCossío‘ElSelu’")

[![Image 6: Juan Carlos Aragon](https://www.codigocarnaval.com/wp-content/uploads/2021/06/Juan-Carlos-Aragon.jpg.webp)](https://www.codigocarnaval.com/juan-carlos-aragon/"JuanCarlosAragón")

[![Image 7: Kike Remolino](https://www.codigocarnaval.com/wp-content/uploads/2021/06/Kike-Remolino.jpg.webp)](https://www.codigocarnaval.com/kike-remolino/"KikeRemolino")

[![Image 8: Manolin Santander](https://www.codigocarnaval.com/wp-content/uploads/2024/04/Manolin-Santander.jpg.webp)](https://www.codigocarnaval.com/manolin-santander-grosso/"ManolínSantanderGrosso")

[![Image 9: Manolo Santander](https://www.codigocarnaval.com/wp-content/uploads/2021/06/Manolo-Santander.jpg.webp)](https://www.codigocarnaval.com/manolo-santander/"ManoloSantander")

[![Image 10: Tino Tovar](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20675'%3E%3C/svg%3E)](https://www.codigocarnaval.com/miguel-angel-garcia-arguez/"MiguelÁngelGarcíaArgüez")

[![Image 11: Tino Tovar](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20675'%3E%3C/svg%3E)](https://www.codigocarnaval.com/paco-alba/"PacoAlba")

[![Image 12: Tino Tovar](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20675'%3E%3C/svg%3E)](https://www.codigocarnaval.com/tino-tovar-verdejo/"TinoTovarVerdejo")

Todavía nos faltan muchos autores relevantes del Carnaval de Cádiz que iremos añadiendo a lo largo del tiempo a nuestro listado.
