Title: La guía de ROMANCEROS 2024 (Carnaval de Cádiz)

URL Source: https://www.codigocarnaval.com/romanceros/

Published Time: 2024-01-31T11:51:18+01:00

Markdown Content:
Listado recopilatorio de **Romanceros** que saldrán en este Carnaval de Cádiz por las calles de la ciudad para presentarnos sus obras.

Si ves algún error o no está el tuyo en el listado puedes proporcionarnos tu información a través de un correo electrónico en el apartado de contacto.

Si estás interesado/a también puedes visitar el listado de **[agrupaciones callejeras](https://www.codigocarnaval.com/agrupaciones-callejeras/)** del Carnaval de Cádiz

*   **30 monedas** – (Abraham Gil Sánchez)
*   **¡Dios mio que patinaso!** – (Susana Benitez y Pepe Baro) – ( en 2023: ¡Qué ruina de Mercromina!)
*   **¡Quillo, tomatelo con filosofía!** – (Javier Outon Porras) – ( en 2023: Quillo, relativiza un poco)
*   **¿Nosferatuuuuuu… Er papi?** – (Juan Antonio García Rodríguez y el ‘Toba’) – ( en 2023: Ojú que calor, el romancero que nadie había pedido)
*   **Anunnakis inmortales de la playa de los corrales** – (Carmen Verdugo y Paco Ladrón ) – ( en 2023: Sosiasión defensora del traje de piconera)
*   **Aquellos rublos antiguos** – (Manuel Santamaria ‘el Santa’) – ( en 2023: El mensajero)
*   **Aquí manda el señorito** – (Manuel Rodan ‘Lin’) – ( en 2023: Cuidado con la cabeza que este verdugo es una pieza )
*   **Barbi, contar la verdad pa seguir viva** – (Agustín Casado) – Nuevo romancero
*   **Basado en hechos reales** – (María González Lozano, Belén González y Rafa González)) – ( en 2023: Nos quedaron secuelas al cambiarnos al Columela)
*   **Black Lives Matter** – (Alejandro Fernández Jiménez) – (En 2023: Un romancero de tronío)
*   **Cadifornikeishon** – (Juan Antonio Andrade y Begoña Fuentes) – ( en 2023: Miércoles Santo)
*   **Carmen y Latina, basadas en historias reales** – (Mª Carmen Laínez) – Nuevo romancero
*   **Con los muertos de mi pare** – (José Pereira) – (en 2023: Te la via meté doblá)
*   **Con mi mono de faena** – (Agustín Barba y Pedro Barba) – (en 2023: Terminator, los Cyborg de la bahía)
*   **Dos cabras locas** – (Antonio Alonso Revuelta y Luis Padilla Díaz) – (en 2023: El pospecto)
*   **Dragon Ball, pero la parte de Goku niño nada mas** – (Marco Santamaria – Romancero infantil) – ( en 2023: El entrenador Pokémon)
*   **Eau de toillete ‘egoist’ pour homme de Paco Pararabanelmio** – (Jorge Sánchez y Paco Marín) – Nuevo romancero
*   **El forajido** – (Fernando Álvarez Sáez Javier Álvarez) – ( en 2023: Farolillo de Moscú)
*   **El que abandonó el Himalaya porque era más de playa** – (Francisco Muñoz Camacho) – ( en 2023: Los sonotones sordos, sordos de cojones)
*   **El quinto coño** – (Nazaret Jiménez) – ( en 2023: Lo que me sale del coño)
*   **El romancero** – (Francisco J Benítez y Javier Sánchez) – ( en 2023: El planeta de los perros)
*   **El romancero más malo del mundo** – (Javier Álvarez y Fernando Álvarez) – (en 2023: Farolillo de Moscú)
*   **El terapeuta** – (Abraham Andrade y David Medina) – ( en 2023: Este guardia sabe latín)
*   **El trastero** – (Rafa Piñero ‘Cuqui’) – ( en 2023: Memorias del cabo Oreja)
*   **El trepa** – (Juan Cea Valls y María Cea Pérez) – Nuevo romancero
*   **En Madrid la sanidad no parece de verdad** – (Ángel Alcaide ‘el loco de la muleta’) – ( en 2023: Cuento de carnaval)

*   **Er viudo** – (Manuel Sánchez Cerpa ‘El Melena’) – ( en 2023: Er callehero)
*   **Este año vengo con un objetivo** – (Víctor L. Gómez) – ( en 2023: Clotildo el babeta, el dios de la cerveza)
*   **Herminia** – (David Caro Betanzos) – ( en 2023: El hombre que susurraba a la berza)
*   **IA, IA, OH** – (Juan Francisco Butrón Prida y Manuel Pereira González) – (en 2023: Esto es lo que air)
*   **La del cuarto** – (Ana Niño López) – ( en 2023: ¡Ay! Mi Paco)
*   **La graduada** – (Miriam Andrades Pérez)
*   **La historia jamás contada de Superman (el otro)** – (David Magrañal) – ( en 2023: El cuervo negro)
*   **La I.A. la gran puta** – (Ismael Denis Rodríguez) – ( en 2023: El gran emperador)
*   **La No Boda del Siglo** – (Manuel Ponce ‘Wito’) – (en 2023: Te voy a dar un buen viaje)
*   **La tenemos así de grande** – (Juan Manuel Amuedo ‘Barea’ y José M. Bengines) – ( en 2023: En la ruina soy feliz)
*   **La vida es una mierda y luego te mueres** – (Dani Casellas) – ( en 2023: Tremos aquí cera pa tol que quiera)
*   **Las del Columela** – (Romancero infantil) – ( en 2023: Las alcaldesitas)
*   **Lo que diga la Yenny, me lo paso por el fores…** – (Helen Lorenzo) – ( en 2023: La veleta, ni dos horas se está quieta)
*   **Los que siempre se quedan a las puertas** – (Raúl Moreno y Miguel Moreno) – (en 2023: Miento, luego existo)
*   **Mafalda** – (Ana Magallanes) – ( en 2023: La ninja)
*   **Más pallá que pacá** – (Jairo Serrano Gómez y Juan Manuel Garcia) – (en 2023: Éramos 300 y quedamos dos…este y yo!!)
*   **Mazinguer Z ¡Buen sólo de trompeta!** – (Francisco Ramón Marín Malia) – (en 2023: Paconan de Barbatian)
*   **Me metí en el centro Retro y ya casi ni me meto** – (José Candón Mena)
*   **Mi padre (creo que) era de Cádiz** – (Selu Gómez)
*   **Nos la escarapela** – (Karim Aljende y Raquel Barcala) – ( en 2023: Kadizco Bertosolariak)
*   **Nostalgia de hueva** -(Fco. Javier Sánchez Vázquez y Fco. J. Benítez Muñoz) (Nueva creación)
*   **Oh lá la Rachelieu c´est moi** -(José Manuel Bravo Rosano)
*   **Por la popa no** – (Eva Mª Gómez y Ana Bartual ) – ( en 2023: Por Perseo, así me veo)
*   **Quien me mandaría mete el Batmovil por Compañía** – (Álvaro Ballen Pozo) – ( en 2023: Aterriza como puedas en la calle Columela)
*   **Romalcero Gaditanófobo** – (Karim Aljende y Raquel Barcala) – (en 2023: Kadizco Bertosolariak)
*   **Sin reservas** – (Estela Durán, Laura Gómez Elicio Marchante, Ismael Rodríguez y Javier Velázquez ) – ( en 2023: Comando Malaka)
*   **Toro sentado (y su hijo de pie cansado)** – (Juan Antonio Díaz Valleras y David Rebolo Mesa) – ( en 2023: Los caraviñeros)
*   **Tour tétrico y tenebroso ¡Oh Cádiz misterioso!** – (Rafael Rodríguez y David Amaya) – (El conquistador)
*   **Un beso para la historia** – (Jose Manuel Caballero Sánchez) – ( en 2023: Este romancero es un puntazo)
*   **Una historia con moraleja** – (Romancero infantil) – ( en 2023: Las hijas de las chirigoteras)
*   **Urbanitas, una especie en peligro de expansión** – (Nolo Rodriguez) – ( en 2023: Junito el trepa’Un líder de pura cepa’)
*   **Superman (El otro)** – (David Magrañal) – (en 2023: El cuervo negro)
*   **Yo nunca me equivoco** – (Luis Miguel García, Juan Díaz y Dani Casellas) – (En 2023: Traemos aqui cera pa tol que quiera)
*   **Yo yó, cla clá** – (Hermanos Beiro) – ( en 2023: La verdadera pero increible historia de los padres de Hitler)

¿Qué son los romanceros del Carnaval de Cádiz?
----------------------------------------------

Los romanceros es otra de las **[modalidades existentes en el Carnaval de Cádiz](https://www.codigocarnaval.com/modalidades-carnaval/)**. Están formados por uno o dos componentes y se tratan de composiciones rimadas, generalmente de tono humorístico o satírico.

Estos romanceros suelen tratar temas de actualidad como la política, la sociedad, la cultura, la critica social y en muchas ocasiones, hilando la idea sobre el personaje que representan.

Su estructura es sencilla, son versos octosílabos, con rima consonante en los versos pares. Su métrica es libre, por lo que los versos pueden tener un número variable de sílabas.

¿Dónde actúan los romanceros?
-----------------------------

Los romanceros tienen un concurso aparte del COAC. En él, las agrupaciones interpretan sus repertorios en una fase de semifinales y posteriormente en una fase final.

En la actualidad, las semifinales del concurso de Romanceros se realiza en el **Teatro del Títere de la Tía Norica** y la Gran Final se realiza en el **Gran Teatro Falla**, un día antes de la celebración de la Final del COAC en adultos.

Independientemente del concurso, también hay otros romanceros que junto a muchos que se presentan al concurso, están por las calles de Cádiz ofreciendo sus repertorios.

Ataviados con un cartelón, que les sirve de guía para representar su obra, estos suelen interpretar una parodia de unos 10 a 20 minutos. Algunos de ellos también hacen tandas de cuplés.
