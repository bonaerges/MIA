Title: ▷ Agenda SÁBADO DE CARNAVAL en Cádiz - 10 de febrero

URL Source: https://www.codigocarnaval.com/carnaval-de-cadiz/agenda-sabado-de-carnaval/

Published Time: 2023-02-17T20:07:42+01:00

Markdown Content:
El primer **sábado de Carnaval** (10 de febrero) es uno de los días que más visitantes y turistas recibe la ciudad de Cádiz.

Una vez finalizada la [**Gran Final del COAC 2024**](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/), que despunta prácticamente hasta las claras del día, la ciudad ya se prepara casi sin apenas tregua para disfrutar de un gran día repleto de eventos.

Pregón Infantil y actos para la cantera
---------------------------------------

La **agenda sábado de Carnaval** comenzará con un desfile de disfraces y agrupaciones infantiles que saldrá desde Cortadura hasta la Plaza Ana Orantes (Antigua Ingeniero de la Cierva) a partir de las 12:00h del mediodía.

📌 _Recorrido: Salida Plaza Cortadura – Paseo Marítimo – Glorieta Ana Orantes_

Luego, en torno a las 13:00h en esa misma plaza, **Sofía Letrán Sánchez de la Campa** serán la encargada de realizar el **Pregón Infantil 2024**.

Una vez finalizado, el acto concluirá con actuaciones tanto de agrupaciones infantiles como juveniles que se extenderá hasta la tarde, el lugar escogido para ello será tanto en la Glorieta Ana Orantes como en el Paseo Marítimo.

A su vez, se celebrará una serie de juegos temáticos en la misma Glorieta Ana Orantes.

Mejillonada Popular
-------------------

Sobre las **12:00h** se celebrará la **mejillonada popular** en la **Plaza de los Porches**, organizado por la AV Zona Puerta del Mar.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Certamen de romanceros
----------------------

A partir de las **13:30h** se celebrará un **Certamen de romanceros** organizado por la AVV Murallas de San Carlos que tendrá lugar en el tablao situado en la **Plaza España.**

### Orden actuación Certamen Romanceros

*   **Cadifornikeishon** (Juan Antonio Andrade y Begoña Fuentes)
*   **IA IA OH** (Txapela y Kiko)
*   **Nostalgia de hueva** (Javi Benítez y Monano)
*   **Er viudo** (Er Melena)
*   **Quién me mandaría meter el batmóvil por Compañía** (Álvaro Ballén)
*   **La tenemos así de grande** (Juan Manuel Barea y José Manuel Mantenío)
*   **Con mi mono de faena** (Hermanos Barba)

Batalla de Coplas en el mercado central
---------------------------------------

El mercado central (o plaza de Abastos) acogerá nuevamente la **[Batalla de Coplas 2024](https://www.codigocarnaval.com/batalla-coplas-carnaval/)** a partir de las **14:00h.** Aquí, ubicados en diferentes escenarios situados en las esquinas del mercado, las agrupaciones ofrecerán sus repertorios al público con un orden de actuación determinado.

Aquí actuarán agrupaciones de la cantera y del COAC, así como los 4º premios de cada modalidad.

**BATALLA DE COPLAS** 🎭  
Si quieres más información detallada, visita nuestro artículo sobre la **[Batalla de Coplas](https://www.codigocarnaval.com/batalla-coplas-carnaval/)**

Festival de coros en la Peña La Estrella
----------------------------------------

La **Peña La Estrella**, ubicará un escenario en la **plaza de Candelaria**, donde ese día, a partir de las **14:00h** irán desfilando diferentes agrupaciones (en este caso coros), con motivo del concurso de tangos ‘Tío de la Tiza’.

**CONCURSO PEÑA LA ESTRELLA 🎭  
**Si quieres más información detallada, visita nuestro artículo sobre el **[Tablao Peña La Estrella](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)**

I Gala de Comparsas
-------------------

La sala Momart Theatre situada en la Punta de S. Felipe, celebrará su primera Gala de comparsas a partir de las 16:00h. **[Comprar entradas](https://www.giglon.com/todos?idEvent=gala-de-carnaval-asociacion-de-comparsistas-1960-cadiz)**

Pregón de Juanma Braza ‘El Sheriff’
-----------------------------------

La plaza de San Antonio recibirá a partir de las 20:30h, el **[pregón](https://www.codigocarnaval.com/pregon-carnaval-cadiz/)** del autor del Carnaval de Cádiz **Juan Manuel Braza ‘El Sheriff’.**

Un pregón que estará acompañado de actuaciones invitadas por el propio pregonero y su grupo.

Gala de Carnaval
----------------

El Gran Teatro Falla acogerá a partir de las 22:00h una **[gala del Carnaval](https://www.codigocarnaval.com/gala-carnaval-de-cadiz/)** donde participarán los primeros y segundos premios del COAC 2024. Las entradas saldrán por Bacantix.com sin fecha fijada.

Orden actuación

Pregón en el Barrio del Pópulo
------------------------------

El barrio del Pópulo celebrará su pregón a cargo de **Ketama y Cuqui** a partir de las **22:00h**.

Noche de carnaval en La Viña y San Antonio
------------------------------------------

Tras el pregón de ‘El Sheriff’, a partir de las **22:30h** tendrá lugar una noche de actuaciones carnavalescas con los **primeros y segundos premios del COAC 2024** en los escenarios de la **Plaza de San Antonio** y el **barrio de La Viña** (Escenario de La Palma).

### Actuaciones en Barrio La Viña (22:30h)

*   22:30h – **[Los Luciérnagas](https://www.codigocarnaval.com/coac-2024/los-luciernagas/)**
*   23:00h – **[Punk y Circo, la lucha continúa](https://www.codigocarnaval.com/coac-2024/punk-y-circo-la-lucha-continua/)**
*   23:30h – **[Los Colgaos](https://www.codigocarnaval.com/coac-2024/los-colgaos/)**
*   00:00h – [**El Grinch de Cai**](https://www.codigocarnaval.com/coac-2024/el-grinch-de-cai/)
*   00:30h – **[El Paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**
*   01:00h – **[En mi caseta cabe todo el mundo](https://www.codigocarnaval.com/coac-2024/en-mi-caseta-cabe-todo-el-mundo/)**
*   01:30h – **[Los Sacrificaos](https://www.codigocarnaval.com/coac-2024/los-sacrificaos/)**
*   02:00h – **[La callejera invisible](https://www.codigocarnaval.com/coac-2024/la-callejera-invisible/)**

### Actuaciones en San Antonio (22:30h)

*   22:30h – **[El Paraíso](https://www.codigocarnaval.com/coac-2024/el-paraiso/)**
*   00:00h – **[La callejera invisible](https://www.codigocarnaval.com/coac-2024/la-callejera-invisible/)**
*   00:30h – **[Los Iluminados](https://www.codigocarnaval.com/coac-2024/los-iluminados/)**
*   01:00h – **[Los Cocos de Cádiz](https://www.codigocarnaval.com/coac-2024/los-cocos-de-cadi/)**
*   01:30h – **[La oveja negra](https://www.codigocarnaval.com/coac-2024/la-oveja-negra/)**
*   02:00h – **[Los Exageraos](https://www.codigocarnaval.com/coac-2024/los-exageraos/)**

**NOCHE DE CARNAVAL 🎭  
**Si quieres más información sobre este evento, no te pierdas nuestro artículo sobre el **[Sábado noche de Carnaval en Cádiz](https://www.codigocarnaval.com/sabado-de-carnaval-cadiz/)**

#### Programación para otros días
