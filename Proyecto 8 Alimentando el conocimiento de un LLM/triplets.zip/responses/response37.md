Title: ✉ Contacto - Codigo Carnaval

URL Source: https://www.codigocarnaval.com/contacto/

Published Time: 2020-03-31T17:02:42+02:00

Markdown Content:
Ponte en contacto con nosotros para cualquier duda, sugerencia o propuesta comercial y te responderemos lo antes posible.

Nombre (requerido)  

Tu correo electrónico (requerido)  

Asunto  

Demuéstrame que eres humano/a (respuesta en números)  
uno + 2 =

Mensaje  

He leído y acepto las [Políticas de Privacidad](https://www.codigocarnaval.com/politica-de-privacidad/)



Tus datos van a estar seguros porque cumplimos con el RGPD (Reglamento General de Protección de Datos) y te dejamos esta información que debes saber:  

1.  Responsable de los datos: Yasser Tirado

2.  Finalidad de los datos: Poderte contestar al envío de este correo electrónico.

3.  Almacenamiento de los datos: Tus datos se almacenarán en el servidor de Google GMAIL. (UE)

4.  Derechos: En cualquier momento puedes [limitar, recuperar y borrar tu información](https://www.codigocarnaval.com/aviso-legal/).
