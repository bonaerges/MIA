Title: ▷ CARRUSEL DE COROS 2024 en Cádiz

URL Source: https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/

Published Time: 2019-10-10T18:40:36+02:00

Markdown Content:
El **Carrusel de Coros** es uno de los eventos más característicos del Carnaval de Cádiz. En él, los numerosos coros participantes en el **[Concurso Oficial de Agrupaciones Carnavalescas del Gran Teatro Falla](https://www.codigocarnaval.com/coac-2024/)**, junto algunos callejeros, se montan en carrozas llamadas bateas.

En ellas, y tiradas por un tractor, hacen un recorrido establecido, por el cual van ofreciendo sus repertorios al numeroso público que se congrega en torno a ellos.

Para este 2024, volveremos a las fechas y horarios habituales de años anteriores, comenzando en torno a las 13:00h, del mediodía.

*   **[Listado con todos los COROS del COAC 2024](https://www.codigocarnaval.com/coac-2024/coros-2024/)**

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Los carruseles de coros previstos para este 2023 se desarrollarán los **domingos 11 y 18 de febrero** y el **lunes 12 de febrero** (día festivo local en Cádiz).

Habrá **dos recorridos** con diferentes coros en los alrededores de la **Plaza de Abastos** y **Plaza de Mina**,

**El recorrido de ambos carruseles será circular**. Y como hemos dicho anteriormente, el horario de comienzo de este evento está previsto en torno a las 13:00h del mediodía.

Sin dudas, una oportunidad perfecta para disfrutar con la tradicional copa de vino moscatel de unos buenos tangos gaditanos.

Carrusel de coros en el barrio de La Viña y Mentidero
-----------------------------------------------------

También se ha confirmado en la programación oficial del Carnaval de Cádiz, un carrusel de coros por los barrios de **La Viña** y **el Mentidero**.

Este evento, tendrá lugar el sábado **17 de febrero**, a partir de las **13:00h**.

Resumen Carrusel de Coros Cádiz 2024
------------------------------------

#### Título del aviso

📌 Domingo 11 febrero: Carrusel de coros (Mercado y Plaza Mina)  
📌 Lunes 12 febrero: Carrusel de coros (Mercado y Plaza Mina)  
📌 Sábado 17 febrero: Carrusel de coros (Barrio La Viña y Mentidero)  
📌 Domingo 18 febrero: Carrusel de coros (Mercado y Plaza Mina)
