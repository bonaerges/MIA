Title: COAC 2025 - Guía completa sobre el Concurso del Falla

URL Source: https://www.codigocarnaval.com/coac-2025/

Published Time: 2024-03-21T09:39:51+01:00

Markdown Content:
En este artículo te contaremos todo lo que debes saber sobre el **COAC 2025**, el Concurso Oficial de Agrupaciones del Carnaval de Cádiz que se celebra en el Gran Teatro Falla.

Antes de nada, tienes una guía rápida a continuación con los artículos más interesantes y relacionados con el **COAC 2025** para que no te pierdas nada: desde los nombres de este año, toda la información y venta de entradas, órdenes de actuación, las fichas de las agrupaciones…

Venta de entradas para Preliminares 2025

Venta de entradas para Cuartos 2025

Venta de entradas para Semifinales 2025

Venta de entradas Final 2025

Venta de entradas Semifinales Infantiles 2025

Chirigotas 2025 – Fichas

Comparsas 2025 – Fichas

Fechas COAC 2025 – Calendario completo
--------------------------------------

Aún no conocemos las fechas oficiales del COAC 2025, pero sabiendo ya, por las fechas oficiales del Carnaval de Cádiz 2025 que la **Gran Final será el 28 de febrero**.

Un concurso tardío que tendrá seguramente su inicio a finales de enero o principios del mes de febrero de 2025.

### Fechas COAC 2025 – Adultos

**Preliminares:** Sin fechas oficiales

**Cuartos de Final:** Sin fechas oficiales

**Semifinales:** Sin fechas oficiales

**Gran Final:** 28 de febrero

### Fechas COAC 2025 – Cantera

**Semifinales infantiles:** Sin fechas oficiales

**Semifinales juveniles:** Sin fechas oficiales

**Final Infantil:** Sin fechas oficiales

**Final Juvenil:** Sin fechas oficiales

Sorteo COAC 2025
----------------

El **sorteo del COAC 2025** determinará el orden de actuación de las agrupaciones en la fase de preliminares.

Este suele celebrarse a finales de año, en el que se establecen un número de agrupaciones cabezas de serie que actuarán en las diferentes funciones, garantizando así una por día.

### Cabezas de serie COAC 2025

Las agrupaciones cabezas de serie se otorgan a aquellas agrupaciones finalistas y semifinalistas del concurso anterior, siempre y cuando mantengan a los autores o el 50% del grupo con respecto a la última edición.

También perderán esta condición las agrupaciones que no hayan salido en el **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)**.

Entradas
--------

Las entradas del Carnaval de Cádiz son muy esperadas por los aficionados al COAC 2025 que ansían escuchar los nuevos repertorios en directo desde el Gran Teatro Falla.

Por lo general, se suele destinar el 50% para la venta en internet y el 50% para la venta en taquillas físicas.

Si no te quieres perder nada sobre sus fechas, precios y la información necesaria antes de comprarlas puedes visitar nuestro artículo de **[entradas COAC](https://www.codigocarnaval.com/entradas-coac/)** donde te lo explicamos todo al detalle.

Las fases del COAC 2025
-----------------------

El COAC 2025 se divide en 4 fases, todas ellas eliminatorias: preliminares, cuartos de final, semifinales y final.

### Preliminares

Es la primera fase del concurso, aquí participan todas las agrupaciones y se dan a conocer los tipos y repertorios por primera vez.

El jurado puntúa para tener un baremo clasificatorio, pero los puntos de las preliminares no se arrastran a la siguiente fase.

Una vez emitido el primer fallo del jurado, se conocerán la clasificación y puntos de las que no han conseguido pasar el corte.

### Cuartos de Final

Aquí, las agrupaciones que hayan superado el corte deberán afrontar la segunda fase del concurso. Están obligados a traer las piezas de pasodobles/tangos y cuplés de nueva creación, pudiendo mantener fijas la presentación y el popurrí.

En el caso de los cuartetos, deberán ofrecer parodia y cuplés de nueva creación, manteniendo fijo si desean el popurrí (o estrenando tema libre).

Aquí los puntos si arrastrarán en la siguiente fase y se conocerán la clasificación final y puntos de las que no pasan el corte.

### Semifinales

La penúltima fase del concurso es una de las de mayor calidad, donde las agrupaciones buscan meterse en la Gran Final del 28 de febrero.

Se sigue el formato de cuartos de final y el jurado deliberará en la famosa ‘noche de cuchillos largos’ un máximo de 16 agrupaciones (4 por modalidad) para que opten a la Final.

Los puntos también arrastrarán y se darán a conocer la clasificación y puntos de las que no pasan el corte.

### Final (28 de febrero)

La gran noche del COAC 2025 termina con la celebración de la Gran Final, con un máximo de 16 agrupaciones.

Esta fase se alarga durante toda la noche hasta entrada las primeras horas del sábado.

En esta ocasión, se permite repetir una pieza de tango/pasodoble y otra de cuplé si se quiere, obligando a ser la otra inédita.

Una vez concluido el certamen, el jurado fallará con las agrupaciones que obtienen del 1º hasta el 4º premio.

Los puntos también arrastrarán y se darán a conocer los puntos de todas las finalistas.

Antifaces de oro 2025
---------------------

Por el momento no sabemos quiénes serán los nuevos **antifaces de oro 2025** del Carnaval de Cádiz, pero si quieres puedes echar un vistazo al listado completo de galardonados durante la historia en nuestro artículo de **[Antifaces de Oro](https://www.codigocarnaval.com/antifaces-de-oro/)**.

Los cambios del COAC 2025
-------------------------

De momento, no conocemos los nuevos **cambios del COAC 2025** en base al reglamento.

Actualizaremos esta sección con toda la información en cuanto tengamos más datos.

¿Cómo seguir el concurso en directo?
------------------------------------

Existen diversas formas de seguir el COAC 2025 en directo, ya sea a través de la TV convencional o las diferentes plataformas online.

La cadena local, Onda Cádiz TV retransmite de manera íntegra todo el concurso desde las preliminares hasta la final, incluyendo las categorías de la cantera.

Si quieres conocer todo al detalle, mira nuestro artículo sobre **[cómo ver el COAC en directo](https://www.codigocarnaval.com/coac-directo-online/)**.
