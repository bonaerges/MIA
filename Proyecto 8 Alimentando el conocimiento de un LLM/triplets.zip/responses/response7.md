Title: CARNAVAL PARA PRINCIPIANTES - Todo lo que debes saber

URL Source: https://www.codigocarnaval.com/carnaval-para-principiantes/

Published Time: 2021-12-15T12:52:01+01:00

Markdown Content:
A buen seguro que esto del Carnaval de Cádiz ha llamado la atención a muchos curiosos que recién descubren la fiesta más importante de la ciudad. Con **Carnaval para Principiantes**, queremos hacer una pequeña guía básica para adentrar a la gente al veneno.

Son muchas las cosas que uno debe conocer de la fiesta: sus orígenes, sus autores, las letras más relevantes, sus relaciones con otras fiestas y culturas…

Pero vayamos por partes, y poco a poco iremos engordando este pequeño rincón, donde la historia, las raíces, la lectura y la música tienen mucho que decir.

*   **[Todo sobre las agrupaciones callejeras del Carnaval de Cádiz](https://www.codigocarnaval.com/agrupaciones-callejeras/)**
*   **[Los Romanceros del Carnaval de Cádiz](https://www.codigocarnaval.com/romanceros/)**

Las modalidades del Carnaval de Cádiz
-------------------------------------

Aunque antes de meternos en faena, recomendando letras, necesitamos que tengáis bien claro los conceptos y las diferencias que existen entre las diferentes modalidades de la fiesta: los coros, los cuartetos, las comparsas o las chirigotas entre otros.

Para ello, no te pierdas nuestro artículo de las **[modalidades del Carnaval de Cádiz](https://www.codigocarnaval.com/modalidades-carnaval/)** donde te lo dejamos todo muy clarito.

Letras que debes aprenderte
---------------------------

Por supuesto que no están todas las que son, pero para ir abriendo boca y adentrarse en el mundo del Carnaval de Cádiz es imprecindible aprenderse algunas de las letras más icónicas de la fiesta.

Con este pequeño repertorio, podremos asistir sin miedo a cualquier tipo de reunión carnavalera donde se cante algo.

### Los hombres del mar – Viene a esta tierra un barquito

**Paco Alba** es considerado por muchos el autor más grande de la historia del Carnaval de Cádiz. Para muestra, fue el precursor de la creación de la modalidad de comparsas, que contaban con un sello mucho más fino y elegante.

Una de sus letras más cantadas, es el pasodoble de la comparsa **‘Los hombres del Mar’** (1965) donde se menciona al célebre ‘Vaporcito del Puerto’ que unía en travesía Cádiz y El Puerto de Santa María.

Sin lugar a dudas, la copla más icónica para una barbacoa o celebración con amigos.

### Los Anticuarios – Los duros Antiguos

Una de las letras más antiguas del Carnaval de Cádiz, que se siguen cantando como si fuera ayer, es la que compuso el autor **Antonio Rodríguez ‘El tío de la tiza’** para el coro **‘Los Anticuarios’** en 1905.

En este célebre tango, se recuerda la **[historia de los duros antiguos](https://www.codigocarnaval.com/articulos/aquellos-duros-antiguos/)** y el gran revuelo que causó en Cádiz aquel hallazgo.

### Caleta – Presentación

![Image 1: los yesterday aragon](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201024%20576'%3E%3C/svg%3E)

**Antonio Martín García** es el autor más laureado de la historia del Carnaval de Cádiz, y una de sus letras más cantadas en celebraciones y reuniones con amigos es sin duda la de su comparsa **‘Caleta’** (1980), que curiosamente, no consiguió entrar en la Gran Final de aquel año, considerándose, uno de los **[grandes cajonazos de la historia del Carnaval](https://www.codigocarnaval.com/articulos/cajonazos-carnaval-cadiz/)**.

El autor, en sus más de 50 años haciendo carnaval nos dejó un legado inmortal de coplas, de las que también no paran de sonar hoy día **‘Voces Negras’** (1982) con su presentación o el célebre **pasodoble de la rosa**, con la comparsa **‘Capricho Andaluz’** (1973) que provocó un enfrentamiento entre los seguidores de Paco Alba y Martín.

*   📌 **[Presentación de ‘Caleta’](https://www.youtube.com/watch?v=xib5gIrD4Go)**

### Los Valientes – Loquito por verte a mi vera

Juan Manuel Braza Benítez, más conocido en el mundo del Carnaval como **‘El Sheriff’,** En el año 2004, una chirigota llamada **‘Los Valientes’** se alzó con el tercer premio de la modalidad, vestidos de novios.

En el pasodoble, que realmente es un piropo a Cádiz, se ha convertido en uno de los pasodobles más cantados, principalmente en las bodas.

*   📌 **[‘Loquito por verte a mi vera’ por Toni Piojo y Paco Pellejo](https://www.youtube.com/watch?v=bbfjumd84WY)**

### Las viudas – Vuelve ya el 3×4

El trío formado por **Paco Cárdenas**, **Ramón Peñalver** y la música de **[Manuel Sánchez Alba ‘Noly’](https://www.codigocarnaval.com/articulos/noly-el-beethoven-del-carnaval/)** (considerado uno de los mejores músicos del Carnaval de Cádiz) trajo consigo, un gran pelotazo con **‘Las viudas de los bisabuelos de los viejos del 55’** (1994) donde consiguieron el primer premio.

Una chirigota que nos trae un pasodoble añejo, sencillo y sin estridencias, como siempre marcaron los cánones antiguos de la fiesta.

*   📌 **[Pasodoble ‘Vuelve ya el 3×4’ por Manolín Gálvez, Piojo y Manolín Santander](https://www.youtube.com/watch?v=aB-zkjiWkS0)**

### La familia Pepperoni – Me han dicho que el amarillo

![Image 2: chirigota-la-familia-pepperoni](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20750%20450'%3E%3C/svg%3E)

La influencia del gran **[Manolo Santander](https://www.codigocarnaval.com/autores/manolo-santander/)** con su chirigota ‘La familia Pepperoni’ fue tan grande, que por primera vez una letra del Carnaval de Cádiz se hacía famosa más allá del contexto del propio carnaval.

Aquel célebre pasodoble de ‘Me han dicho que el amarillo’ se convirtió en un cántico del Estadio Ramón de Carranza (hoy Nuevo Mirandilla) y posteriormente se transformó en el himno oficioso del Cádiz CF, sonando cada domingo en la megafonía del estadio.

*   📌 **[Pasodoble ‘Me han dicho que el amarillo’ por el Batallón Rebaná](https://www.youtube.com/watch?v=OioQ7E-3er8)**

### Los Piratas – Con permiso buenas tardes

**[Antonio Martínez Ares](https://www.codigocarnaval.com/autores/antonio-martinez-ares/)** es otro de los grandes autores de la fiesta. Sus letras han trascendido todos los ámbitos y podríamos decir que el fenómeno ‘fan’ comenzó con uno de sus mayores pelotazos, la comparsa **‘Los Piratas’** (1998).

Conocido como **‘El niño’**, siempre fue un trasgresor, un adelantado a su tiempo y consiguió escribir letras icónicas, como aquel ‘Con permiso buenas tardes’, en un cántico certero contra la violencia de género.

Antonio también se ‘enfrentó’ al Papa en 1993, con su comparsa **‘Los Miserables’** en aquel mítico _‘Ha dicho_ _el Santo Padre’_, que le costó la expulsión de su cofradía, o aquel eterno canto de amor con **[‘Recuerdo que era mayo’](https://www.codigocarnaval.com/articulos/recuerdo-que-era-mayo/)** de la comparsa **‘La Ventolera’** (1994).

*   📌 **[Los Piratas ‘Con permiso buenas tardes’ (Antología 2017)](https://www.youtube.com/watch?v=edFicapT-fY)**
*   📌 **[Pasodoble ‘Recuerdo que era mayo’ por Carli Brihuega](https://www.youtube.com/watch?v=K4Cycbaf6oo)**

### Raza Mora – Un 4 de diciembre

El asesinato de **Caparrós**, el **[4 de diciembre de 1977 en Málaga](https://www.codigocarnaval.com/articulos/4-de-diciembre-carnaval/)**, hizo que la comparsa de **‘Los Majaras’** del Puerto de Santa María, trajesen al año siguiente con **Raza Mora** (1978), uno de los grandes himnos de la fiesta.

*   📌 **[Pasodoble ‘Un 4 de diciembre’ por Vicente Lázaro ‘Lali’](https://www.youtube.com/watch?v=K7uVmoXdndU)**

### Los Yesterday – Aunque diga Blas Infante

![Image 3: los yesterday aragon](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201024%20576'%3E%3C/svg%3E)

No podemos olvidarnos tampoco de uno de los autores con más talento del Carnaval de Cádiz, **[Juan Carlos Aragón](https://www.codigocarnaval.com/autores/juan-carlos-aragon/)**, también conocido como ‘_El Capitán Veneno_‘ nos dejó un enorme abanico de letras reflexivas y críticas a caballo entre la chirigota y la comparsa principalmente.

Entre ellas destacamos una de sus obras cúlmenes en la chirigota, como fue ‘**Los Yesterday**‘ (1999), con una defensa al servilismo andaluz que se mostraban en las series de producción españolas.

*   📌 **[Pasodoble ‘Aunque diga Blas Infante’ por Er Chele Vara](https://www.youtube.com/watch?v=xfDapjO8OXw)**

Autores del Carnaval de Cádiz
-----------------------------

En nuestra web, también podrás consultar una serie de **autores del Carnaval de Cádiz**, con su trayectoria y colaboraciones completas, sus premios, una breve historia de sus inicios… Estos apartados se irán ampliando próximamente con nuevos autores. Una oportunidad perfecta para conocer a algunos de los más relevantes de nuestra fiesta.

*   **[Juan Carlos Aragón](https://www.codigocarnaval.com/autores/juan-carlos-aragon/)**
*   **[Antonio Martínez Ares](https://www.codigocarnaval.com/autores/antonio-martinez-ares/)**
*   **[Tino Tovar](https://www.codigocarnaval.com/autores/tino-tovar-verdejo/)**
*   **[Miguel Ángel García Argüez ‘Chapa’](https://www.codigocarnaval.com/autores/miguel-angel-garcia-arguez/)**
*   **[Selu García Cossío](https://www.codigocarnaval.com/autores/jose-luis-garcia-cossio-el-selu/)**
*   **[Enrique García Rosado ‘Kike Remolino’](https://www.codigocarnaval.com/autores/kike-remolino/)**
*   **[Germán Rendón](https://www.codigocarnaval.com/autores/german-rendon/)**
*   **[Joaquín Quiñones](https://www.codigocarnaval.com/autores/joaquin-quinones-madera/)**
*   **[Manolo Santander](https://www.codigocarnaval.com/autores/manolo-santander/)**

Voces del Carnaval de Cádiz
---------------------------

En nuestro canal de Youtube, hemos dedicado un apartado en el que contamos la trayectoria de algunas de las voces más relevantes del Carnaval de Cádiz de la época actual principalmente: **Nico García, Fali Figuier, Caracol, Toni Piojo, Dani Obregón, Rafa Taleguilla, Ramoni** o **Carli Brihuega** son algunas de nuestras piezas más destacadas.

*   📌 **[Playlist de Voces del Carnaval](https://www.youtube.com/watch?v=bm1RefKa-gA&list=PLsSvWXfNFryNW8jK_AN6tPgqMgkbomZGX)**

Libros de Carnaval, la mejor opción para los principiantes
----------------------------------------------------------

![Image 4: libros manuel salguero](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20799%20515'%3E%3C/svg%3E)

Para conocer el Carnaval de Cádiz, también podemos adentrarnos en él a través de la literatura. Hemos realizado una recopilación de algunos de los libros referentes con temática de la fiesta.

Aquí encontrarás de todo, desde novelas de ficción, biografías, ensayos, poemarios… ¡No te lo pierdas!

*   📌 **[Los mejores libros del Carnaval de Cádiz](https://www.codigocarnaval.com/libros-carnaval-cadiz/)**

La Escuelita del Carnaval
-------------------------

Otra de las mejores ideas para aprender sobre el Carnaval de Cádiz, es mediante la pedagogía. En Youtube, nuestro amigo y autor **Miguel Ángel García Argüez ‘Chapa’**, tiene un canal muy interesante llamado ‘**[La Escuelita del Carnaval](https://www.youtube.com/channel/UC_oknW2BM9_Arqr_PDllVZw/videos)**‘, en él, se analizan letras de diversas agrupaciones y se da algunas nociones básicas sobre componentes musicales. ¡Muy recomendado!
