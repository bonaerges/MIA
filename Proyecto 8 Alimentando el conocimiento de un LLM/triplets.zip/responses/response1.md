Title: ENTRADAS COAC 2025 ✅ Fechas, precios e información

URL Source: https://www.codigocarnaval.com/entradas-coac/

Published Time: 2024-03-20T11:39:32+01:00

Markdown Content:
En este artículo encontrarás toda la información para **comprar entradas COAC 2025** para el Carnaval de Cádiz en el Gran Teatro Falla.

Antes que nada, recordarte que **Código Carnaval no es ningún canal oficial de venta de entradas** ni ofrecemos soporte oficial ante las diferentes incidencias que ocurran durante la compra de los usuarios en los medios oficiales.

Únicamente facilitamos la información necesaria para el proceso de compra de las entradas del COAC a través de la información que ofrece el Ayuntamiento de Cádiz.

La **venta de entradas COAC 2025** es uno de los eventos más esperados por los aficionados al Carnaval de Cádiz. Poder asistir en directo al Concurso Oficial de Agrupaciones Carnavalescas desde el Gran Teatro Falla.

Como cada año, el **COAC 2025** acoge a un gran número de agrupaciones y espectadores dispuestos a disfrutar del Carnaval de Cádiz.

Entradas Teatro Falla 2025. ¿Cuáles son los requisitos?
-------------------------------------------------------

Durante el proceso de compra en las diferentes fases, únicamente se pueden comprar **un máximo de dos entradas por persona** **y función**.

En las diferentes fases, se establece un número máximo de funciones a las que se pueden acceder en una misma compra.

Es decir, puedes comprar en preliminares dos entradas para el viernes, dos para el sábado y dos para el domingo…hasta el número máximo que se establezca en cada fase. Por ejemplo, en las preliminares de 2024 fueron 6 sesiones.

Las entradas **son nominativas y deberán estar identificadas con el DNI** de la personas que vayan a asistir a la sesión correspondiente.

Será necesario **mostrar el DNI en la puerta**, junto a las entradas a la hora del acceso al Gran Teatro Falla.

Además, **no se admitirán cambios ni devoluciones bajo ninguna circunstancia**.

### Registro en Bacantix (Para compra de entradas COAC 2025 online)

Para comprar las entradas vía online, es necesario estar registrado previamente en **Bacantix**, la web que da soporte a la venta de entradas de espectáculos del Gran Teatro Falla y el Ayuntamiento de Cádiz.

Para ello, puedes hacerlo a través de la web (**[https://www.bacantix.com/aytocadiz](https://www.bacantix.com/aytocadiz)**). En la esquina superior derecha aparece el botón inicio de sesión, que al pinchar en él ofrece la opción ‘Registrarse ahora’.

Este proceso es imprescindible, así como la información aportada sea veraz y correcta para completar el proceso de compra posterior.

¿Cuándo salen a la venta las entradas del COAC 2025?
----------------------------------------------------

El Ayuntamiento de Cádiz informa con un par de horas de antelación sobre la puesta a la venta de las entradas de cada fase.

Por lo general, se avisa con una hora de antelación para su puesta a la venta en internet y a la hora siguiente se abren las taquillas físicas en el Gran Teatro Falla o en los diferentes puntos que se habiliten para tal caso.

Si quieres información más detallada sobre la venta de entradas en las diferentes fases del concurso puedes mirar estos artículos

*   **Venta de entradas COAC Preliminares 2025**
*   **Venta de entradas COAC Cuartos 2025**
*   **Venta de entradas COAC Semifinales 2025**
*   **Venta de entradas COAC Final 2025**

Además, también puedes consultar sobre la venta de entradas de la cantera del Carnaval de Cádiz

*   **Venta de entradas COAC Semifinales Infantiles 2025**
*   **Venta de entradas COAC Semifinales Juveniles 2025**
*   **Venta de entradas COAC Final Infantil 2025**
*   **Venta de entradas COAC Final Juvenil 2025**

Si no quieres perderte nada, únete a nuestro **[canal Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)** y recibe todos los avisos en tu móvil.

Puntos de venta ¿Dónde se pueden conseguir las entradas COAC 2025?
------------------------------------------------------------------

Las entradas del COAC 2025 se venden de manera simultánea en internet (**[Bacantix](https://www.bacantix.com/entradas/?id=aytocadiz)**) y en taquillas físicas.

Se destina el 50% del aforo a cada formato.

Las taquillas físicas por lo general, se ubican en el **Gran Teatro Falla** (habilitando el Hall del Teatro durante las Preliminares) o en las taquillas del mismo (las más próximas a la Facultad de Medicina).

No obstante, esto **en ocasiones puede variar y se pueden utilizar otros lugares para la venta de entradas físicas**.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

¿Cuáles son los precios de las entradas?
----------------------------------------

De momento, desconocemos cuáles serán los precios para las entradas 2025. En 2024 se mantuvieron los precios de 2023.

Preguntas frecuentes para comprar las entradas Carnaval de Cádiz 2025
---------------------------------------------------------------------

### No sé para dónde sacar mis entradas ¿Cuáles son las localidades disponibles en el teatro?

En el Gran Teatro Falla podrás encontrar varios tipos de localidades: Patio de butacas, Palco Platea, Palco Principal, Delantero Anfiteatro, Palco Segundo, Anfiteatro y Paraíso.

Si no sabes para dónde sacar tus entradas, te recomendamos te leas nuestro artículo sobre el **[aforo del Gran Teatro Falla](https://www.codigocarnaval.com/aforo-gran-teatro-falla/)** donde te explicamos cómo son todas las localidades y sus precios aproximados para cada fase.

### ¿Qué necesito para comprar las entradas del Falla 2025?

Es imprescindible el DNI de las personas que vayan a acceder al Teatro para esa función en el momento de la compra, ya que las entradas son nominativas.

Por lo tanto, si lo haces por internet, asegúrate de tener apuntado en número del documento de la persona con la que vayas a acceder para su compra.

### No tengo DNI a mano de la persona que asistirá al evento. ¿Puedo sacarle entrada por internet?

No. **Las entradas son nominativas**, y a no ser la persona que facilite su DNI en la compra también asista al evento, no podrá comprarla en nombre de otra persona si no conoce su numeración. En ese caso, deberá acudir al punto de venta de entradas físico para realizar la compra.

### No puedo acudir al Teatro y las entradas están a mi nombre ¿Puedo cancelar las entradas o cambiarlas?

No. La política de la página de entradas es tajante: **_«Una vez adquirida la entrada no se admitirán cambios ni devoluciones del importe»._** 

Además confirman desde sus políticas que **si te has equivocado en la compra o no puedes ir al espectáculo, no podrás anular ni cambiar tus entradas**.

### Las entradas para la función están agotadas. ¿Se podrán a la venta más entradas?

Las entradas se ponen simultáneamente (con una hora de diferencia en internet y en las taquillas físicas).

Por lo general, siempre se agotan en internet mucho antes que en las taquillas físicas y en la mayoría de los casos en este último formato suele haber entradas sobrantes.

**Si hay entradas sobrantes en taquillas físicas, se vuelcan en internet** justo cuando acaben las colas y se cierren las taquillas.

Además, el mismo día de cada función, a las 10:00h se ponen a la venta y se liberan al público general, si hubiese disponibilidad, las entradas sobrantes al cupo que se destina a mayores de 65 años, movilidad reducida… que se ponen a la venta en las taquillas del Falla.

### ¿Pueden los menores acceder al COAC 2025? ¿Qué hacer si no tienen DNI?

Sólo en el caso de los menores de 14 años que no tengan este documento las dos entradas podrán figurar con el mismo DNI y una de ellas estará identificada con la palabra ‘menor’. Estos menores no podrán acceder solos al teatro

Este proceso deberá hacerse únicamente por las taquillas del Teatro.

### He tenido un problema con el proceso de compra. ¿Dónde puedo dirigirme?

Si has tenido algún tipo de incidencia a la hora de comprar las entradas por internet, Bancatix dispone de un correo de soporte: [**soporte.ticketing@bacanti.com**](mailto:soporte.ticketing@bacanti.com).

Para otro tipo de dudas o consultas, **Bacantix** ofrece a sus usuarios un FAQ de ‘**Preguntas Frecuentes**‘ que se puede consultar. **[Preguntas frecuentes Bacantix](https://www.bacantix.com/webforms/documento.aspx?doc=preguntasfrecuentes)**.

### ¿Se puede comer en el Gran Teatro Falla? ¿Qué debo de saber antes de ir?

Si es tu primera vez, seguramente tendrás muchas preguntas acerca del Gran Teatro Falla. ¿Se puede comer en su interior? ¿Hará frío? ¿Puedo volver a entrar y salir?

Para ello, tienes este artículo donde te contamos **[todo lo que debes saber antes de ir al Falla](https://www.codigocarnaval.com/consejos-gran-teatro-falla/)**. Y si quieres conocer más la ciudad y los alrededores para aprovechar tu visita a Cádiz, puedes mirar **[que hacer en Cádiz si vienes al COAC](https://www.codigocarnaval.com/que-hacer-en-cadiz-si-vienes-al-coac/)**.
