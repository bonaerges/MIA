Title: ▷ Agenda DOMINGO DE PIÑATA en Cádiz - 18 de febrero

URL Source: https://www.codigocarnaval.com/carnaval-de-cadiz/agenda-domingo-de-pinata/

Published Time: 2023-02-21T16:05:31+01:00

Markdown Content:
El segundo **domingo de Carnaval** (18 de febrero), también conocido como **domingo de piñata** es uno de los puntos y finales del Carnaval de Cádiz, ya que con él se acaban los actos oficiales.

Espectáculo de música infantil Cantajuego
-----------------------------------------

Desde por la mañana **a partir de las 12:30h** ya tendremos espectáculos infantiles en la **Plaza de San Antonio**, con talleres de magia, espectáculos de magia y muchas sorpresas más para los más pequeños.

Si quieres consultar más información puedes ver la programación del **[Carnaval con niños](https://www.codigocarnaval.com/carnaval-con-ninos/)**.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Final Concurso ‘Holaquilloquepasa’
----------------------------------

A partir de las **13:00h** se celebrará la final del concurso de presentaciones en la plaza del Mentidero con la actuación de las agrupaciones premiadas.

Final Concurso Romanceros en el Mentidero
-----------------------------------------

A partir de las **13:00h** se celebrará la final del concurso de romanceros en la plaza del Mentidero con la actuación de los premiados.

Carruseles de coros
-------------------

A partir de las **13:00h**, el **[carrusel de coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** volverá como ya hicieran el pasado domingo de carnaval y lunes de carnaval.

Habrá dos recorridos circulares en torno a **Plaza de Mina** y **Plaza de Abastos.**

Degustaciones gratuitas
-----------------------

A partir del mediodía, podrás disfrutar de un gran surtido de **[degustaciones gastronómicas gratuitas](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** en las diferentes peñas y asociaciones de Cádiz.

*   **La Peña La Estrella** organiza su degustación de **pescaíto frito** en la Plaza de Candelaria a partir de las **13:00h**. Además también actuarán las agrupaciones premiadas en sus concursos. _(A falta de confirmación por parte de la organización)_

**CONCURSO PEÑA LA ESTRELLA 🎭  
**Consulta el orden de actuación y agrupaciones premiadas del **[concurso de Plaza Candelaria.](https://www.codigocarnaval.com/tablao-plaza-candelaria-pena-la-estrella/)**

*   **XL Gran Berzá Carnavalesca** que se celebrará en la AVV Murallas San Carlos (Plaza España) donde se entregará los premios de sus concursos de coros, comparsas y chirigotas.

_Orden de actuación_

*   13:00h – Coro: **El Gremio**
*   13:30h – Coro: **La fiesta de los locos**
*   14:00h – Coro: **El paraíso**
*   15:00h – Cuarteto infantil: **Un cuarteto en peligro de extinción**
*   15:30h – Chirigota juvenil: **Las añejas**
*   16:00h – Comparsa: **Pueblejito la frontera**
*   17:00h – Chirigota: **Carnaval, me cago en tus muertos**
*   17:30h – Comparsa: **La chirigotera**
*   18:00h – Comparsa: **El paseíto**
*   18:30h – Chirigota: **Los plácidos domingos**
*   19:00h – Comparsa: **Los Sacrificaos**
*   19:30h – Chirigota: **Los del Canal Sur**

*   La **AVV del Mentidero** organizará en su plaza la **II Pinchada popular**, en torno a las **13:00h**.

Agrupaciones callejeras y del COAC por las calles de Cádiz
----------------------------------------------------------

Este jueves de carnaval, encontrarás numerosas callejeras, romanceros y agrupaciones del COAC ofreciendo sus repertorios por las calles de Cádiz. Si quieres saber cuáles son los puntos más calientes y habituales échale un vistazo a nuestro artículo sobre **[donde ver agrupaciones en Cádiz](https://www.codigocarnaval.com/donde-ver-agrupaciones-cadiz/)**. También puedes consultar la **[guía de Callejeras 2024](https://www.codigocarnaval.com/noticias/guia-callejeras-2024/)**

Además, en nuestro **[canal Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)**, donde somos ya más de 5000 carnavaleros podrás acceder y recibir todas las notificaciones al instante en tu teléfono sobre ubicaciones de agrupaciones y sus programas para el día.

La cantera callejea
-------------------

Desde las **14:00h hasta las 18:00h**, podremos disfrutar de las actuaciones de las agrupaciones tanto **infantiles como juveniles** en los tablaos situados en **San Antonio** y en la plaza **San Juan de Dios**.

Gran Piñata Infantil
--------------------

Desde las **14:00h hasta las 18:00h** en la **Glorieta Ana Orantes** los más peques podrán disfrutar de la Gran Piñata Infantil.

Quema Bruja Piti
----------------

Los eventos del Carnaval de Cádiz 2024 finalizarán este domingo con la **quema de la Bruja Piti**, que como novedad se celebrará en la Plaza de San Antonio tras la finalización del concierto.

Espectáculo de luces y sonidos Fin del Carnaval
-----------------------------------------------

Desde las **22:15h** se podrá dar por finalizada la semana de carnaval a orillas de la **playa de la Caleta** donde se disfrutará de un espectáculo de luces y sonido.

#### Programación para otros días
