Title: ▷ Agenda SEGUNDO SABADO DE CARNAVAL en Cádiz

URL Source: https://www.codigocarnaval.com/carnaval-de-cadiz/agenda-segundo-sabado-de-carnaval/

Published Time: 2023-02-21T15:28:31+01:00

Markdown Content:
El segundo **sábado de Carnaval** (17 de febrero) comienza con una programación amplia y variada, donde disfrutaremos del segundo fin de semana del Carnaval de Cádiz ¡Comienza a acabarse lo bueno!

Aquí, podremos disfrutar de una programación tanto de día como la tarde-noche, con especial atención a los eventos gastronómicos.

Final XLIV Concurso Tanguillos
------------------------------

El **Gran Teatro Falla** acoge, a partir de las **16:00h** del mediodía la **Gran Final del concurso de Tanguillos** del Carnaval de Cádiz.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Concierto de Luly Pampín
------------------------

A las **12:30h** del medio día podremos disfrutar del concierto de **Luly Pampín** en la Plaza de San Antonio.

Carruseles de coros
-------------------

A partir de las **13:00h**, comenzarán nuevos **[carruseles de coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** que en esta ocasión recorrerán el **barrio del Mentidero** y **La Viña**. Una nueva oportunidad para disfrutar de su majestad el tango.

Carrusel de Callejeras en ‘Los Adoquines’
-----------------------------------------

La Peña ‘Los Adoquines’ acogerá nuevamente una concentración de agrupaciones callejeras y romanceros del Carnaval de Cádiz.

![Image 1: adoquines2024](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20940%20788'%3E%3C/svg%3E)

Degustaciones gratuitas
-----------------------

A partir del mediodía, podrás disfrutar de un gran surtido de **[degustaciones gastronómicas gratuitas](https://www.codigocarnaval.com/comer-gratis-en-el-carnaval-de-cadiz/)** en las diferentes peñas y asociaciones de Cádiz.

Así, podrás encontrar:

*   A partir de las **12:00h** se podrá disfrutar de la **XXXVI Panizada Popular** donde este año tendrá lugar en las Bóvedas de Santa Elena.
*   A partir de las **12:00h** **XLV Tortillada Popular de Camarones** en la barriada de Loreto con actuaciones de algunas agrupaciones de carnaval _(a falta de confirmación por parte de la organización)_
*   A partir de las **13:00h Degustación de papas aliñás** en el Barrio Santa María acompañada de actuaciones carnavalescas (_a falta de confirmación oficial por parte de la organización)_
*   A partir de las **13:30h** **XXVII Degustación de migas extremeñas** en la Casa de Extremadura (c/regimiento de Infantería, 7) donde habrá actuaciones de romanceros, chirigotas y cuartetos.

Final XXIV Concurso de pasodobles
---------------------------------

La **peña Paco Alba** organizará la tradicional **Panizada Popular**, donde se degustarán panizas y actuarán diversas agrupaciones carnavalescas.  El evento se celebrará en **las Bóvedas de Santa Elena en el antiguo patio de Bomberos,** frente a la propia peña en las Puertas de Tierra. El evento comenzará a partir de las **14:00h** del sábado 17 de febrero.

Este sábado de carnaval, encontrarás numerosas callejeras, romanceros y agrupaciones del COAC ofreciendo sus repertorios por las calles de Cádiz. Si quieres saber cuáles son los puntos más calientes y habituales échale un vistazo a nuestro artículo sobre **[donde ver agrupaciones en Cádiz](https://www.codigocarnaval.com/donde-ver-agrupaciones-cadiz/)**. También puedes consultar la **[guía de Callejeras 2024](https://www.codigocarnaval.com/noticias/guia-callejeras-2024/)**

Además, en nuestro **[canal Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)**, donde somos ya más de 7000 carnavaleros podrás acceder y recibir todas las notificaciones al instante en tu teléfono sobre ubicaciones de agrupaciones y sus programas para el día.

La cantera callejea
-------------------

Desde las **14:00h** hasta las **18:00h** podremos disfrutar de actuaciones de **agrupaciones tanto infantiles como juveniles** en la plaza San Antonio como en la plaza San Juan de Dios.

Cabalgata del Humor
-------------------

Las calles del centro histórico volverán a llenarse de música y coloridos con el desfile de la **[cabalgata del humor](https://www.codigocarnaval.com/cabalgata-del-humor-carnaval-cadiz/)** a partir de las **19:00h** de la tarde.

_**Recorrido**: Salida del Colegio de Santa Teresa – Avda. Duque de Nájera – Rosa – Sagasta – San Pedro – Beato Diego José de Cádiz – San Francisco – Nueva – Plaza de San Juan de Dios_

**CABALGATA DEL HUMOR 🎭  
**Consulta todo el recorrido y los detalles de la **[cabalgata del humor](https://www.codigocarnaval.com/cabalgata-del-humor-carnaval-cadiz/)**

Concierto ‘El Arrebato’
-----------------------

La **plaza de San Antonio** acogerá el segundo sábado de carnaval el concierto de **‘El Arrebato’**. Será a partir de las **22:00h**, la entrada es libre hasta completar aforo.

Concierto de Luigii López
-------------------------

La **plaza de San Antonio** acogerá el segundo sábado de carnaval el concierto de **‘Luiggi López’**. Será a partir de las **23:30h**, la entrada es libre hasta completar aforo.

#### Programación para otros días
