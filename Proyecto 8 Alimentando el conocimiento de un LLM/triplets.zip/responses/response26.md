Title: Código Carnaval ▷ La web del CARNAVAL DE CADIZ ®

URL Source: https://www.codigocarnaval.com/

Published Time: 2021-04-20T17:11:19+02:00

Markdown Content:
¡Bienvenidos/as! a **Código Carnaval**. Aquí encontrarás toda la información relacionada con el **Carnaval de Cádiz** y con el **Concurso Oficial de Agrupaciones** (**[COAC 2025](https://www.codigocarnaval.com/coac-2024/)**) en el Gran Teatro Falla.

¿Qué encontrarás en Código Carnaval?
------------------------------------

### Contenido original

¡Olvídate de los ‘copia y pega’!  
Generamos el contenido 100% original

### Web referente

Contamos con más de 200.000 seguidores  
en todas nuestras redes sociales

### Contenido objetivo

Amamos el carnaval, sin fanatismos.  
Todas las modalidades y por supuesto, cantera.

*   [Facebook](https://www.facebook.com/codigocarnaval)
*   [X](https://www.twitter.com/codigocarnaval)
*   [Instagram](https://www.instagram.com/codigocarnaval)
*   [WhatsApp](https://whatsapp.com/channel/0029VaCb6jt5vKAE2SWYv41M)
*   [YouTube](https://www.youtube.com/@Codigocarnaval)
*   [TikTok](https://www.tiktok.com/@codigocarnaval)
