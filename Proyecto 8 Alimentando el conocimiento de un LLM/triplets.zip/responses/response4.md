Title: CARPA Carnaval Cadiz 2024 ▷ Todas las NOVEDADES

URL Source: https://www.codigocarnaval.com/carpa-carnaval-cadiz/

Published Time: 2019-10-17T10:43:51+02:00

Markdown Content:
El Ayuntamiento de Cádiz ha confirmado que en el próximo **Carnaval de Cádiz 2024** volverá a instalarse la **Carpa Municipal** como en años anteriores, con excepción de 2022 que finalmente quedo el proceso de licitación desierto.

¿Dónde se ubicará la Carpa 2024?
--------------------------------

La Carpa 2024 del Carnaval de Cádiz se instalará junto a la muralla del **Parque Ondalla**, frente a la estación de tren al lado de la Plaza de Sevilla y colindante a la cuesta de las Calesas.

La carpa tendrá una capacidad de 1800 metros cuadrados como máximo y albergará espectáculos, baile, restauración y actividades del carnaval.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

¿Cuándo abre la carpa de Carnaval 2024?
---------------------------------------

Está previsto, que como todos los años la **apertura de la Carpa de Carnaval 2023** se inicie un día antes de la **[Gran Final del COAC 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-final-2024/)**, es decir, el jueves 8 de febrero, permaneciendo abierta hasta el domingo 18 de febrero.

Horarios Carpa Carnaval 2024
----------------------------

De momento no tenemos información de los horarios de apertura y cierre. Habrá que esperar a que se realice la subasta.

Precios entradas Carpa Carnaval Cádiz 2024
------------------------------------------

De momento desconocemos los precios de la Carpa para el Carnaval de Cádiz 2024, ya que la misma saldrá a concurso para adjudicar a las empresas que deseen explotarla y señalar sus normativas.

En líneas generales, los precios de las entradas suelen ser más caros durante los fines de semana y festivos, bajando el precio durante los días entre semana. Algunos días, las entradas incluyen derecho a consumición, pero de momento estará por ver.
