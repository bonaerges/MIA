Title: La guía de Callejeras 2024 del Carnaval de Cádiz

URL Source: https://www.codigocarnaval.com/noticias/guia-callejeras-2024/

Published Time: 2024-01-29T12:01:27+01:00

Markdown Content:
Una vez termina el concurso del Teatro Falla, la calle toma el protagonismo en el Carnaval de Cádiz. Como cada año, te hemos preparado un pequeño resumen de **chirigotas callejeras 2024** que podrás encontrar y quiénes eran en años anteriores.

Recuerda, la mayoría de agrupaciones tienen algunos puntos de referencia donde es habitual verlas, pero no tienen un horario establecido y se van moviendo de manera anárquica.

Si quieres estar al tanto de las ubicaciones de las **agrupaciones callejeras 2024** puedes seguirnos en **[nuestro canal de Telegram](https://www.codigocarnaval.com/carnaval-de-cadiz-en-telegram/)**.

Esto es solo un aperitivo de las agrupaciones destacadas que puedes encontrar en la calle durante la semana de carnaval. Si quieres, puedes consultar un **[listado de agrupaciones callejeras](https://www.codigocarnaval.com/agrupaciones-callejeras/)** mucho más completo y detallado.

Guía de chirigotas callejeras 2024
----------------------------------

Estas son algunas de las agrupaciones que no deberías perderte por las calles de Cádiz.

La conocida como ‘**Chirigota del Airon**‘ es una de las más buscadas, el año pasado fueron ‘**[Los Llorones](https://youtu.be/GHR5bU9zgsk?si=U5GGBzYP43kfUA0C)‘** y este año serán ‘**Los becarios del Telediario**‘. Son muy habituales por la Viña y alrededores durante toda la semana, principalmente de noche.

Las **Cadiwoman** son otras de las habituales, con sus repertorios feministas y humor descarado. En 2023 fueron ‘**[Las spice del padrón](https://www.youtube.com/watch?v=AEJ2s4rksLs&pp=ygUZbGFzIHNwaWNlIGNvZGlnbyBjYXJuYXZhbA%3D%3D)**‘ y este año serán ‘**Las sin filtro, chirigota cadiwoman 1954′**. Muy habituales por Encarnación, Solano y/o alrededores.

**La chirigota del Perchero** (En 2023: ‘De Medieval en peor’) se llamarán ‘**Los Psicoanalistas se la dan de artistas**‘. El **Showmancero** (La tribu de los indios gaditas de la reserva del Río San Pedro) aumentan sus componentes y serán ‘**Los Bacardí**‘.

La conocida como **chirigota de Casapuerta** en la que participa **[Miguel Ángel García Argüez ‘Chapa’](https://www.codigocarnaval.com/autores/miguel-angel-garcia-arguez/)** se llamarán ‘**La clínica privada del Sr. Potato**‘. Fueron ‘**[Los Cocos](https://www.youtube.com/watch?v=52dBp1LBeQg&pp=ygUZbG9zIGNvY29zIGNvZGlnbyBjYXJuYXZhbA%3D%3D)**‘ el año pasado. Los podrás ver por Argantonio y alrededores de La Viña.

El chiridúo compuesto por Pedro Thomas y José Flor se llamarán ‘**Abatar, desavío en el espacio**‘, el año pasado fueron ‘**Si me queréis venirse**‘. Son muy habituales entre semana por la iglesia de Santa Cruz.

El humorista **Carlos Mení** (‘**La recogía**‘ en 2023) volverá a estar por las calles con ‘**Er coño tu prime**‘. Mientras que **la chirigota del Pedri** (Te la vamos a clavar en 2023) serán ‘**¡Cuéntame!**‘.

Una de las novedades en la calle será la incorporación de la comparsa de **Marta Ortiz**, que participaron en el COAC con agrupaciones como ‘**[Las Musas](https://www.codigocarnaval.com/coac-2023/las-musas/)**‘ o ‘**[We can do… Carnaval](https://www.codigocarnaval.com/coac-2022/we-can-do-carnaval/)**‘. Serán este año chirigota callejera con el nombre ‘**Las Adolfas, una comparsita feminazi de toda la vida**‘.

También hablando del COAC, el grupo de lo que la chirigota ‘**[Los Daddy Cadi](https://www.codigocarnaval.com/coac-2019/daddy-cadi/)**‘ volverán a estar en la calle como hicieron en 2022 con ‘**Los Kichi Blinders**‘. En esta ocasión serán ‘**Los Secos del Rocío**‘

Otra de las habituales es la **chirigota del Ukelele**, con sus célebres cuplés de 3 palabras. En 2023 fueron ‘**Los chamanes del Marquesado**‘ y este año serán ‘**Los Lisántropos**‘. Muy habituales por Mateo de Alba, Armengual o calles de la Viña.

**La chirigota rockera** es otra de las veteranas de la calle. En 2023 fueron ‘**Espartaco y los que te meten el taco**‘. Para este año serán ‘**Los que fueron a Woodstock y todavía están a gusto**‘. Muy habituales por c/ Rosario Cepeda por el día y por Capuchinos por la noche.

Más chirigotas callejeras 2024 que no puedes perderte…
------------------------------------------------------

La **chirigota de los extranjeros** son muy habituales por el arco del Pópulo. En 2023 fueron ‘**Más vale nunca que tarde**‘ y este año nos presentan ‘**Viven (y de milagro)**‘.

La **chirigota Platónica** serán este año ‘**Valiente príncipe**‘. En 2023 fueron ‘**[Un mundo feliz](https://www.youtube.com/watch?v=KwvIpVl2jvk&pp=ygUedW4gbXVuZG8gZmVsaXogY29kaWdvIGNhcm5hdmFs)**‘. Los podrás encontrar por los alrededores de Armengual, La Rosa por el día y La Viña por la noche.

Otra de las clásicas es la **chirigota del Parchís**, que este año serán ‘**Los que sueltan agüilla**‘. Fueron el año anterior ‘**Los que se jartan despacio**‘. La callejera ‘**Sin ánimo de luto**‘ es otra de las habituales. Fueron en 2023 ‘**La guantá invisible**‘ y para este año serán ‘**Los Peritos**‘.

La conocida como **callejera absurda** estará en las calles con ‘**Los mierdas lerendas**‘, mientras que **la chirigota de la bandera** serán ‘**Los trisnina**‘ (Banda de cornetas sin tambores…en 2023). La ilegal de Rota, que fueron ‘**Los Alarmistas**‘ serán ‘**Que traducido resulta**‘.

Otra de las habituales en estos últimos años es la **chirigota de Juan Osorio**, que estuvieron con ‘**La última y nos vamos**‘ en 2023 y serán este año ‘**A morir que son dos días**‘. La **chirigota Cuqui** serán ‘**Los otakus: Una chirigota pa que te Anime**‘, el año pasado fueron ‘**Esto ya ha salio**‘.

Tampoco te puedes perder **el cuarteto de la calle Sagasta**. Que siempre interpretan con un humor exquisito todos sus repertorios, aunque de momento este año no conocemos su nombre.

Otras de las agrupaciones que han confirmado su nombre a última hora es la **chirigota de las Coñetas**, que serán este año ‘**Cadi, la exnovia del mar**‘. En 2023 fueron ‘**[Callejera Street Fighter](https://www.youtube.com/watch?v=NDJ0MILHhGU&pp=ygUoc3RyZWV0IGZpZ2h0ZXIgY2FsbGVqZXJhIGNvZGlnbyBjYXJuYXZhbA%3D%3D)**‘.
