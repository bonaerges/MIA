Title: ▷ PESTIÑADA 2024 - Fecha, actuaciones e información

URL Source: https://www.codigocarnaval.com/pestinada/

Published Time: 2019-10-10T18:13:55+02:00

Markdown Content:
La **Pestiñada Popular** es una de las fiestas más célebres del Carnaval de Cádiz, que este año celebrará el colectivo ‘**Asociación de Comparsistas 1960**‘, cogiendo así el testigo de la **Peña Los Dedócratas**, los primeros fundadores de este evento gastronómico.

La Pestiñada 2023 se celebrará el sábado **27 de enero** en la plaza de San Francisco, a partir de las 20:30h, coincidiendo con los **[cuartos de final del COAC 2024](https://www.codigocarnaval.com/coac-2024/orden-actuacion-cuartos-2024/)**.

La Pestiñada es la primera fiesta gastronómica del año, que posteriormente suele dar paso a la **[erizada](https://www.codigocarnaval.com/erizada/)** y **[ostionada](https://www.codigocarnaval.com/ostionada/)**, la gambada y mejillonada popular de la Peña La Perla.

Tradicionalmente, la Pestiñada siempre ha sido uno de los primeros eventos gastronómicos que se celebraban en Cádiz previos al concurso del Gran Teatro Falla, habitualmente muy pegado a la navidad, aunque en esta edición, se hará con el mismo ya comenzado.

Agrupaciones que participan en la Pestiñada 2024
------------------------------------------------

Además del acto gastronómico, la Pestiñada contarña con la participación de diversas agrupaciones y antologías carnavalescas

*   Antología ‘La Tropa del 3×4’
*   Antología ‘Sal de coplas’
*   Antología ‘Jesús Cruz y Zeus Marín’
*   Antología ‘Los Cleriguillos’
*   Chirigota ‘Los de la arritmia al 3×4’.

La teniente de alcalde de Fiestas y Carnaval, Beatriz Gandullo, ha realzado la importancia de la fiesta en la calle, así como la implicación de los colectivos. “Me gustaría agradecer a la Asociación de Comparsistas su implicación para mantener viva una fiesta que forma parte de la historia de la ciudad y que será un adelanto de lo que podremos vivir en la semana oficial del Carnaval de Cádiz”.

Asimismo, ha destacado que este año los actos gastronómicos llegarán de la mano de la cantera, con la puesta en marcha del programa ‘La cantera callejea’. Gracias a esta iniciativa, los grupos finalistas de las categorías de infantiles y juveniles ofrecerán sus coplas en los alrededores de los actos gastronómicos los días 28 de enero y 4 de febrero.

¿En qué consiste la Pestiñada?
------------------------------

Es una fiesta gastronómica, en la que la **Asociación de Comparsistas 1960** reparte de manera gratuita se repartirán unos **10.000 pestiños** elaborados por la empresa Franjosé, regados con **120 litros de anís** para acompañar la degustación.

La fiesta se prolonga durante unas horas y en ella, aparte de la degustación gastronómica se puede disfrutar de las coplas que amenizan los coros y algunas antologías en el escenario que se instala en la misma plaza.

Datos de interés sobre la Pestiñada

🗓️ **Fecha:** Sábado, 27 de enero

📍 **Lugar:** Plaza de San Francisco (Cádiz)

🛏️ **Ofertas de alojamientos en Cádiz:** **[Busca en Booking](http://bit.ly/33RYCWg)**
