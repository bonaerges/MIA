Title: 【 CABALGATA Carnaval de Cádiz 2024 】▷ Código Carnaval

URL Source: https://www.codigocarnaval.com/cabalgata-carnaval-cadiz/

Published Time: 2019-10-10T13:20:37+02:00

Markdown Content:
**La Gran Cabalgata del Carnaval de Cádiz** tendrá lugar el próximo **domingo 11 de febrero** y recorrerá la **Avenida Ana de Viya**, una de las principales arterias de la ciudad gaditana, es junto al **[Carrusel de Coros](https://www.codigocarnaval.com/carrusel-coros-carnaval-cadiz/)** uno de los eventos más importantes del domingo.

Será a partir de las **18:00h**, cuando de comienzo en la **Glorieta Ana Orantes** (a la altura de McDonald’s) y llegue hasta la zona de las Puertas de Tierra en un recorrido lineal. 

Las agrupaciones del COAC que participen se situarán al inicio oficial de la Cabalgata, entre las que suelen ir la carroza del **[Pregonero](https://www.codigocarnaval.com/pregon-carnaval-cadiz/)** y el **[Dios Momo](https://www.codigocarnaval.com/quema-dios-momo/)**.

Recorrido Cabalgata Carnaval 2024
---------------------------------

Itinerario

– Glorieta Ana Orantes  
– Avenida Cayetano del Toro  
– Avenida Ana de Viya  
– Avenida Andalucía  
– Puertas de Tierra (Final, altura c/ Barcelona)

**La Cabalgata del Carnaval de Cádiz** estará compuesta por diversas carrozas, adornadas a una temática concreta, recorriendo la avenida dando luz, música y colorido a las calles gaditanas durante su trayecto.

Una de las peculiaridades de este cortejo es que todas las carrozas girarán en torno a una misma temática, que estará centrada en la **historia de Cádiz**.

**Serán nueve las carrozas que formen parte del desfile** y cada una de ellas representará una de las etapas históricas de la ciudad. El Cádiz romano, fenicio, el de los Cargadores de Indias y sus piratas, el Cádiz Ilustrado, el de la Constitución de 1812 o el Cádiz del futuro serán algunos de los pasajes históricos que contarán con representación, a través de numerosos elementos vinculados a estos hechos históricos.

Desde los sarcófagos fenicios, hasta las características Casas Palacio gaditanas, pasando por los galeones que surcaban los mares de la Bahía de Cádiz y sus incalculables tesoros tendrán cabida a través de esta colorida recreación histórica.

A estas carrozas también se sumarán una dedicada al **Gran Teatro Falla**, así como las de los personajes habituales del Carnaval de Cádiz, como son el **Dios Momo** o los pregoneros de la fiesta, tanto infantil como adulto, que tendrán sus propias carrozas, como es habitual.

En la misma, suelen participar algunas agrupaciones del **[COAC 2024](https://www.codigocarnaval.com/coac-2024/)**, pero únicamente como partícipes del desfile. No cantarán, pero puede ser una oportunidad para poder adquirir el libreto o cd de su agrupación favorita.

Además de las diversas agrupaciones, se inscriben grupos para el cortejo.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Así es la Cabalgata del Carnaval de Cádiz
-----------------------------------------

Comprar sillas Cabalgata Carnaval Cádiz 2024
--------------------------------------------

Las sillas para la **Cabalgata Magna del Carnaval de Cádiz 2024** que se desarrollará el próximo domingo 11 de febrero ya están a la venta.

Por primera vez, las localidades se podrán comprar por internet, en la página web de Enterticket [**https://www.enterticket.es/**](https://www.enterticket.es/), donde ya está disponible el 40% de las sillas. En este caso y sólo para la venta online, la empresa concesionaria cargará una comisión por gastos de gestión de 1,80 euros por localidad.

### Horario de taquillas para sillas Cabalgata 2024

El 60% restante se pondrá a la venta en taquilla, en un módulo habilitado en la calle Doctor José Manuel Pascual y Pascual número 3, a partir del próximo miércoles. El horario de las taquillas será de 10 a 13:30 horas y de 16 a 19 horas. Este punto de venta estará habilitado también el jueves y el viernes en el mismo horario.

El precio de las localidades será de 7 euros en fila delantera y de 6 euros para la fila trasera.

Datos de interés sobre la Cabalgata del Carnaval de Cádiz

🗓️ **Fecha:** Domingo 11 de febrero (18:00h)

📍 **Lugar:** Glorieta Ana Orantes (Antigua Ingeniero La Cierva) (Punto de inicio)

🛏️ **Ofertas de alojamientos en Cádiz:** **[Busca en Booking](http://bit.ly/33RYCWg)**

🛏️ **El mejor comparador de Alojamientos en Cádiz:** **[Mejores precios en Cádiz](http://www.hotelscombined.es/Place/Cadiz.htm?a_aid=178580)**
