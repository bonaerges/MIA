Title: 🥇 Pregón Carnaval de Cádiz 2024 | Código Carnaval

URL Source: https://www.codigocarnaval.com/pregon-carnaval-cadiz/

Published Time: 2019-10-11T09:21:50+02:00

Markdown Content:
El **pregón del Carnaval de Cádiz** es uno de los eventos que dan el pistoletazo de salida al carnaval en la calle.

Cada año, el Ayuntamiento de Cádiz elige una personalidad que ya sea por su influencia e importancia de cara a la ciudad o su trayectoria y trascendencia en la fiesta es nombrada para efectuar un pregón en la **plaza de San Antonio** el primer sábado de carnavales.

Estos pregones también cuentan con agrupaciones invitadas por el pregonero/a.

Fechas ¿Cuándo es el pregón del Carnaval de Cádiz 2024?
-------------------------------------------------------

Este año, el pregón se celebrará el **sábado 10 de febrero** en la **Plaza de San Antonio**, en torno a las 20:00h de la tarde.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Juan Manuel Braza ‘El Sheriff’, pregonero del Carnaval 2024
-----------------------------------------------------------

El gaditano y autor de carnaval, **Juan Manuel Braza Benítez ‘El Sheriff’** será el pregonero del Carnaval de Cádiz 2024.

**‘El Sheriff’**, gaditano de 55 años, es uno de los autores y componentes más carismáticos de la modalidad de chirigotas en el Carnaval de Cádiz. Inició su andadura en 1987 con ‘**Los feicios**’, una chirigota que curiosamente participó en el pregón que aquel año dio **Ramón Díaz ‘Fletilla’**.

Nacido en el barrio de Santa María pero desde su adolescencia en Loreto, las chirigotas de **‘El Sheriff’** cuentan con numerosas finales en su larga trayectoria con dos primeros premios en la modalidad, en 1997 con ‘**Los aleluyas**’ y en 2006 con ‘**Los aguafiestas**’. Sin embargo, una de sus chirigotas más recordadas fue ‘**Caimán**’, que en 1994 alcanzó un tercer puesto pero que todavía sigue siendo muy recordada por los aficionados.

También lo es un pasodoble que compuso para ‘**Los valientes**’ en 2004, ‘_**Loquito por verte a mi vera**_’.

Recoge así, el testigo de la cordobesa **[India Martínez](https://www.codigocarnaval.com/carnaval-de-cadiz-2022/india-martinez-pregonera/)**, que fue la encargada de dar el pregón del Carnaval de Cádiz en 2022.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

Así fue el pasado Pregón Carnaval Cádiz
---------------------------------------

Listado pregoneros Carnaval de Cádiz

2024 – **Juan Manuel Braza «El Sheriff»**  
2023 – **Joaquín Quiñones**  
2022 – **India Martínez**  
2020 – **David Palomar**  
2019 – **Joaquín Sabina**  
2018 – **Compañía de Teatro «Las Niñas de Cádiz»**  
2017 – **Antonio Rico Segura** **«Pedro de Los Majaras»**  
2016 – **Pablo Carbonell**  
2015 – **Merche**  
2014 – **Chirigota del Love**  
2013 – **Jorge Drexler**  
2012 – **María Rosa García, Niña Pastori**  
2011 – **Julio Pardo Melero**  
2010 – **José Luis García Cossío «El Selu»**  
2009 – **Javier Ruibal**  
2008 – **Antonio Martínez Ares**  
2007 – **Pasión Vega**  
2006 – **José Guerrero Roldán, Yuyu**  
2005 – **Alejandro Sanz**  
2004 – **Andrés Morales y Lucas González Andy & Lucas**  
2003 – **Carlos Herrera**  
2002 – **Sara Baras**  
2001 – **Ismael Beiro**  
2000 – **Agustín González, Chimenea**  
1999 – **Enrique Villegas**  
1998 – **Paz Padilla**  
1997 – **Antonio Martín García**  
1996 – **Esther Arroyo**  
1995 – **Jesús Janeiro Jesulín de Ubrique**  
1994 – **Miguel Durán Campos**  
1993 – **Pedro Payán Sotomayor**  
1992 – **Carmen Abenza Díaz**  
1991 – **Benito Rodríguez, Beni de Cádiz**  
1990 – **Jorge y César Cadaval, Los Morancos**  
1989 – **Isabel Pantoja**  
1988 – **Antonio Burgos y Carlos Cano**  
1987 – **Ramón Díaz (Fletilla)**  
1986 – **Mario Moreno Cantinflas**  
1985 – **Rocío Jurado**  
1984 – **Jesús Quintero el Loco de la Colina**  
1983 – **Carlos Edmundo de Ory**  
1982 – **Pedro Romero Varo y Felipe Campuzano**  
1981 – **Rafael Alberti**  
1980 – **Fernando Quiñones**  
1979 – **Bartolomé Llompart Bello**  
1961 – **Joaquín Calvo Sotelo**  
1960 – **José de las Cuevas Velásquez- Gaztelu**  
1959 – **José María Pemán**
