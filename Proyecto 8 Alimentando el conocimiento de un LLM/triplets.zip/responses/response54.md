Title: ▷ Consejos GRAN TEATRO FALLA para el COAC 2023

URL Source: https://www.codigocarnaval.com/consejos-gran-teatro-falla/

Published Time: 2019-10-17T11:38:54+02:00

Markdown Content:
Una vez has completado la difícil, pero no imposible tarea de **[conseguir las entradas](https://www.codigocarnaval.com/entradas-coac/)** para disfrutar de una o varias funciones en el Gran Teatro Falla y su concurso del Carnaval de Cádiz, hay una serie de consejos que debes saber.

Si todavía no has disfrutado de una sesión del Concurso en el Gran Teatro Falla o si has ido, pero andas un poco despistado/a, vamos a darte una serie de _‘tips’_ imprescindibles que debes saber.

Entra con antelación
--------------------

Las puertas se abren aproximadamente **entre una hora y una hora y media antes** de cada función.

No vayas con el tiempo justo, ya que **suelen formarse colas previas al acceso del Teatro** (sobre todo en las funciones más esperadas) y puedes llegar muy apurado al inicio de la función.

**COAC 2024**

Si quieres estar al tanto sobre toda la información del concurso no te pierdas nuestro artículo sobre el **[COAC 2024](https://www.codigocarnaval.com/coac-2024)** (fechas oficiales, precios de las entradas, las diferentes fases, las agrupaciones…)

Paraíso no está numerado
------------------------

![Image 1: Gallinero Teatro Falla](https://www.codigocarnaval.com/wp-content/uploads/2019/10/Gallinero-Teatro-Falla-1.jpg.webp)

Si tienes tu localidad para paraíso / gallinero, debes de recordar que estas entradas **no están numeradas**, por lo que es conveniente que vayas con una hora de antelación a la apertura de puertas para conseguir un buen sitio.

Tampoco lo están los palcos, que tienen varias sillas delante y un par de ellas altas atrás, que suelen ser más incómodas, por lo que si quieres coger las más cómodas y compartes palco, se previsor.

Las localidades del teatro
--------------------------

Si aún no estás familiarizado con las localidades del Teatro Falla, en este artículo te dejamos toda la información sobre los diferentes asientos.

*   **[El aforo del Gran Teatro Falla y sus localidades](https://www.codigocarnaval.com/aforo-gran-teatro-falla/)**

No subas fotos antes de la actuación a redes sociales
-----------------------------------------------------

![Image 2: Pasacalles Los Equilibristas](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201024%20576'%3E%3C/svg%3E)

Es muy problable que mientras estés en la cola para entrar al Teatro te encuentres a alguna agrupación que está haciendo pasacalles para entrar.

Te rogamos, por el respeto al trabajo de las agrupaciones **no cuelgues esas fotografías en las redes sociales antes de la actuación de las mismas**.

Hay muchos aficionados que no quieren ‘spoliers’ de su agrupación favorita hasta que no se levanten las cortinas.

Te pedirán el DNI en la entrada
-------------------------------

Aparte de las correspondientes entradas, uno de los requisitos imprescindibles para acceder al Falla será **presentar el DNI**, que te será requerido en la puerta.

Allí, comprobarán que los datos de la entrada y el documento de identidad coinciden.

**ALOJAMIENTOS EN CÁDIZ 🏨  
**Consulta la mejor oferta de **[alojamientos en Cádiz](https://www.booking.com/searchresults.es.html?city=-374884&aid=1286902&no_rooms=1&group_adults=2&label=cadiz)** para los carnavales. No pagues de más y consigue los mejores precios en hoteles, hostales y apartamentos con cancelación gratuita.

No se puede acceder con la agrupación en escena
-----------------------------------------------

No hay descanso como tal entre agrupación y agrupación, pero sí un tiempo aproximado de unos 15 minutos entre desmontaje y montaje de otra agrupación.

En ese tiempo, puedes aprovechar para ir al servicio, o para acudir al ambigú si quieres comer o beber algo, pero recuerda, una vez la agrupación esté en escena, los acomodadores no te dejarán entrar a tu ubicación para que no interrumpas y tendrás que esperar a que acabe el repertorio o al menos una pieza.

No está permitido grabar ni realizar fotos
------------------------------------------

Durante la actuación de las agrupaciones **no está permitido grabar ni realizar fotografías** (salvo a los medios acreditados), los acomodadores pueden llamarte la atención.

Entre agrupación y agrupación si podrás realizar las fotos o vídeos que quieras.

Así es el Gran Teatro Falla por dentro
--------------------------------------

No se permite comer en el teatro
--------------------------------

![Image 3:](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20800%20389'%3E%3C/svg%3E)

Si acudes por primera vez al teatro, debes de saber que **no está permitido comer en el interior del Gran Teatro Falla**.

No obstante, hay una sala habilitada para ello, llamada **ambigú**, en el que se instala una barra donde podréis encontrar bocadillos, aperitivos y todo tipo de refrescos y bebidas alcohólicas.

No hay aire acondicionado en el teatro
--------------------------------------

El Teatro Falla no posee un sistema de calefacción ni aire acondicionado, por lo que en ocasiones, en algunas zonas del Teatro podrías pasar frío, o calor si lo visitas en una época más veraniega.

Te recomendamos ir bien abrigado (en el mes de febrero), y aunque aquello no sea Alaska, los más frioleros acaban siempre echándose el abrigo por encima.

**PROGRAMACIÓN CARNAVAL DE CÁDIZ 2024  
**Si no quieres perderte ningún evento del Carnaval de Cádiz ya puedes consultar la agenda más completa con la **[Programación Carnaval de Cádiz 2024](https://www.codigocarnaval.com/programacion-carnaval-de-cadiz/)**

Respeta a las agrupaciones
--------------------------

Intenta ser lo más respetuoso posible con las agrupaciones, son muchos meses de trabajo y necesitarán silencio para que la obra se escuche en todo el Teatro, sobre todo el cuarteto, que son pocos componentes.

Si no te gusta la agrupación que viene a continuación, siempre tienes la opción de irte al ambigú.

¿Dónde aparcar cerca del Teatro Falla?
--------------------------------------

Ya sabemos que aparcar en Cádiz es un dilema, pero puedes encontrar algunos parkings cercanos al Gran Teatro Falla.

*   **Parking Valcárcel:** Situado en el antiguo colegio de Varcárcel, capacidad para 300 plazas.
*   **Parking El Tenis:** Es el más cercano al Teatro Falla, posee 4 plantas y 308 plazas.
*   **Parking Santa Catalina:** Junto al Parador Hotel Atlántico, tiene para 160 plazas.
*   **Párking Santa Bárbara:** Entre el Parque Genovés y la Alameda Apodaca posee 800 plazas.
